from __future__ import annotations
from dataclasses import dataclass, field
import hashlib
import math
import re
from app.modules.drawings_boq.takeoff.extract import config as C
from app.modules.drawings_boq.takeoff.extract import members as M
from app.modules.drawings_boq.takeoff.extract import rooms as R
from app.modules.drawings_boq.takeoff.extract.sheetkind import sheet_kind
from app.modules.drawings_boq.takeoff.extract import walls as W
from app.modules.drawings_boq.takeoff.extract import rcc as RC
from app.modules.drawings_boq.takeoff.extract import rcc_ring as RR
from app.modules.drawings_boq.takeoff.extract import completion as CP
from app.modules.drawings_boq.takeoff.extract import neck as NK
from app.modules.drawings_boq.takeoff.extract import wide_openings as WO
from app.modules.drawings_boq.takeoff.extract import lintel_heads as LH
from app.modules.drawings_boq.takeoff.extract import beam_sections as BS
from app.modules.drawings_boq.takeoff.extract import tank_sections as TS
from app.modules.drawings_boq.takeoff.extract import site_items as SI
from app.modules.drawings_boq.takeoff.extract import opening_check as OK
from app.modules.drawings_boq.takeoff.prep import tank_details as TD
from app.modules.drawings_boq.takeoff.extract import dashed_openings as DO
from app.modules.drawings_boq.takeoff.extract import hosts as H
from app.modules.drawings_boq.takeoff.extract import beam_marks as BM
from app.modules.drawings_boq.takeoff.extract import plan_regions as PR
from app.modules.drawings_boq.takeoff.extract import foundation as FD
from app.modules.drawings_boq.takeoff.extract import finishes as FN
from app.modules.drawings_boq.takeoff.extract import flights as FL
from app.modules.drawings_boq.takeoff.extract import slab_openings as SO
from app.modules.drawings_boq.takeoff.extract import structure as ST
from app.modules.drawings_boq.takeoff.extract import column_census as CS
from app.modules.drawings_boq.takeoff.extract import beam_strips as BSP
from app.modules.drawings_boq.takeoff.levels import level_spec
from app.modules.drawings_boq.takeoff.prep import census
from app.modules.drawings_boq.takeoff.prep import lintels as LT
from app.modules.drawings_boq.takeoff.prep import steel_notes as SN
from app.modules.drawings_boq.takeoff.prep import schedules as S
from app.modules.drawings_boq.takeoff.prep import stairs as STR
from app.modules.drawings_boq.takeoff.prep import views as VW
from app.modules.drawings_boq.takeoff.prep.details import norm_mark as ST_norm
from app.modules.drawings_boq.takeoff.prep.texts import build_lines, find_units_hint
import time

SCAN_TEXT_FACTOR = 0.8

@dataclass
class Candidate:
  key: str
  category: str
  kind: str
  quantity_mode: str
  label: str
  tag: str | None
  geometry: dict
  params: dict
  missing: list
  work_item: str | None
  status: str
  confidence: float
  facts: dict
  notes: list
  source: str
  count: int

@dataclass
class Extraction:
  candidates: list = field(default_factory=list)
  unmapped_tags: list = field(default_factory=list)
  stats: dict = field(default_factory=dict)
  notes: list = field(default_factory=list)

VIEW_SCALE_TOL = 0.03
_FEET_INCH = re.compile(r"\d+\s*['’′]\s*-\s*\d+")

def _key(*parts) -> str:
  return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:24]

def _status(notes: list) -> str:
  sev = {n["severity"] for n in notes}
  return "INVALID" if "error" in sev else "WARNING" if "warning" in sev else "VALID"

def _fmt_mm(v: float) -> str:
  return str(int(round(v))) if abs(v - round(v)) < 0.05 else f"{v:.1f}"

def _finish(c: Candidate, ctx: dict, base: float) -> Candidate:
  if ctx.get("scale_unverified"):
    c.notes.append(C.note("SCALE_UNVERIFIED"))
  c.status = _status(c.notes)
  c.confidence = round(max(0.0, min(1.0, base * ctx["cal_factor"] * ctx["content_factor"])), 4)
  return c

_snap_inch = ST.snap_inch

def _tag_candidates(index, words, shapes, f, hint, heights, ctx, openings=None, view=None, groups=None, imperial: bool = False, footing: dict | None = None, col_details: dict | None = None) -> list:
  """view: one drawing of a composite sheet (its marks are counted inside it only). groups: the marks already found in that view.
  footing: {"assigned": {mark: (a, b)}, "assumed": bool, "options": [...]} the footing sizes read from the footing section details."""
  if groups is None:
    groups = M.tag_members(words, shapes, f, hint, openings)
  out = []
  
  clusters: dict = {}
  for g in groups:
    if g["category"] in ("COLUMN", "FOOTING") and "drawn_mm" in g:
      a, b = g["drawn_mm"]
      ids = tuple(i for i, s in enumerate(shapes) if s["fill"] and abs(s["a"] - a) <= 0.05 * a + 5 and abs(s["b"] - b) <= 0.05 * b + 5)
      clusters.setdefault((g["category"], ids), []).append(g)
  tags_in = {}
  for (cat, ids), gs in clusters.items():
    for g in gs:
      tags_in[g["tag"]] = (sum(x["count"] for x in gs), len(ids))
  for g in groups:
    cat, tag = g["category"], g["tag"]
    work_item, mode, kind = C.SUGGESTIONS[cat]
    notes: list = []
    facts: dict = {"tag": tag, "count": g["count"], "schedule_rows": g["schedule_rows"]}
    params: dict = {}
    missing: list = []
    base = 0.9
    used = None
    
    if cat in ("COLUMN", "FOOTING"):
      drawn, sched = g.get("drawn_mm"), g.get("schedule_mm")
      if drawn and imperial and cat == "COLUMN":
        snapped = (_snap_inch(drawn[0]), _snap_inch(drawn[1]))
        if snapped != tuple(drawn):
          facts["size_measured_mm"] = list(drawn)
          drawn = snapped
      detail = (footing or {}).get("assigned", {}).get(tag) if cat == "FOOTING" else None
      cdet = (col_details or {}).get(ST_norm(tag)) if cat == "COLUMN" else None
      cdet_mm = cdet.get("size_mm") if cdet and not cdet.get("disagree") else None
      facts["matched_shapes"] = g["matched"]
      
      if drawn:
        facts["size_drawn_mm"] = list(drawn)
      if sched:
        facts["size_schedule_mm"] = list(sched)
      if sched:
        used = sched
        notes.append(C.note("SIZE_FROM_SCHEDULE"))
        if drawn and (abs(sched[0] - drawn[0]) > C.SIZE_TOL * drawn[0] or abs(sched[1] - drawn[1]) > C.SIZE_TOL * drawn[1]):
          notes.append(C.note("SIZE_DIFFERS_FROM_SCHEDULE", drawn_mm=list(drawn), schedule_mm=list(sched)))
          base *= 0.9
          
      elif cdet_mm:
        used = cdet_mm
        facts["size_detail_mm"] = list(cdet_mm)
        notes.append(C.note("SIZE_FROM_COLUMN_DETAIL"))
        if drawn and (abs(cdet_mm[0] - drawn[0]) > C.SIZE_TOL * cdet_mm[0] or abs(cdet_mm[1] - drawn[1]) > C.SIZE_TOL * cdet_mm[1]):
          notes.append(C.note("COLUMN_PLAN_VS_DETAIL", drawn_mm=list(drawn), detail_mm=list(cdet_mm)))
          base *= 0.9
      elif drawn:
        used = drawn
        if view and cat == "COLUMN":
          notes.append(C.note("COLUMN_SIZE_FROM_PLAN"))
      elif detail:
        used = detail
        facts["size_detail_mm"] = list(detail)
        notes.append(C.note("SIZE_FROM_DETAIL"))
        
        if footing.get("assumed"):
          notes.append(C.note("FOOTING_SIZE_ORDER_ASSUMED", options_mm=footing["options"]))
          base *= 0.8
      else:
        notes.append(C.note("SIZE_NOT_FOUND"))
        if cat == "FOOTING" and footing and footing.get("options") and not g.get("stair"):
          notes.append(C.note("FOOTING_SIZES_LISTED", options_mm=footing["options"]))
        base *= 0.8
      if cdet and cdet.get("disagree"):
        notes.append(C.note("COLUMN_DETAILS_DISAGREE", sizes_in=cdet["sizes_in"]))
        base *= 0.9
      if drawn and g.get("spread", 0) > C.SIZE_TOL:
        notes.append(C.note("SIZE_VARIES"))
        base *= 0.9
        
      if used:
        facts["size_used_mm"] = [used[0], used[1]]
        params["length_mm"], params["width_mm"] = used[0], used[1]
      if tag in tags_in:
        n_tags, n_drawn = tags_in[tag]
        facts["same_size_marks"], facts["same_size_drawn"] = n_tags, n_drawn
        if n_drawn > n_tags:
          notes.append(C.note("UNTAGGED_SAME_SIZE", marks=n_tags, drawn=n_drawn))
          base *= 0.9
        elif n_drawn and n_drawn < n_tags:
          notes.append(C.note("COUNT_DIFFERS_FROM_DRAWN", marks=n_tags, drawn=n_drawn))
          base *= 0.9
      dim = "depth_mm"
      h = heights.get("COLUMN") if cat == "COLUMN" else None
      
      if h:
        params[dim] = h["mm"]
        notes.append(_height_note(h))
      else:
        missing.append("height_mm" if cat == "COLUMN" else "depth_mm")
      params["dims_basis"] = "SPECIFIED" if (sched or h) else "DRAWN"
      if not used:
        missing.insert(0, "size")
      label = f"{tag} ×{g['count']}" + (f" · {_fmt_mm(used[0])}×{_fmt_mm(used[1])} mm" if used else "")
    elif cat == "BEAM":
      notes.append(C.note("BEAM_LENGTH_NOT_READ"))
      work_item = None
      sched = g.get("schedule_mm")
      if sched:
        facts["size_schedule_mm"] = list(sched)
        notes.append(C.note("SIZE_FROM_SCHEDULE"))
      label = f"{tag} ×{g['count']}" + (f" · {_fmt_mm(sched[0])}×{_fmt_mm(sched[1])} mm" if sched else "")
    else:
      sched = g.get("schedule_mm")
      kind_of = g.get("opening_kind") or cat
      facts["opening_kind"] = kind_of
      if sched:
        facts["size_schedule_mm"] = list(sched)
        facts["area_each_m2"] = round(sched[0] * sched[1] / 1e6, 3)
        notes.append(C.note("SIZE_FROM_SCHEDULE"))
        
      elif g.get("schedule_missing"):
        notes.append(C.note("SCHEDULE_MARK_NOT_FOUND"))
        base *= 0.9
      label = f"{tag}{' ventilator' if kind_of == 'VENTILATOR' else ''} ×{g['count']}" + (f" · {_fmt_mm(sched[0])}×{_fmt_mm(sched[1])} mm" if sched else "")
    if view:
      facts["view"] = {"key": view["key"], "caption": view["caption"], "kind": view["kind"], "level_hint": view.get("level_hint")}
      spec = level_spec(view.get("level_hint"))
      
      if spec:
        label += f" · {spec[0]}"
    cand = Candidate(key=_key(cat, tag, view["key"]) if view else _key(cat, tag), category=cat, kind=kind, quantity_mode=mode, label=label, tag=tag,
      geometry={"points": g["points"]}, params=params, missing=missing, work_item=work_item, status="VALID", confidence=0.0,
      facts=facts, notes=notes, source="TAG_SCAN", count=g["count"])
    out.append(_finish(cand, ctx, base))
  return out

def _ft_in(mm: float) -> str:
  inches = int(round(mm / 25.4))
  return f"{inches // 12}'-{inches % 12}\""

def _with_floor_height(heights: dict, floor_heights: dict | None, level_hint: str | None) -> dict:
  """The height notes of the sheet, with the clear storey height printed on the building sections added for the floor this plan shows. A height
  written as a note on the plan itself is kept; the section height only fills a gap."""
  fh = (floor_heights or {}).get(level_hint or "")
  
  if not fh or not fh.get("clear_mm"):
    return heights
  entry = {"mm": float(fh["clear_mm"]), "text": f"clear storey height {_ft_in(float(fh['clear_mm']))} printed on the building section", "basis": "SECTION"}
  out = dict(heights)
  for cat in ("WALL", "COLUMN"):
    out.setdefault(cat, entry)
  return out

def _height_note(h: dict) -> dict:
  return C.note("HEIGHT_FROM_SECTION" if h.get("basis") == "SECTION" else "HEIGHT_FROM_NOTE", text=h["text"])

def _unmarked_columns(v: dict, squares: list, f: float, ctx: dict, imperial: bool, heights: dict | None = None) -> Candidate | None:
  """A framing view with no column marks at all (a mumty or a stair head) still shows its columns as black squares."""
  sized = [s for s in squares if 150.0 <= s["a"] <= 600.0 and s["b"] <= 900.0]
  if not sized:
    return None
  a = sorted(s["a"] for s in sized)[len(sized) // 2]
  b = sorted(s["b"] for s in sized)[len(sized) // 2]
  a, b = (_snap_inch(a), _snap_inch(b)) if imperial else (M._round5(a), M._round5(b))
  work_item, mode, kind = C.SUGGESTIONS["COLUMN"]
  notes = [C.note("UNMARKED_COLUMNS"), C.note("COLUMN_SIZE_FROM_PLAN")]
  h = (heights or {}).get("COLUMN")
  
  if h:
    notes.append(_height_note(h))
  spec = level_spec(v.get("level_hint"))
  label = f"Columns (no mark) ×{len(sized)} · {_fmt_mm(a)}×{_fmt_mm(b)} mm" + (f" · {spec[0]}" if spec else "")
  facts = {"tag": None, "count": len(sized), "size_drawn_mm": [a, b], "size_used_mm": [a, b], "matched_shapes": len(sized),
    "view": {"key": v["key"], "caption": v["caption"], "kind": v["kind"], "level_hint": v.get("level_hint")}}
  cand = Candidate(key=_key("COLUMN", "UNMARKED", v["key"]), category="COLUMN", kind=kind, quantity_mode=mode, label=label, tag=None,
    geometry={"points": [[round(s["cx"], 4), round(s["cy"], 4)] for s in sized]},
    params={"length_mm": a, "width_mm": b, "dims_basis": "DRAWN", **({"depth_mm": h["mm"]} if h else {})},
    missing=[] if h else ["height_mm"], work_item=work_item, status="VALID", confidence=0.0, facts=facts, notes=notes, source="TAG_SCAN", count=len(sized))
  return _finish(cand, ctx, 0.6)

def _settle_hidden_columns(cands: list) -> int:
  """Fewer columns of a mark's size are drawn than there are marks (some are hidden inside a wall, as on a basement), but the same mark with the same
  number of columns is on another floor where every one is drawn: the marks are the count, and the shortfall is explained."""
  full: dict = {}
  for c in cands:
    f = c.facts or {}
    codes = {n.get("code") for n in c.notes}
    if c.category == "COLUMN" and c.tag and f.get("same_size_marks") and f.get("same_size_drawn") == f.get("same_size_marks") and not codes & {"COUNT_DIFFERS_FROM_DRAWN", "UNTAGGED_SAME_SIZE"}:
      full.setdefault((c.tag, int(c.count or 0), f["same_size_marks"]), set()).add((f.get("view") or {}).get("key"))
  settled = 0
  
  for c in cands:
    f = c.facts or {}
    if c.category != "COLUMN" or not c.tag or not any(n.get("code") == "COUNT_DIFFERS_FROM_DRAWN" for n in c.notes):
      continue
    peers = full.get((c.tag, int(c.count or 0), f.get("same_size_marks")), set()) - {(f.get("view") or {}).get("key")}
    if not peers:
      continue
    c.notes = [C.note("COUNT_MATCHES_OTHER_FLOOR", marks=c.count, drawn=f.get("same_size_drawn")) if n.get("code") == "COUNT_DIFFERS_FROM_DRAWN" else n for n in c.notes]
    c.status = _status(c.notes)
    settled += 1
  return settled

def _column_marks(cands: list) -> list:
  """The columns a framing plan lists, for the shape count: [{"tag", "count", "sizes_mm"}], the plan size first and then the detail size."""
  out = []
  for c in cands:
    f = c.facts or {}
    if c.category != "COLUMN" or f.get("neck_of") or f.get("from_shapes"):
      continue
  
    sizes: list = []
    for k in ("size_drawn_mm", "size_detail_mm", "size_used_mm"):
      v = f.get(k)
      if v and not any(CS.same_size(v, x) for x in sizes):
        sizes.append((float(v[0]), float(v[1])))
    out.append({"tag": c.tag, "count": int(c.count or 0), "sizes_mm": [list(x) for x in sizes]})
  return out

def _beam_width_mm(widths: list, imperial: bool) -> float:
  """The width of a strip beam: the middle of the widths measured on its legs, taken to a whole number of inches on a drawing in inches."""
  mid = sorted(widths)[len(widths) // 2]
  n = round(mid / 25.4)
  return round(n * 25.4, 1) if imperial and n >= 1 and abs(mid - n * 25.4) <= C.BEAM_WIDTH_SNAP_TOL * mid else round(mid, 1)

def _apply_strips(index, view: dict, words: list, cands: list, f: float, ctx: dict, imperial: bool, sections: list | None, level_hint: str | None) -> dict | None:
  beams = [c for c in cands if c.category == "BEAM" and c.tag and not (c.facts or {}).get("derived_from")]
  tags = {str(c.tag).strip().upper() for c in beams}
  marks = [(w.text.strip().upper(), w.cx, w.cy, w.angle) for w in words if w.text.strip().upper() in tags]
  segments, _, truncated = index.window(*view["bbox"], max_segments=C.STRIP_MAX_SEGMENTS)
  
  if truncated:
    return None
  res = BSP.read(segments, marks, f)
  if not res["legs"] and not marks:
    return None

  by = BSP.by_tag(res)
  spec = level_spec(level_hint)
  where = f" · {spec[0]}" if spec else ""
  for c in beams:
    tag = str(c.tag).strip().upper()
    legs = by.get(tag)
    missed = res["unplaced"].get(tag, 0)
    if not legs:
      if missed:
        c.notes.append(C.note("BEAM_MARK_WITHOUT_STRIP", marks=missed, strips=0))
        c.status = _status(c.notes)
      continue
  
    total = sum(l["length_mm"] for l in legs)
    width = _beam_width_mm([l["width_mm"] for l in legs], imperial)
    longest = max(legs, key=lambda l: l["length_mm"])
    marks_printed = int(c.count or 0)
    c.work_item, c.quantity_mode, c.kind = "CON-RCC", "COUNT_X_VOLUME", "COUNT"
    c.count = 1
    
    c.geometry = {"points": [[round((longest["p0"][0] + longest["p1"][0]) / 2.0, 4), round((longest["p0"][1] + longest["p1"][1]) / 2.0, 4)]]}
    c.params = {"length_mm": round(total, 1), "width_mm": width, "dims_basis": "DRAWN"}
    c.missing = ["depth_mm"]
    c.notes = [n for n in c.notes if n.get("code") != "BEAM_LENGTH_NOT_READ"]
    c.notes.append(C.note("BEAM_LENGTH_FROM_STRIPS", strips=len(legs), length_m=round(total / 1000.0, 3)))
    inferred = [l for l in legs if l["via"] != "LABEL"]
    if inferred:
      c.notes.append(C.note("BEAM_STRIP_MARK_FROM_NEIGHBOUR", strips=len(inferred), length_m=round(sum(l["length_mm"] for l in inferred) / 1000.0, 3)))
      
    if missed:
      c.notes.append(C.note("BEAM_MARK_WITHOUT_STRIP", marks=missed, strips=len(legs)))
    BS.apply_marked(c, sections or [])
    c.facts.update({"from_strips": True, "count": 1, "marks_printed": marks_printed, "strip_count": len(legs), "length_m": round(total / 1000.0, 3), "beam_width_mm": width,
      "level_hint": level_hint, "strips": [{"p0": l["p0"], "p1": l["p1"], "length_mm": l["length_mm"], "via": l["via"]} for l in legs]})
    c.label = f"{c.tag} · {total / 1000.0:.2f} m × {_inch_label(width)} in · {len(legs)} strip{'s' if len(legs) != 1 else ''}{where}"
    c.status = _status(c.notes)
  orphans = by.get(None)
  
  if orphans:
    total = sum(l["length_mm"] for l in orphans)
    width = _beam_width_mm([l["width_mm"] for l in orphans], imperial)
    longest = max(orphans, key=lambda l: l["length_mm"])
    notes = [C.note("BEAM_STRIP_NO_MARK", strips=len(orphans)), C.note("BEAM_LENGTH_FROM_STRIPS", strips=len(orphans), length_m=round(total / 1000.0, 3))]
    facts = {"from_strips": True, "count": 1, "tag": None, "strip_count": len(orphans), "length_m": round(total / 1000.0, 3), "beam_width_mm": width, "level_hint": level_hint,
      "strips": [{"p0": l["p0"], "p1": l["p1"], "length_mm": l["length_mm"], "via": None} for l in orphans]}
    
    if view.get("key"):
      facts["view"] = {"key": view["key"], "caption": view["caption"], "kind": view["kind"], "level_hint": view.get("level_hint")}
    cand = Candidate(key=_key("BEAM", "STRIPS", view.get("key") or level_hint or ""), category="BEAM", kind="COUNT", quantity_mode="COUNT_X_VOLUME",
      label=f"Beam strips (no mark) · {total / 1000.0:.2f} m × {_inch_label(width)} in · {len(orphans)} strip{'s' if len(orphans) != 1 else ''}{where}", tag=None,
      geometry={"points": [[round((longest["p0"][0] + longest["p1"][0]) / 2.0, 4), round((longest["p0"][1] + longest["p1"][1]) / 2.0, 4)]]},
      params={"length_mm": round(total, 1), "width_mm": width, "dims_basis": "DRAWN"}, missing=["depth_mm"], work_item="CON-RCC", status="VALID", confidence=0.0, facts=facts,
      notes=notes, source="VECTOR_SNAP", count=1)
    cands.append(_finish(cand, ctx, 0.5))
    
  by_tag_m = {str(t): round(sum(l["length_mm"] for l in ls) / 1000.0, 3) for t, ls in by.items() if t is not None}
  return {"legs": len(res["legs"]), "length_m": round(sum(l["length_mm"] for l in res["legs"]) / 1000.0, 3), "by_tag": by_tag_m,
    "unmarked_m": round(sum(l["length_mm"] for l in orphans or []) / 1000.0, 3), "unplaced_marks": res["unplaced"], "level_hint": level_hint}

def _structure_candidates(index, views: list, f: float, hint, heights, ctx, imperial: bool, view_scales: dict | None = None, col_details: dict | None = None,
  floor_heights: dict | None = None, beam_sections: list | None = None) -> tuple:
  """A sheet that shows several structural plans (foundation, basement / ground / first framing plans, mumty framing plan): each plan is read on
  its own, so the C1 marks of the ground floor are not added to the C1 marks of the first floor. Footings are read from the foundation plan only

  (the framing plans repeat the footing marks beside the columns)."""
  plans = [v for v in views if v["structural"]]
  squares = ST.dedupe_solid(ST.square_shapes(index.rings, f), f)
  pool = ST.dedupe_solid(M.member_shapes(index.rings, f) + squares, f)
  shapes_by = VW.split(pool, views, lambda s: (s["cx"], s["cy"]))
  squares_by = VW.split(squares, views, lambda s: (s["cx"], s["cy"]))
  words_by = VW.split(index.words, views, lambda w: (w.cx, w.cy))
  sizes = ST.footing_sizes(index.words, hint, imperial)
  out: list = []
  stats: list = []
  found: dict = {}
  
  for v in plans:
    ws, sh = words_by.get(v["key"], []), shapes_by.get(v["key"], [])
   
    keep = ("FOOTING",) if v.get("foundation") else ("COLUMN", "BEAM")
    found[v["key"]] = [g for g in M.tag_members(ws, sh, f, hint, None, plan_view=True) if g["category"] in keep]
  
  seen: dict = {}
  for gs in found.values():
    for g in gs:
      if g["category"] == "COLUMN" and g.get("drawn_mm"):
        seen.setdefault(g["tag"], []).append(g["drawn_mm"])
        
  for v in plans:
    groups = found[v["key"]]
    ws, sh = words_by.get(v["key"], []), shapes_by.get(v["key"], [])
    borrowed = set()
    for g in groups:
      if g["category"] == "COLUMN" and not g.get("drawn_mm") and seen.get(g["tag"]):
        g["drawn_mm"] = max(set(seen[g["tag"]]), key=seen[g["tag"]].count)
        g["spread"] = 0.0
        borrowed.add(g["tag"])
    footing = None
    
    if v.get("foundation"):
      footing = ST.assign_footing_sizes(groups, sizes)
      for w in ST.stair_footings(ws):
        groups.append({"tag": "STAIR-F", "category": "FOOTING", "points": [[round(w.cx, 4), round(w.cy, 4)]], "count": 1, "schedule_rows": 0,
          "matched": 0, "stair": True})
    view_heights = _with_floor_height(heights, floor_heights, v.get("level_hint")) if not v.get("foundation") else heights
    cands = _tag_candidates(index, ws, sh, f, hint, view_heights, ctx, view=v, groups=groups, imperial=imperial, footing=footing, col_details=col_details)
    for c in cands:
      if c.tag in borrowed and c.category == "COLUMN":

        c.notes.append(C.note("SIZE_FROM_OTHER_VIEW"))
        c.status = _status(c.notes)
    has_columns = any(g["category"] == "COLUMN" for g in groups)
    if not has_columns and not v.get("foundation"):
      extra = _unmarked_columns(v, squares_by.get(v["key"], []), f, ctx, imperial, view_heights)
      
      if extra is not None:
        cands.append(extra)
    strip_stats = None if v.get("foundation") else _apply_strips(index, v, ws, cands, f, ctx, imperial, beam_sections, v.get("level_hint"))
    own = (view_scales or {}).get(v["key"]) or {}
    if own.get("mm_per_pt") and abs(own["mm_per_pt"] / f - 1.0) > VIEW_SCALE_TOL:
      for c in cands:
        c.notes.append(C.note("VIEW_SCALE_DIFFERS", view_mm_per_pt=own["mm_per_pt"], sheet_mm_per_pt=round(f, 5)))
        c.status = _status(c.notes)
    out.extend(cands)
    by = {}
    
    for c in cands:
      by[c.category] = by.get(c.category, 0) + int(c.count or 0)
    stats.append({"key": v["key"], "caption": v["caption"], "level_hint": v.get("level_hint"), "foundation": bool(v.get("foundation")),
      "columns": by.get("COLUMN", 0), "footings": by.get("FOOTING", 0), "beams": by.get("BEAM", 0), "squares": len(squares_by.get(v["key"], [])),
      "slab_panels": v.get("slab_panels", 0), "slab_note_mm": v.get("slab_note_mm"),
      "column_marks": [] if v.get("foundation") else _column_marks(cands), "beam_strips": strip_stats})
  _settle_hidden_columns(out)
  return out, stats

def _is_imperial(words) -> bool:
  """A drawing dimensioned in feet and inches: several words such as 30'-0" or 13'-6"."""
  n = 0
  for w in words:
    if _FEET_INCH.search(w.text or ""):
      n += 1
      if n >= 4:
        return True
  return False

def _drop_tank_heights(walls: list) -> None:
  """A tank wall is not a storey wall: the storey height read from the sections does not apply to it."""
  for c in walls:
    if c.facts.get("enclosure") != "TANK" or not any(n.get("code") == "HEIGHT_FROM_SECTION" for n in c.notes):
      continue
  
    c.params.pop("height_mm", None)
    c.params["dims_basis"] = "DRAWN"
    c.notes = [n for n in c.notes if n.get("code") != "HEIGHT_FROM_SECTION"]
    if "height_mm" not in c.missing:
      c.missing.append("height_mm")
    c.status = _status(c.notes)
    
def _mark_tanks(words, walls: list, f: float) -> int:
  """Walls that close in a labelled tank (O.H.W.T, U.G.W.Tank, septic tank) get facts["enclosure"] = "TANK"."""
  marked = 0
  for w in words:
    if not C.TANK_LABEL.search(w.text or ""):
      continue
    near = []
    
    for c in walls:
      if c.facts.get("enclosure"):
        continue
      pts = (c.geometry or {}).get("points") or []
      if len(pts) < 2:
        continue
      if H._seg_distance(pts[0], pts[1], (w.cx, w.cy)) * f <= C.TANK_REACH_MM:
        near.append(c)
    if len(near) < 3:
      continue
  
    xs = [p[0] for c in near for p in c.geometry["points"]]
    ys = [p[1] for c in near for p in c.geometry["points"]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    if not (x0 <= w.cx <= x1 and y0 <= w.cy <= y1) or max(x1 - x0, y1 - y0) * f > C.TANK_MAX_MM:
      continue
    for c in near:
      c.facts["enclosure"] = "TANK"
      c.facts["tank_kind"] = TD.kind_of(w.text)
      c.notes.append(C.note("TANK_WALL"))
      c.status = _status(c.notes)
      marked += 1
  return marked

def _outer_box(frames: list, runs: list, f: float) -> tuple | None:
  """The ground the walls of a plan stand on: the box round the runs that are 9 inch or thicker and meet another wall at both ends."""
  pts = []
  for r in runs:
    if r.t_pt * f >= C.OUTER_CORE_MIN_MM and r.end0 != "FREE" and r.end1 != "FREE":
      fr = frames[r.peak]
      pts += [fr.pt(r.s0 - r.ext0, r.dc), fr.pt(r.s1 + r.ext1, r.dc)]
  if len(pts) < 6:
    return None
  tol = max(1.5, C.OUTER_TOL_MM / f)
  return min(p[0] for p in pts) - tol, min(p[1] for p in pts) - tol, max(p[0] for p in pts) + tol, max(p[1] for p in pts) + tol

def _tread_ladders(walls: list, f: float) -> set:
  """The wall candidates (by id) that are really the treads of a stair: at least LADDER_MIN_RUNGS lines of one length and one direction, stacked
  one step apart (a step is at most LADDER_MAX_STEP_MM) at an even spacing. On a plan drawn small, a tread pair looks like a thin wall."""
  items = []
  for c in walls:
    (x0, y0), (x1, y1) = c.geometry["points"]
    length = math.hypot(x1 - x0, y1 - y0)
    if length <= 0.0:
      continue
    ang = math.degrees(math.atan2(y1 - y0, x1 - x0)) % 180.0
    items.append((c, ang, length, (x0 + x1) / 2.0, (y0 + y1) / 2.0))
  gone: set = set()
  step_max = C.LADDER_MAX_STEP_MM / f
  for i, (_, a0, l0, _, _) in enumerate(items):
    group = [it for it in items if min(abs(it[1] - a0), 180.0 - abs(it[1] - a0)) <= 3.0 and abs(it[2] / l0 - 1.0) <= C.LADDER_LENGTH_TOL]
    if len(group) < C.LADDER_MIN_RUNGS:
      continue
  
    rad = math.radians(a0)
    ux, uy = math.cos(rad), math.sin(rad)
    stacked = sorted(((-it[3] * uy + it[4] * ux, it[3] * ux + it[4] * uy, it) for it in group), key=lambda t: t[0])
    chain: list = []
    for t in stacked + [None]:
      if t is not None and chain and 0.0 <= t[0] - chain[-1][0] <= step_max and abs(t[1] - chain[-1][1]) <= 0.6 * l0:
        chain.append(t)
        continue
    
      if len(chain) >= C.LADDER_MIN_RUNGS:
        steps = sorted(b[0] - a[0] for a, b in zip(chain, chain[1:]) if b[0] - a[0] > 0.5)
        mid = steps[len(steps) // 2] if steps else 0.0
        if len(steps) + 1 >= C.LADDER_MIN_RUNGS and all(abs(s - mid) <= C.LADDER_STEP_TOL * mid for s in steps):
          gone.update(id(x[2][0]) for x in chain)
      chain = [t] if t is not None else []
  return gone

def _wall_candidates(index, f, heights, ctx, deadline, imperial: bool = False, at_grade: bool = False, outer_only: bool = False, wall_vocab: list | None = None) -> tuple:
  frames, runs, stats = W.detect_walls(index, f, deadline, at_grade)
  rcc = RC.rcc_runs(index.rings, f)
  stats["rcc_runs"] = len(rcc)
  stats["dropped_stubs"] = 0
  stats["dropped_on_rcc"] = 0
  stats["dropped_outside_rcc"] = 0
  stats["dropped_outside_plan"] = 0
  stats["outside_plan_m"] = 0.0
  outer = _outer_box(frames, runs, f) if outer_only else None
  box = RC.envelope(rcc, f) if rcc else None
  extra = W.bridge_ends(runs, frames, f)
  stats["bridged_ends"] = sum(1 for v in extra.values() for x in v if x > 0.0)
  
  out = []
  for r in runs:
    fr = frames[r.peak]
    add0, add1 = extra.get(id(r), (0.0, 0.0))
    p0, p1 = fr.pt(r.s0 - r.ext0 - add0, r.dc), fr.pt(r.s1 + r.ext1 + add1, r.dc)
    t_mm = r.t_pt * f
    std, use_t = W.snap_thickness(t_mm, imperial, wall_vocab)
    cc_m = ((r.s1 + r.ext1 + add1) - (r.s0 - r.ext0 - add0)) * f / 1000.0
    clear_m = r.clear_pt * f / 1000.0
    if std is None and cc_m * 1000.0 < C.WALL_STUB_MAX_MM:
      stats["dropped_stubs"] += 1
      continue
  
    if outer is not None and not (outer[0] <= (p0[0] + p1[0]) / 2.0 <= outer[2] and outer[1] <= (p0[1] + p1[1]) / 2.0 <= outer[3]):
      stats["dropped_outside_plan"] += 1
      stats["outside_plan_m"] = round(stats["outside_plan_m"] + cc_m, 2)
      continue
    if rcc and RC.covered_by(rcc, p0, p1, f):
      stats["dropped_on_rcc"] += 1
      continue
    
    if box is not None and RC.outside(box, p0, p1):
      stats["dropped_outside_rcc"] += 1
      continue
    spans = list(r.gaps)
    if add0 > 0.0:
      spans.append((r.s0 - r.ext0 - add0, r.s0 - r.ext0))
    if add1 > 0.0:
      spans.append((r.s1 + r.ext1, r.s1 + r.ext1 + add1))
    gaps = [round((b - a) * f) for a, b in spans]
    notes: list = []
    base = 0.8
    if std is None:
      notes.append(C.note("THICKNESS_OFF_STANDARD", drawn_mm=round(t_mm, 1)))
      base *= 0.85
      
    if gaps:
      notes.append(C.note("WALL_OPENINGS_INCLUDED", gaps_mm=gaps, total_mm=sum(gaps)))
      base *= 0.95
      if max(gaps) > C.WALL_GAP_MAX_MM:
        notes.append(C.note("WALL_WIDE_OPENING", widest_mm=max(gaps)))
    if r.end0 == "FREE" and r.end1 == "FREE":
      base *= 0.9
    params = {"thickness_mm": use_t}
    missing = []
    h = heights.get("WALL")
    if h:
      params["height_mm"] = h["mm"]
      notes.append(_height_note(h))
      
    else:
      missing.append("height_mm")
    params["dims_basis"] = "SPECIFIED" if h else "DRAWN"
    if cc_m * 1000.0 <= 0:
      continue
    facts = {"thickness_mm": round(t_mm, 1), "thickness_standard_mm": std, "thickness_used_mm": use_t, "length_cc_m": round(cc_m, 3),
      "length_clear_m": round(clear_m, 3), "gaps_mm": gaps, "ends": [r.end0, r.end1], "method": "CENTRE_LINE",
      "gap_pts": [[[round(x, 3) for x in fr.pt(a, r.dc)], [round(x, 3) for x in fr.pt(b, r.dc)]] for a, b in spans]}
    
    if r.pen_kept:
      facts["light_pen"] = True
      notes.append(C.note("LIGHT_PEN_WALL"))
    if add0 > 0.0 or add1 > 0.0:
      facts["bridged_mm"] = [round(add0 * f), round(add1 * f)]
      notes.append(C.note("WALL_BRIDGED"))
    key = _key("WALL", round(p0[0] / 2), round(p0[1] / 2), round(p1[0] / 2), round(p1[1] / 2))
    work_item, mode, kind = C.SUGGESTIONS["WALL"]
    
    cand = Candidate(key=key, category="WALL", kind=kind, quantity_mode=mode, label=f"Wall {_fmt_mm(use_t)} mm · {cc_m:.2f} m", tag=None,
      geometry={"points": [[round(p0[0], 4), round(p0[1], 4)], [round(p1[0], 4), round(p1[1], 4)]], "closed": False}, params=params,
      missing=missing, work_item=work_item, status="VALID", confidence=0.0, facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    out.append(_finish(cand, ctx, base))
  if outer_only:
    treads = _tread_ladders(out, f)
    if treads:
      stats["dropped_treads"] = len(treads)
      stats["treads_m"] = round(sum(c.facts["length_cc_m"] for c in out if id(c) in treads), 2)
      out = [c for c in out if id(c) not in treads]
  for rc in rcc:
    t_mm = rc["t_mm"]
    std, use_t = W.snap_thickness(t_mm, imperial, wall_vocab)
    cc_m = rc["length_mm"] / 1000.0
    notes = [C.note("RCC_WALL_FROM_FILL")]
    if rc["gaps_mm"]:
      notes.append(C.note("WALL_OPENINGS_INCLUDED", gaps_mm=rc["gaps_mm"], total_mm=sum(rc["gaps_mm"])))
    h = heights.get("WALL")
    params = {"thickness_mm": use_t, "dims_basis": "SPECIFIED" if h else "DRAWN"}
    missing = []
    
    if h:
      params["height_mm"] = h["mm"]
      notes.append(_height_note(h))
    else:
      missing.append("height_mm")
      
    facts = {"thickness_mm": round(t_mm, 1), "thickness_standard_mm": std, "thickness_used_mm": use_t, "length_cc_m": round(cc_m, 3),
      "length_clear_m": round(rc["clear_mm"] / 1000.0, 3), "gaps_mm": rc["gaps_mm"], "ends": ["FREE", "FREE"], "method": "CENTRE_LINE",
      "construction": "RCC", "gap_pts": [[[round(x, 3) for x in a], [round(x, 3) for x in b]] for a, b in rc["gap_pts"]]}
    key = _key("WALL", round(rc["p0"][0] / 2), round(rc["p0"][1] / 2), round(rc["p1"][0] / 2), round(rc["p1"][1] / 2))
    _, mode, kind = C.SUGGESTIONS["WALL"]
    
    cand = Candidate(key=key, category="WALL", kind=kind, quantity_mode=mode, label=f"RCC wall {_fmt_mm(use_t)} mm · {cc_m:.2f} m", tag=None,
      geometry={"points": [[round(rc["p0"][0], 4), round(rc["p0"][1], 4)], [round(rc["p1"][0], 4), round(rc["p1"][1], 4)]], "closed": False},
      params=params, missing=missing, work_item="CON-RCC", status="VALID", confidence=0.0, facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    out.append(_finish(cand, ctx, 0.75))
  stats["rcc_walls"] = len(rcc)
  stats["rcc_ring"] = RR.ring_gaps(rcc, f) if rcc else None
  out.sort(key=lambda c: (c.facts.get("construction") == "RCC", -c.facts["thickness_used_mm"], -c.facts["length_cc_m"]))
  return frames, runs, out, stats

def _room_candidates(index, frames, runs, lines, f, hint, ctx) -> list:
  faces = R.wall_faces(runs, frames)
  k = f * f / 1e6
  faces = [p for p in faces if C.ROOM_MIN_M2 <= p.area * k <= C.ROOM_MAX_M2]
  names, sizes = R.labels(lines, hint)
  pairs = [p for p in R.pair_labels(names, sizes, f) if R.plausible_room(p)]
  items = [(p, "WALLS") for p in faces] + [(p, "OUTLINE") for p in R.outline_rooms(index, names, faces, f)]
  out = []
  used: set = set()
  replaced: dict = {}
  
  for poly, how in items:
    poly = R._clean(poly)
    d = R.describe(poly, names, sizes, f)
    inside = R.pairs_inside(poly, pairs)
    if len(inside) >= 2:
     
      continue
    if len(inside) == 1:
      p = pairs[inside[0]]
      label_area = p["a_mm"] * p["b_mm"] / 1e6
      if abs(d["area_m2"] / label_area - 1.0) > C.ROOM_SIZE_TOL:
        replaced[inside[0]] = d["area_m2"]
        continue
      used.add(inside[0])
    notes: list = []
    base = 0.85 if how == "WALLS" else 0.65
    if how == "OUTLINE":
      notes.append(C.note("ROOM_FROM_OUTLINE"))
    room_names = d["names"]
    if not room_names:
      notes.append(C.note("ROOM_NO_LABEL"))
      base *= 0.8
      
    elif len(room_names) > 1:
      notes.append(C.note("ROOM_MULTIPLE_LABELS", names=room_names))
      base *= 0.85
    if d["deviation_pct"] is not None and abs(d["deviation_pct"]) > C.ROOM_SIZE_TOL * 100:
      notes.append(C.note("ROOM_SIZE_MISMATCH", label_area_m2=round(d["label_area_m2"], 3), measured_area_m2=round(d["area_m2"], 3)))
      base *= 0.9
    cx, cy = poly.centroid.x, poly.centroid.y
    name = " / ".join(room_names) if room_names else None
    minx, miny, maxx, maxy = poly.bounds
    facts = {"name": name, "area_m2": round(d["area_m2"], 3), "perimeter_m": round(d["perimeter_m"], 3), "holes": d["holes"],
      "bbox_mm": [round((maxx - minx) * f), round((maxy - miny) * f)], "size_text": d["size_text"], "outline_from": how}
    
    if d["label_area_m2"] is not None:
      facts["label_area_m2"] = round(d["label_area_m2"], 3)
      facts["deviation_pct"] = round(d["deviation_pct"], 2)
    work_item, mode, kind = C.SUGGESTIONS["ROOM"]
    cand = Candidate(key=_key("ROOM", round(cx / 3), round(cy / 3)), category="ROOM", kind=kind, quantity_mode=mode,
      label=(name or "Room") + f" · {d['area_m2']:.2f} m²", tag=None, geometry=R.polygon_geometry(poly), params={"dims_basis": "DRAWN"},
      missing=[], work_item=work_item, status="VALID", confidence=0.0, facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    out.append(_finish(cand, ctx, base))
  for i, p in enumerate(pairs):
    if i in used:
      continue
    poly = R.label_polygon(p, f)
    area = p["a_mm"] * p["b_mm"] / 1e6
    
    notes = [C.note("ROOM_OUTLINE_REPLACED", measured_area_m2=round(replaced[i], 3), label_area_m2=round(area, 3))] if i in replaced else []
    notes.append(C.note("ROOM_FROM_LABEL", size_text=p["size_text"]))
    facts = {"name": p["name"], "area_m2": round(area, 3), "perimeter_m": round(2.0 * (p["a_mm"] + p["b_mm"]) / 1000.0, 3), "holes": 0,
      "bbox_mm": [round(p["a_mm"]), round(p["b_mm"])], "size_text": p["size_text"], "label_area_m2": round(area, 3), "outline_from": "LABEL"}
    work_item, mode, kind = C.SUGGESTIONS["ROOM"]
    
    cand = Candidate(key=_key("ROOM", round(p["x"] / 3), round(p["y"] / 3)), category="ROOM", kind=kind, quantity_mode=mode,
      label=f"{p['name']} · {area:.2f} m²", tag=None, geometry=R.polygon_geometry(poly), params={"dims_basis": "SPECIFIED"},
      missing=[], work_item=work_item, status="VALID", confidence=0.0, facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    out.append(_finish(cand, ctx, 0.7))
  _flag_nested_rooms(out)
  out.sort(key=lambda c: (c.facts["name"] or "~", -c.facts["area_m2"]))
  return out

def _flag_nested_rooms(rooms: list) -> None:
  """A room whose centre is inside a larger room's outline (a W/C drawn inside a stair hall) is counted twice in the room total. It is kept and
  flagged, not removed: only the engineer can say which outline is the room."""
  from shapely.geometry import Polygon
  polys = []
  for c in rooms:
    g = c.geometry or {}
    try:
      polys.append(Polygon(g["outer"], g.get("holes") or []) if g.get("outer") else None)
    except Exception:
      polys.append(None)
      
  for i, a in enumerate(rooms):
    pa = polys[i]
    if pa is None or pa.is_empty:
      continue
    inside = [j for j, b in enumerate(rooms) if j != i and polys[j] is not None and b.facts["area_m2"] > a.facts["area_m2"] * 1.2
              and polys[j].contains(pa.representative_point())]
    if inside:
      big = max(inside, key=lambda j: rooms[j].facts["area_m2"])
      a.notes.append(C.note("ROOM_INSIDE_ROOM", enclosing=rooms[big].facts.get("name"), enclosing_m2=rooms[big].facts["area_m2"]))
      a.facts["inside_room"] = rooms[big].facts.get("name")
      a.status = _status(a.notes)

def _inch_text(mm: float) -> str:
  return f"{mm / 25.4:g}\""

def _section_label(values: list, note_mm: float, implied_mm) -> dict | None:
  best = None
  for v in values:
    if abs(v["mm"] - note_mm) <= 1.0 or "slab" not in (v.get("scopes") or []) or int(v.get("count") or 0) < C.SLAB_LABEL_MIN_COUNT:
      continue
    if implied_mm and abs(float(implied_mm) - v["mm"]) > C.SLAB_LABEL_SECTIONS_TOL_MM:
      continue
    if best is None or int(v["count"]) > int(best["count"]):
      best = v
  return best

def _slab_thickness(note_mm, slab_values: list, implied_mm=None) -> tuple:
  values = [v for v in (slab_values or []) if v.get("mm")]
  if note_mm:
    others = [v for v in values if abs(v["mm"] - note_mm) > 1.0]
    label = _section_label(others, float(note_mm), implied_mm) if others else None
    note = lambda used: C.note("SLAB_THICKNESS_DISAGREES", plan_mm=note_mm, used=used, others=[{"mm": v["mm"], "pages": v.get("pages", []), "count": int(v.get("count") or 0)} for v in others])
    
    if label:
      return float(label["mm"]), "SECTION_LABEL", [note("SECTION_LABEL")]
    return float(note_mm), "PLAN_NOTE", [note("PLAN_NOTE")] if others else []
  if len(values) == 1:
    return float(values[0]["mm"]), "OTHER_SHEET", [C.note("SLAB_THICKNESS_FROM_OTHER_SHEET", pages=values[0].get("pages", []))]
  if len(values) > 1:
    return None, None, [C.note("SLAB_THICKNESSES_LISTED", options_mm=[v["mm"] for v in values])]
  return None, None, []

def _slab_options(t, source, slab_values: list, implied, note_mm=None) -> list:
  """Every thickness the drawing supports for one slab, each with the places that print it: the plan note or the one used, the other sheets that print a
  slab thickness, and the thickness the building sections imply (floor-to-floor height less clear storey height)."""
  out: list = []
  def add(mm, src, pages=None):
    if not mm:
      return
    for o in out:
      if abs(o["mm"] - mm) <= 1.0:
        if src not in o["sources"]:
          o["sources"].append(src)
        o["pages"] = sorted(set(o["pages"]) | set(pages or []))
        return
    out.append({"mm": float(mm), "sources": [src], "pages": sorted(set(pages or []))})
  add(t, source or "PLAN_NOTE")
  add(note_mm, "PLAN_NOTE")
  for v in slab_values or []:
    add(v.get("mm"), "OTHER_SHEET", v.get("pages"))
  add(implied, "SECTIONS")
  return out

def _implied_slab_mm(floor_heights: dict | None, hint: str | None) -> float | None:
  """The slab thickness the building sections imply for one floor: the floor-to-floor height less the clear storey height."""
  fh = (floor_heights or {}).get(hint or "") or {}
  ftf, clear = fh.get("floor_to_floor_mm"), fh.get("clear_mm")
  if not ftf or not clear:
    return None
  mm = float(ftf) - float(clear)
  return round(mm, 1) if C.SLAB_SECTION_MIN_MM <= mm <= C.SLAB_SECTION_MAX_MM else None

def _outline_axes(dims, printed: list) -> tuple | None:
  """(horizontal mm, vertical mm) of the covered area: the overall lengths printed on the plans along each direction are matched to the two sides of the
  area table's rectangle. None when they cannot be matched."""
  a, b = float(dims[0]), float(dims[1])
  def has(axis: str, v: float) -> bool:
    return any(d.get("axis") == axis and abs(float(d["mm"]) - v) <= 0.015 * v for d in printed)
  ah, av, bh, bv = has("H", a), has("V", a), has("H", b), has("V", b)
  if ah and bv and not (av and bh):
    return a, b
  if bh and av and not (ah and bv):
    return b, a
  if ah and bv and av and bh and abs(a - b) <= 0.015 * a:
    return a, b
  return None

def _slab_outline(dims, proj: dict | None) -> tuple:
  """(outline (length, width) mm or None, facts, notes): the covered area of a floor widened by the roof projections its plans print, one width per side.
  The slab is the plan outline plus the projection on each side, corners included. A side printed twice with different widths, or a label that sits in no
  clear side of the page, is not added."""
  if not proj or not dims or len(dims) != 2:
    return None, {}, []

  sides = dict(proj.get("sides") or {})
  unplaced, conflicts = proj.get("unplaced") or [], proj.get("conflicts") or []
  if not sides and not unplaced and not conflicts:
    return None, {}, []
  notes: list = []
  
  facts: dict = {"projections": {"sides": {k: v["width_mm"] for k, v in sides.items()}, "text": {k: v["text"] for k, v in sides.items()},
    "pages": sorted({p for v in sides.values() for p in v.get("pages", [])}), "applied": False}}
  if unplaced:
    notes.append(C.note("SLAB_PROJECTION_UNPLACED", labels=[u["text"] for u in unplaced]))
  if conflicts:
    notes.append(C.note("SLAB_PROJECTION_CONFLICT", sides=[{"side": c["side"], "widths_mm": c["widths_mm"]} for c in conflicts]))
  if not sides:
    return None, facts, notes
  axes = _outline_axes(dims, proj.get("dims") or [])
  if axes is None:
    notes.append(C.note("SLAB_PROJECTION_AXIS_UNKNOWN"))
    return None, facts, notes
  h, v = axes
  w = {k: float(sides[k]["width_mm"]) if k in sides else 0.0 for k in ("TOP", "BOTTOM", "LEFT", "RIGHT")}
  outline = (h + w["LEFT"] + w["RIGHT"], v + w["TOP"] + w["BOTTOM"])
  facts["projections"]["applied"] = True
  facts["projections"]["table_dims_mm"] = [h, v]
  notes.append(C.note("SLAB_PROJECTIONS_ADDED", sides={k: v_["text"] for k, v_ in sides.items()}))
  return outline, facts, notes

def _slab_candidate(plan: dict, areas: dict, slab_values: list, ctx: dict, implied_mm: float | None = None, projections: dict | None = None) -> tuple:
  """One slab per floor from a structural framing plan: the covered area printed for that floor in the area table, as the rectangle (length x width)
  printed beside it, with the thickness of the plan's slab note. Nothing is measured from the drawn lines, so the scale of the sheet does not enter.
  Returns (candidate or None, notes for the sheet)."""
  hint = plan.get("level_hint")
  area = areas.get(hint) if hint else None
  spec = level_spec(hint)
  if area is None:
    return None, [C.note("SLAB_AREA_NOT_FOUND", floor=spec[0] if spec else hint, caption=plan.get("caption"))]
  t, source, notes = _slab_thickness(plan.get("note_mm"), slab_values, implied_mm)
  options = _slab_options(t, source, slab_values, implied_mm, plan.get("note_mm"))
  if implied_mm:
    notes.append(C.note("SLAB_THICKNESS_SECTIONS", implied_mm=implied_mm))
    for n in notes:
      if n["code"] == "SLAB_THICKNESS_DISAGREES":
        n["sections_mm"] = implied_mm
        
  params: dict = {"dims_basis": "SPECIFIED"}
  missing: list = []
  dims = area.get("dims_mm")
  base = 0.9
  outline, outline_facts, outline_notes = _slab_outline(dims, (projections or {}).get(hint) if hint else None)
  if dims and len(dims) == 2:
    params["length_mm"], params["width_mm"] = (float(outline[0]), float(outline[1])) if outline else (float(dims[0]), float(dims[1]))
    notes.append(C.note("SLAB_AREA_FROM_TABLE"))
    notes.extend(outline_notes)
    if outline_notes:
      base *= 0.95
  else:
    missing.append("size")
    notes.append(C.note("SLAB_SIZE_NOT_PRINTED"))
    base *= 0.7
  if t:
    params["depth_mm"] = t
  else:
    missing.append("thickness_mm")
    base *= 0.8
  if any(n["code"] == "SLAB_THICKNESS_DISAGREES" for n in notes):
    base *= 0.9
  m2 = float(area["m2"])
  gross_m2 = float(outline[0]) * float(outline[1]) / 1e6 if outline else m2
  label = "Slab" + (f" {_inch_text(t)}" if t else "") + f" · {gross_m2:.2f} m²" + (f" · {spec[0]}" if spec else "")
  facts = {"floor": hint, "area_m2": m2, "area_text": f"{area['value']:g} {area['unit']}", "area_name": area.get("name"), "area_pages": area.get("pages", []),
    "thickness_mm": t, "thickness_source": source, "thickness_options": options, "thickness_sections_mm": implied_mm, "panels": plan.get("panels", 0),
    "panel_marks": plan.get("marks", [])}
  
  if dims:
    facts["dims_mm"] = [float(dims[0]), float(dims[1])]
    facts["dims_text"] = area.get("dims_text")
  facts.update(outline_facts)
  if outline:
    facts["outline_dims_mm"] = [round(float(outline[0]), 1), round(float(outline[1]), 1)]
    facts["gross_area_m2"] = round(gross_m2, 3)
    facts["projection_area_m2"] = round(gross_m2 - m2, 3)
  if t and dims:
    facts["volume_m3"] = round(float(params["length_mm"]) * float(params["width_mm"]) * t / 1e9, 4)
  if plan.get("view"):
    facts["view"] = plan["view"]
    
  work_item, mode, kind = C.SUGGESTIONS["SLAB"]
  cand = Candidate(key=_key("SLAB", hint, plan.get("key") or ""), category="SLAB", kind=kind, quantity_mode=mode, label=label, tag="SLAB",
    geometry={"points": [[round(plan["centre"][0], 4), round(plan["centre"][1], 4)]]}, params=params, missing=missing, work_item=work_item,
    status="VALID", confidence=0.0, facts=facts, notes=notes, source="PRINTED", count=1)
  cand.status = _status(cand.notes)
  cand.confidence = round(max(0.0, min(1.0, base * ctx["content_factor"])), 4)
  return cand, []

def _hosted_by_tag(by_wall: dict, walls: list) -> dict:
  """tag -> {"thin": n, "rcc": n, "hosted": n}: how many of each opening mark sit in 4.5 inch walls and in RCC walls, from the openings already assigned to walls."""
  wall_of = {w.key: w for w in walls}
  out: dict = {}
  for key, ops in (by_wall or {}).items():
    w = wall_of.get(key)
    if w is None:
      continue
    thin = float((w.params or {}).get("thickness_mm") or 0) < 160.0
    rcc = (w.facts or {}).get("construction") == "RCC"
    for o in ops:
      if not o.get("label"):
        continue
      rec = out.setdefault(o["label"], {"thin": 0, "rcc": 0, "hosted": 0})
      rec["hosted"] += int(o["nos"])
      rec["thin"] += int(o["nos"]) if (thin and not rcc) else 0
      rec["rcc"] += int(o["nos"]) if rcc else 0
  return out

def _lintel_candidates(openings: list, table: list, hosted: dict, ctx: dict) -> list:
  """One lintel candidate per door / window / ventilator mark of a plan: the opening width from the schedule picks the row of the lintel table printed on
  the drawing, the length is the width plus the bearing at each end, and the count is the number of marks counted. Nothing is read from drawn lines."""
  out = []
  if not table:
    return out
  bearing = C.LINTEL_BEARING_MM
  for o in openings:
    size = (o.facts or {}).get("size_schedule_mm")
    pts = (o.geometry or {}).get("points") or []
    if o.category not in ("DOOR", "WINDOW") or not size or not o.tag or not pts:
      continue
    span = float(size[0])
    sec = LT.section_for(table, span)
    notes = [C.note("LINTEL_BEARING_ASSUMED", bearing_mm=bearing)]
    params: dict = {"dims_basis": "SPECIFIED"}
    
    missing: list = []
    base = 0.85
    facts = {"opening_tag": o.tag, "opening_kind": (o.facts or {}).get("opening_kind") or o.category, "span_mm": round(span, 1), "bearing_mm": bearing,
      "opening_size_mm": [round(float(size[0]), 1), round(float(size[1]), 1)]}
    if sec:
      params["length_mm"], params["width_mm"], params["depth_mm"] = round(span + 2.0 * bearing, 1), sec["width_mm"], sec["depth_mm"]
      facts["section_mm"] = [sec["width_mm"], sec["depth_mm"]]
      facts["table_span_max_mm"] = sec["span_max_mm"]
      facts["table_pages"] = list(sec.get("pages") or [])
      notes.append(C.note("LINTEL_SECTION_FROM_TABLE"))
      if sec.get("steel"):
        params["steel"] = dict(sec["steel"])
        facts["steel_text"] = LT.steel_text(sec["steel"])
        notes.append(C.note("LINTEL_STEEL_FROM_TABLE"))
      label = f"Lintel {o.tag} ×{o.count} · {_inch_text(sec['width_mm'])}×{_inch_text(sec['depth_mm'])} · {_fmt_mm(params['length_mm'])} mm long"
    else:
      missing.append("size")
      notes.append(C.note("LINTEL_SPAN_ABOVE_TABLE"))
      base *= 0.7
      label = f"Lintel {o.tag} ×{o.count} · span {_fmt_mm(span)} mm"
    h = hosted.get(o.tag)
    if h:
      facts["hosted"] = dict(h)
      if h["thin"]:
        notes.append(C.note("LINTEL_IN_THIN_WALL", count=h["thin"]))
        base *= 0.9
      if h["rcc"]:
        notes.append(C.note("LINTEL_IN_RCC_WALL", count=h["rcc"]))
    work_item, mode, kind = C.SUGGESTIONS["LINTEL"]
    
    cand = Candidate(key=_key("LINTEL", o.key), category="LINTEL", kind=kind, quantity_mode=mode, label=label, tag=f"L-{o.tag}",
      geometry={"points": [list(p) for p in pts]}, params=params, missing=missing, work_item=work_item, status="VALID", confidence=0.0,
      facts=facts, notes=notes, source="TAG_SCAN", count=int(o.count or len(pts)))
    cand.status = _status(cand.notes)
    cand.confidence = round(max(0.0, min(1.0, base * ctx["content_factor"])), 4)
    out.append(cand)
  return out

def _located_stairs(places: list, spec: dict, ctx: dict, level_hint: str | None = None) -> list:
  waist = spec.get("waist_mm")
  printed = bool(waist)
  waist_used = float(waist or C.STAIR_WAIST_DEFAULT_MM)
  work_item, mode, kind = C.SUGGESTIONS["STAIR"]
  out = []
  
  for p in places:
    notes = [C.note("STAIR_FROM_DETAILS"), C.note("STAIR_LANDINGS_NOT_INCLUDED"), C.note("STAIR_LOCATED_BY_TREADS")]
    way = p.get("direction")
    if way == "DOWN":
      notes.append(C.note("STAIR_DOWN_FLIGHT"))
    elif way is None:
      notes.append(C.note("STAIR_DIRECTION_UNKNOWN"))
    own = p.get("width_printed_mm")
    
    width = float(own) if own else float(spec["width_mm"])
    if own and abs(width - float(spec["width_mm"])) > C.STAIR_OWN_WIDTH_TOL * float(spec["width_mm"]):
      notes.append(C.note("STAIR_OWN_WIDTH", printed_mm=round(width, 1), detail_mm=round(float(spec["width_mm"]), 1), printed_text=p.get("width_printed_text")))
    box = STR.flight_box({**spec, "width_mm": width}, waist_used)
    facts = {"stair_text": spec.get("text"), "riser_mm": spec.get("riser_mm"), "tread_mm": spec.get("tread_mm"), "stair_width_mm": round(width, 1),
      "detail_width_mm": spec.get("width_mm"), "width_source": "PRINTED_BESIDE" if own else "STAIR_DETAIL", "steps": spec.get("steps"),
      "stair_pages": list(spec.get("pages") or []), "direction": way, "treads_drawn": p["treads_drawn"], "width_drawn_mm": p["width_drawn_mm"],
      "flight_area_m2": p.get("flight_area_m2"), "flight_box": p.get("box"), "floor_hint": level_hint}
    params: dict = {"dims_basis": "SPECIFIED"}
    missing: list = []
    
    base = 0.8 if way else 0.7
    if box:
      params.update(box)
      facts.update({"waist_mm": round(waist_used, 1), "waist_source": "PRINTED" if printed else "ASSUMED", "equivalent_depth_mm": box["depth_mm"]})
      if not printed:
        notes.append(C.note("STAIR_WAIST_ASSUMED"))
        base *= 0.9
      label = f"Stair {'up' if way == 'UP' else 'down' if way == 'DOWN' else ''}".strip() + f" · {spec['steps']} steps · {_fmt_mm(spec['riser_mm'])}/{_fmt_mm(spec['tread_mm'])} mm · {_fmt_mm(width)} mm wide"
    else:
      missing = ["size"]
      notes.append(C.note("STAIR_DETAILS_INCOMPLETE"))
      base *= 0.6
      label = "Stair"
    cand = Candidate(key=_key("STAIR", round(p["x"], 1), round(p["y"], 1), 1), category="STAIR", kind=kind, quantity_mode=mode, label=label, tag="STAIR",
      geometry={"points": [[round(p["x"], 3), round(p["y"], 3)]]}, params=params, missing=missing, work_item=work_item, status="VALID", confidence=0.0,
      facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    cand.status = _status(cand.notes)
    cand.confidence = round(max(0.0, min(1.0, base * ctx["content_factor"])), 4)
    out.append(cand)
  return out

def _stair_candidates(lines: list, spec: dict | None, ctx: dict, index=None, mm_per_pt: float | None = None, level_hint: str | None = None) -> tuple[list, list]:
  """One stair candidate per plan that names a staircase, sized from the riser, tread, width and number of steps printed elsewhere on the drawing. The
  concrete is the plan run of the steps x the width x an equivalent thickness (waist slab along the slope plus half a riser). The waist slab is rarely
  printed, so 6 inches is assumed and said so. Landings are not included."""
  
  if spec and index is not None and mm_per_pt:
    places = FL.find_stairs(W.straight_lines(index), spec, mm_per_pt, FL.direction_labels(lines), FL.length_labels(lines, S.feet_inches_mm))
    if places:
      return _located_stairs(places, spec, ctx, level_hint), []
  labels = STR.find_labels(lines)
  if not labels:
    return [], []
  if not spec:
    return [], [C.note("STAIR_DETAILS_NOT_FOUND")]
  waist = spec.get("waist_mm")
  assumed = not waist
  waist_used = float(waist or C.STAIR_WAIST_DEFAULT_MM)
  box = STR.flight_box(spec, waist_used)
  notes = [C.note("STAIR_FROM_DETAILS"), C.note("STAIR_LANDINGS_NOT_INCLUDED"), C.note("STAIR_COUNT_FROM_LABELS", count=len(labels))]
  facts = {"stair_text": spec.get("text"), "riser_mm": spec.get("riser_mm"), "tread_mm": spec.get("tread_mm"), "stair_width_mm": spec.get("width_mm"),
    "steps": spec.get("steps"), "waist_mm": round(waist_used, 1), "waist_source": "ASSUMED" if assumed else "PRINTED", "stair_pages": list(spec.get("pages") or [])}
  params: dict = {"dims_basis": "SPECIFIED"}
  missing: list = []
  base = 0.8
  
  if box:
    params.update(box)
    facts["equivalent_depth_mm"] = box["depth_mm"]
    if assumed:
      notes.append(C.note("STAIR_WAIST_ASSUMED"))
      base *= 0.85
    label = f"Stair ×{len(labels)} · {spec['steps']} steps · {_fmt_mm(spec['riser_mm'])}/{_fmt_mm(spec['tread_mm'])} mm · {_fmt_mm(spec['width_mm'])} mm wide"
  else:
    missing = ["size"]
    notes.append(C.note("STAIR_DETAILS_INCOMPLETE"))
    base *= 0.6
    label = f"Stair ×{len(labels)}"
  work_item, mode, kind = C.SUGGESTIONS["STAIR"]
  cand = Candidate(key=_key("STAIR", round(labels[0]["x"], 1), round(labels[0]["y"], 1), len(labels)), category="STAIR", kind=kind, quantity_mode=mode, label=label,
    tag="STAIR", geometry={"points": [[round(l["x"], 3), round(l["y"], 3)] for l in labels]}, params=params, missing=missing, work_item=work_item, status="VALID",
    confidence=0.0, facts=facts, notes=notes, source="TAG_SCAN", count=len(labels))
  cand.status = _status(cand.notes)
  cand.confidence = round(max(0.0, min(1.0, base * ctx["content_factor"])), 4)
  return [cand], []

def _inch_label(mm: float) -> str:
  return f"{mm / 25.4:g}"

def _wall_beams(walls: list, role: str, ctx: dict, level_hint: str | None, min_wall_mm: float = 0.0, tie_band: dict | None = None) -> list:
  """One beam candidate per wall thickness: the brick walls of this floor laid end to end, as wide as the wall. The depth is not drawn, so it is left to be
  typed when the beam is accepted."""
  groups: dict = {}
  for w in walls:
    f = w.facts or {}
    if w.category != "WALL" or f.get("construction") == "RCC" or f.get("enclosure") == "TANK" or w.status == "INVALID":
      continue
    t = float(f.get("thickness_used_mm") or 0.0)
    if t <= 0.0 or t < min_wall_mm:
      continue
  
    groups.setdefault((round(t, 1), BM.mark_of(w, BS.KIND_OF_ROLE.get(role, role)) or ""), []).append(w)
  out = []
  spec = level_spec(level_hint)
  work_item, mode, kind = ("CON-RCC", "COUNT_X_VOLUME", "COUNT")
  for (t, mark), ws in sorted(groups.items(), key=lambda kv: (-kv[0][0], kv[0][1])):
    length_m = sum(float((w.facts or {}).get("length_cc_m") or 0.0) for w in ws)
    if length_m <= 0.0:
      continue
  
    pts = [p for w in ws for p in ((w.geometry or {}).get("points") or [])]
    cx = sum(p[0] for p in pts) / len(pts) if pts else 0.0
    cy = sum(p[1] for p in pts) / len(pts) if pts else 0.0
    prefix = {"PLINTH": "PLINTH-BEAM", "BAND": "TIE-BAND"}.get(role, "ROOF-BEAM")
    tag = f"{prefix}-{_inch_label(t)}IN" + (f"-{mark}" if mark else "")
    notes = [C.note("BEAM_FROM_WALLS"), C.note("BEAM_OVER_OPENINGS")]
    if role == "PLINTH":
      notes.append(C.note("PLINTH_BEAM_UNDER_9IN"))
    if role == "BAND":
       notes.append(C.note("TIE_BAND_FROM_NOTE"))
    facts = {"derived_from": "WALLS", "beam_role": role, "wall_thickness_mm": t, "wall_count": len(ws), "length_m": round(length_m, 3),
      "wall_keys": [w.key for w in ws], "openings_m": round(sum(sum((w.facts or {}).get("gaps_mm") or []) for w in ws) / 1000.0, 3), "level_hint": level_hint}
    if role == "BAND" and tie_band:
      facts["tie_band_text"] = tie_band.get("text")
      
    if mark:
      facts["beam_mark"] = mark
    kindname = {"PLINTH": "Plinth beam", "BAND": "Tie band at lintel level"}.get(role, "Roof beam")
    label = f"{kindname} {mark} under {_inch_label(t)} in walls · {length_m:.2f} m" if mark else f"{kindname} under {_inch_label(t)} in walls · {length_m:.2f} m"
    label += f" · {spec[0]}" if spec else ""
    cand = Candidate(key=_key("BEAM", role, round(t), level_hint or "", *([mark] if mark else [])), category="BEAM", kind=kind, quantity_mode=mode, label=label, tag=tag,
      geometry={"points": [[round(cx, 4), round(cy, 4)]]}, params={"length_mm": round(length_m * 1000.0, 1), "width_mm": t, "dims_basis": "SPECIFIED"},
      missing=["depth_mm"], work_item=work_item, status="VALID", confidence=0.0, facts=facts, notes=notes, source="VECTOR_SNAP", count=1)
    out.append(_finish(cand, ctx, 0.7))
  return out

def _beam_candidates(walls: list, ctx: dict, level_hint: str | None, lowest: bool, tie_band: dict | None = None) -> list:
  out = _wall_beams(walls, "ROOF", ctx, level_hint)
  if lowest:
    out.extend(_wall_beams(walls, "PLINTH", ctx, level_hint, C.PLINTH_BEAM_MIN_WALL_MM))
  if tie_band:
    out.extend(_wall_beams(walls, "BAND", ctx, level_hint, 0.0, tie_band))
  return out

def _foundation_candidates(walls: list, rooms: list, schedule: dict | None, ctx: dict, level_hint: str | None, sections: list | None = None) -> list:
  """The work under the lowest floor that is worked out from what is already read: a trench, a concrete bed and termite treatment under the walls, the
  termite treatment under the floor, and, on a basement, the dig over the whole outline of the basement."""
  spec = level_spec(level_hint)
  out = FD.strip_candidates(walls, ctx, level_hint, spec, Candidate, _finish, sections)
  out.extend(FD.brick_step_candidates(walls, ctx, level_hint, spec, Candidate, _finish, sections))
  membrane = FD.membrane_candidate(walls, ctx, level_hint, spec, Candidate, _finish)
  if membrane is not None:
    out.append(membrane)
  floor = FD.under_floor_candidate(rooms, ctx, level_hint, spec, Candidate, _finish)
  if floor is not None:
    out.append(floor)
    
  if level_hint == "BASEMENT":
    area = next((a for a in ((schedule or {}).get("areas") or []) if a.get("kind") == "FLOOR" and a.get("key") == level_hint), None)
    dims = (area or {}).get("dims_mm")
    if dims and len(dims) == 2:
      outline, facts, _ = _slab_outline(dims, ((schedule or {}).get("projections") or {}).get(level_hint))
      pts = [p for w in walls for p in ((w.geometry or {}).get("points") or [])]
      centre = [round(sum(p[0] for p in pts) / len(pts), 4), round(sum(p[1] for p in pts) / len(pts), 4)] if pts else [0.0, 0.0]
      cand = FD.excavation_candidate(outline or dims, facts, ctx, level_hint, spec, Candidate, _finish, centre)
      if cand is not None:
        out.append(cand)
  return out

def _finish_candidates(walls: list, rooms: list, doors: list, mm_per_pt: float, ctx: dict, level_hint: str | None) -> list:
  """The finishes of every floor that are worked out from what is already read: the kacha bed and the ceiling plaster from the room areas, the plaster on
  the faces of the walls, and the frames of the doors."""
  spec = level_spec(level_hint)
  out = []
  for build in (FN.kacha_candidate, FN.ceiling_candidate):
    cand = build(rooms, ctx, level_hint, spec, Candidate, _finish)
    if cand is not None:
      out.append(cand)
  out.extend(FN.plaster_candidates(walls, mm_per_pt, ctx, level_hint, spec, Candidate, _finish))
  out.extend(FN.door_frame_candidates(doors, walls, ctx, level_hint, spec, Candidate, _finish))
  return out

def _view_plans(views: list) -> list:
  """The framing plans of a composite structural sheet (not the foundation plan) as slab plans."""
  out = []
  for v in views:
    if not v.get("structural") or v.get("foundation") or not v.get("level_hint"):
      continue
    b = v["bbox"]
    out.append({"key": v["key"], "caption": v.get("caption"), "level_hint": v["level_hint"], "centre": ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0),
      "note_mm": v.get("slab_note_mm"), "panels": int(v.get("slab_panels") or 0), "marks": list(v.get("slab_marks") or []),
      "view": {"key": v["key"], "caption": v["caption"], "kind": v["kind"], "level_hint": v.get("level_hint")}})
  return out

def _sheet_plan(words: list, lines: list, level_hint: str | None, title: str | None) -> dict | None:
  """A structural sheet that shows one framing plan (no separate drawings on it): its slab note and panel marks come from the whole sheet."""
  if not level_hint or not words or VW._FOUNDATION.search(title or ""):
    return None
  note = None
  for ln in lines:
    m = VW._SLAB_NOTE.search(ln.text)
    if m:
      note = round(float(m.group(1)) * 25.4, 1)
      break
  marks = sorted({w.text.strip().upper() for w in words if VW._SLAB_PANEL.match(w.text.strip().upper())})
  xs, ys = [w.cx for w in words], [w.cy for w in words]
  return {"key": "", "caption": title, "level_hint": level_hint, "centre": ((min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0), "note_mm": note,
    "panels": len(marks), "marks": marks, "view": None}

def _read_sheet(index, mm_per_pt: float, *, cal_factor: float = 1.0, scale_unverified: bool = False, content_kind: str = "VECTOR",
  budget_s: float = 25.0, schedule: dict | None = None, views_meta: list | None = None, col_details: dict | None = None,
  floor_heights: dict | None = None, level_hint: str | None = None, slab_values: list | None = None, text_source: str = "TEXT",
  lowest_level: bool = False, with_finishes: bool = False, beam_sections: list | None = None, tank_details: list | None = None,
  sheet_words: list | None = None, outer_only: bool = False, imperial: bool | None = None, wall_vocab: list | None = None,
  footing_sections: list | None = None) -> Extraction:
  started = time.monotonic()
  deadline = started + budget_s
  ctx = {"cal_factor": cal_factor, "scale_unverified": scale_unverified,
    "content_factor": {"VECTOR": 1.0, "UNKNOWN": 0.95, "RASTER": 0.85}.get(content_kind, 0.95) * (SCAN_TEXT_FACTOR if text_source == "OCR" else 1.0)}
  
  res = Extraction()
  if text_source == "OCR":
    res.notes.append(C.note("SCAN_TEXT_READ"))
  words = index.words
  imp_here = imperial if imperial is not None else _is_imperial(words)
  imp_sheet = imperial if imperial is not None else _is_imperial(sheet_words if sheet_words is not None else words)
  lines = build_lines(words)
  notes_lines = build_lines(sheet_words) if sheet_words is not None else lines
  hint = find_units_hint(notes_lines)
  heights = M.height_hints(notes_lines, hint)
  sheet_heights = _with_floor_height(heights, floor_heights, level_hint)
  shapes = M.member_shapes(index.rings, mm_per_pt)
  openings = S.opening_lookup(schedule)
  views = VW.find_views(index)
  
  composite_structural = sum(1 for v in views if v["structural"]) >= 2
  if composite_structural:
    found, vstats = _structure_candidates(index, views, mm_per_pt, hint, heights, ctx, imp_here, {v["key"]: v.get("scale") for v in (views_meta or []) if v.get("scale")}, col_details, floor_heights, beam_sections)
    res.candidates.extend(found)
    res.stats["views"] = vstats
    res.stats["column_details"] = {t: {"sizes_in": r.get("sizes_in") or []} for t, r in (col_details or {}).items()}
    plans = _view_plans(views)
  else:
    found = _tag_candidates(index, words, shapes, mm_per_pt, hint, sheet_heights, ctx, openings, col_details=col_details)
    only = [v for v in views if v["structural"] and not v.get("foundation")]
    if len(only) == 1:
      in_view = [w for w in words if VW.contains(only[0], w.cx, w.cy)]
      strips = _apply_strips(index, only[0], in_view, found, mm_per_pt, ctx, imp_here, beam_sections, only[0].get("level_hint") or level_hint)
      if strips is not None:
        res.stats["beam_strips"] = strips
    res.candidates.extend(found)
    plans = []
    
  res.stats["schedule_marks"] = len(openings)
  kind = sheet_kind(sheet_words if sheet_words is not None else words)
  if not composite_structural and kind["kind"] == "STRUCTURAL":
    one = _sheet_plan(words, lines, level_hint, kind.get("title"))
    plans = [one] if one else []
  areas = {a["key"]: a for a in ((schedule or {}).get("areas") or []) if a.get("kind") == "FLOOR"}
  seen_floor: set = set()
  for plan in plans:
    cand, notes = _slab_candidate(plan, areas, slab_values or [], ctx, _implied_slab_mm(floor_heights, plan.get("level_hint")), (schedule or {}).get("projections"))
    if cand is not None and plan["level_hint"] not in seen_floor:
      seen_floor.add(plan["level_hint"])

      res.candidates.append(cand)
    res.notes.extend(notes)
  res.stats["slabs"] = sum(1 for c in res.candidates if c.category == "SLAB")
  pads = FD.pad_candidates([c for c in res.candidates if c.category == "FOOTING"], ctx, Candidate, _finish)
  res.candidates.extend(pads)
  res.stats["concrete_beds"] = len(pads)
  
  res.stats["sheet_kind"] = kind
  if kind["kind"] != "STRUCTURAL" and not composite_structural and level_hint and sheet_words is None:
    res.stats["column_shapes"] = CS.census(index.rings, mm_per_pt, imp_here, _snap_inch, level_hint)
  frames, runs = [], []
  if kind["kind"] == "STRUCTURAL" or composite_structural:
    res.notes.append(C.note("STRUCTURAL_SHEET", title=kind["title"] or (views[0]["caption"] if views else None)))
  else:
    try:
      frames, runs, walls, wstats = _wall_candidates(index, mm_per_pt, sheet_heights, ctx, deadline, imp_sheet, bool(lowest_level) or str(level_hint or "").upper() in ("GROUND", "BASEMENT"), outer_only, wall_vocab)
      res.candidates.extend(walls)
      wstats["tank_walls"] = _mark_tanks(words, walls, mm_per_pt)
      _drop_tank_heights(walls)
      wstats["tank_drawings_listed"] = TS.apply(walls, tank_details or [])
      res.stats["beam_marks"] = BM.assign(walls, BM.mark_words(words, beam_sections or []), mm_per_pt)
      beams = _beam_candidates(walls, ctx, level_hint, lowest_level, (schedule or {}).get("tie_band"))
      res.stats["beam_sections"] = BS.apply(beams, beam_sections or [])
      res.candidates.extend(beams)
      res.stats["wall_beams"] = len(beams)
      hosted = H.assign(walls, [c for c in res.candidates if c.category in ("DOOR", "WINDOW")], mm_per_pt)
      wstats["openings_assigned"], wstats["openings_unassigned"] = hosted["assigned"], hosted["unassigned"]
      marked = [c for c in res.candidates if c.category in ("DOOR", "WINDOW")]
      wstats["opening_marks"] = OK.check(marked, walls, (schedule or {}).get("openings") or [], mm_per_pt)
      for c in marked:
        if c.facts.get("gap_check"):
          c.status = _status(c.notes)
      
      for c in walls:
        if c.params.get("openings"):
          c.notes.append(C.note("OPENINGS_ASSIGNED", count=c.facts["openings"]["count"], marks=c.facts["openings"]["marks"]))
          c.status = _status(c.notes)
      ring = wstats.pop("rcc_ring", None)
      completion = CP.candidates(ring, CP.rcc_notes(notes_lines), sheet_heights, ctx, imp_sheet, Candidate, _finish, _height_note)
      wstats["rcc_completion"] = {"pieces": len(completion), "sides_drawn": ring["sides"]} if ring else None
      res.stats["walls"] = wstats
      lintels = _lintel_candidates([c for c in res.candidates if c.category in ("DOOR", "WINDOW")], (schedule or {}).get("lintels") or [],
        _hosted_by_tag(hosted.get("by_wall"), walls), ctx)
      res.candidates.extend(lintels)
      dashed = DO.find(index, mm_per_pt, wstats.get("wall_pen_pt"))
      marks = [tuple(q) for c in res.candidates if c.category in ("DOOR", "WINDOW") for q in ((c.geometry or {}).get("points") or [])]
      wide = WO.candidates(walls, (schedule or {}).get("lintels") or [], ctx, Candidate, _finish, _inch_text, _fmt_mm, dashed, marks, mm_per_pt)
      wstats["dashed_openings"] = len(dashed)
      res.candidates.extend(wide)
      bands = [c for c in beams if (c.facts or {}).get("beam_role") == "BAND"]
      res.stats["lintel_heads"] = LH.apply([*lintels, *wide, *bands], [c for c in res.candidates if c.category in ("DOOR", "WINDOW")])
      if bands:
        for c in [*lintels, *wide]:
          if not (c.facts.get("hosted") or {}).get("rcc"):
            c.facts["tie_band"] = {"text": (bands[0].facts or {}).get("tie_band_text"), "candidate_key": bands[0].key}
            c.notes.append(C.note("LINTEL_COVERED_BY_TIE_BAND"))
            
      for c in [*lintels, *wide, *bands]:
        c.status = _status(c.notes)
      res.stats["lintels"] = len(lintels) + len(wide)
      res.stats["lintels_unmarked_openings"] = len(wide)
      stairs, stair_notes = _stair_candidates(lines, (schedule or {}).get("stair"), ctx, index, mm_per_pt, level_hint)
      res.candidates.extend(stairs)
      res.notes.extend(stair_notes)
      res.stats["stairs"] = len(stairs)
      labels = SO.read_labels(lines, hint, mm_per_pt)
      attached, unplaced = SO.attach_landings(stairs, labels["landings"], mm_per_pt, FL._gap)
      for c in stairs:
        c.status = _status(c.notes)
      for lan in unplaced:
        res.notes.append(C.note("STAIR_LANDING_NOT_PLACED", size=lan["text"], area_m2=lan["area_m2"]))
      if labels["unsized"]:
        res.notes.append(C.note("SLAB_OPENING_SIZE_NOT_PRINTED", count=labels["unsized"]))
      res.stats["slab_openings"] = SO.sheet_entries(stairs, labels["voids"], level_hint)
      res.stats["stair_landings"] = {"printed": len(labels["landings"]), "attached": attached}
      if wstats.get("dropped_treads"):
        res.notes.append(C.note("STAIR_TREADS_NOT_WALLS", count=wstats["dropped_treads"], metres=wstats["treads_m"]))
      if wstats.get("dropped_outside_plan"):
        res.notes.append(C.note("RUNS_OUTSIDE_PLAN_WALLS", count=wstats["dropped_outside_plan"], metres=wstats["outside_plan_m"]))
      if wstats.get("dropped_outside_rcc"):
        res.notes.append(C.note("RUNS_OUTSIDE_CONCRETE_WALLS", count=wstats["dropped_outside_rcc"]))
        
      if wstats.get("wall_pen_pt"):
        res.notes.append(C.note("WALL_PEN_SELECTED", pen_pt=wstats["wall_pen_pt"], runs_all_pens=wstats.get("runs_all_pens"),
          wall_m_all_pens=wstats.get("wall_m_all_pens")))
      if wstats.get("light_walls_kept"):
        res.notes.append(C.note("LIGHT_PEN_WALLS_KEPT", count=wstats["light_walls_kept"], metres=wstats.get("light_walls_m")))
      rooms = _room_candidates(index, frames, runs, lines, mm_per_pt, hint, ctx)
      res.candidates.extend(rooms)
      res.candidates.extend(completion)
      
      if with_finishes:
        finishes = _finish_candidates(walls, rooms, [c for c in res.candidates if c.category == "DOOR"], mm_per_pt, ctx, level_hint)
        res.candidates.extend(finishes)
        res.stats["finish_items"] = len(finishes)
      if lowest_level:
        below = _foundation_candidates(walls, rooms, schedule, ctx, level_hint, footing_sections)
        res.candidates.extend(below)
        res.stats["foundation_items"] = len(below)
    except W.TimeLimit:
      res.notes.append(C.note("TIME_LIMIT"))
  found_steel = SN.read(notes_lines)
  res.stats["steel"] = SN.attach(res.candidates, found_steel, C.note)
  res.stats["steel_notes"] = found_steel["notes"]
  
  if composite_structural:
    neck = NK.candidates(res.candidates, ctx, Candidate, _finish)
    res.candidates.extend(neck)
    res.stats["neck_columns"] = len(neck)
  for c in res.candidates:
    c.status = _status(c.notes)
  mapped = {c.tag for c in res.candidates if c.tag}
  unmapped: dict = {}
  for g in census.tag_census(words):
      
    if g["tag"] not in mapped and M.category_of(g["tag"]) is None and g["in_drawing"] >= 2:
      unmapped[g["tag"]] = g["in_drawing"]
  res.unmapped_tags = [{"tag": t, "count": n} for t, n in sorted(unmapped.items(), key=lambda kv: (-kv[1], kv[0]))][:30]
  res.stats["seconds"] = round(time.monotonic() - started, 3)
  res.stats["units_hint"] = hint
  res.stats["units"] = {"imperial": imp_sheet, "basis": "DRAWING" if imperial is not None else "SHEET", "wall_vocab_mm": list(wall_vocab or [])}
  res.stats["height_notes"] = heights
  return res

def _region_scale_note(region: dict, views_meta: list | None, f: float) -> dict | None:
  """The dimensions printed inside the drawing that holds this plan show another scale than the sheet."""
  cx, cy = (region["core_bbox"][0] + region["core_bbox"][2]) / 2.0, (region["core_bbox"][1] + region["core_bbox"][3]) / 2.0
  best = None
  
  for v in views_meta or []:
    b, own = v.get("bbox"), v.get("scale") or {}
    if not b or not own.get("mm_per_pt") or not (b[0] <= cx <= b[2] and b[1] <= cy <= b[3]):
      continue
    area = (b[2] - b[0]) * (b[3] - b[1])
    if best is None or area < best[0]:
      best = (area, own["mm_per_pt"])
  if best is None or abs(best[1] / f - 1.0) <= VIEW_SCALE_TOL:
    return None
  return C.note("VIEW_SCALE_DIFFERS", view_mm_per_pt=best[1], sheet_mm_per_pt=round(f, 5))

def _read_regions(index, mm_per_pt: float, regions: list, found: dict, *, started: float, budget_s: float, **kw) -> Extraction:
  """Each floor plan of a sheet that holds several drawings, read on its own: its walls, its openings, its rooms, its floor."""
  res = Extraction()
  kw.pop("level_hint", None)
  kw.pop("lowest_level", None)
  views_meta = kw.get("views_meta")
  kw["views_meta"] = None
  seen: set = set()
  merged: dict = {}
  unmapped: dict = {}
  openings: list = []
  per: list = []
  left = len(regions)
  for r in regions:
    sub = PR.sub_index(index, r)
    part = _read_sheet(sub, mm_per_pt, budget_s=max(2.0, (budget_s - (time.monotonic() - started)) / left), level_hint=r["level_hint"],
      lowest_level=False, sheet_words=index.words, outer_only=True, **kw)
    
    left -= 1
    spec = level_spec(r["level_hint"])
    scale_note = _region_scale_note(r, views_meta, mm_per_pt)
    for c in part.candidates:
      c.facts = {**(c.facts or {}), "view": PR.view_fact(r)}
      if spec and spec[0] not in c.label:
        c.label = f"{c.label} · {spec[0]}"
      if scale_note is not None:
        c.notes.append(scale_note)
        c.status = _status(c.notes)
      if c.key in seen:
        c.key = _key(c.key, r["key"])
      seen.add(c.key)
    res.candidates.extend(part.candidates)
    
    for n in part.notes:
      if n.get("code") in ("RUNS_OUTSIDE_PLAN_WALLS", "STAIR_TREADS_NOT_WALLS"):
        n["plan"] = r["caption"]
      if n not in res.notes:
        res.notes.append(n)
    for t in part.unmapped_tags:
      unmapped[t["tag"]] = unmapped.get(t["tag"], 0) + int(t["count"])
    openings.extend(part.stats.get("slab_openings") or [])
    for k, v in (part.stats.get("walls") or {}).items():
      if isinstance(v, (int, float)) and not isinstance(v, bool):
        merged[k] = round(merged.get(k, 0) + v, 3)
    by: dict = {}
    
    for c in part.candidates:
      by[c.category] = by.get(c.category, 0) + 1
    per.append({"key": r["key"], "caption": r["caption"], "level_hint": r["level_hint"], "bbox": r["bbox"], "wall_m_found": r["wall_m"],
      "items": by, "walls": (part.stats.get("walls") or {}).get("runs"), "seconds": part.stats.get("seconds")})
  res.unmapped_tags = [{"tag": t, "count": n} for t, n in sorted(unmapped.items(), key=lambda kv: (-kv[1], kv[0]))][:30]
  res.stats["walls"] = merged
  res.stats["slab_openings"] = openings
  res.stats["plan_regions"] = {**found, "count": len(regions), "plans": per}
  res.notes.insert(0, C.note("PLAN_REGIONS_READ", plans=[{"caption": r["caption"], "level_hint": r["level_hint"]} for r in regions]))
  return res

def _site_candidates(found: list, ctx: dict) -> list:
  """One candidate per site item the sheet prints (tanks, septic tank, boundary wall, gate, porch ramp). Their sizes are not drawn on a plan, so a size is
  either printed (and in params) or missing (and typed when the item is accepted)."""
  _, mode, kind = C.SUGGESTIONS["SITE"]
  out = []
  for it in found:
    notes = []
    for code, extra in it["codes"]:
      n = C.note(code, **extra)
      if extra.get("printed"):
        n["message"] += " Printed: " + extra["printed"] + "."
      notes.append(n)
    params = {"dims_basis": "SPECIFIED", **it["params"]}
    mode_of = "COUNT_X_AREA" if it["site_kind"] == "GATE" else mode
    cand = Candidate(key=_key("SITE", it["site_kind"], round(it["x"], 1), round(it["y"], 1)), category="SITE", kind=kind, quantity_mode=mode_of, label=it["label"], tag=it["tag"],
      geometry={"points": [[round(it["x"], 3), round(it["y"], 3)]]}, params=params, missing=list(it["missing"]), work_item=SI.WORK_ITEM.get(it["site_kind"]), status="VALID",
      confidence=0.0, facts=it["facts"], notes=notes, source="TAG_SCAN", count=1)
    cand.status = _status(cand.notes)
    cand.confidence = round(max(0.0, min(1.0, it["base"] * ctx["content_factor"])), 4)
    out.append(cand)
  return out

def _tank_twin_walls(res: Extraction, sites: list) -> int:
  """The walls the plan draws round a labelled tank are the concrete of the tank item too. Each says so, and so does the tank."""
  n = 0
  walls = [c for c in res.candidates if c.category == "WALL" and (c.facts or {}).get("enclosure") == "TANK"]
  for s in sites:
    kind = (s.facts or {}).get("tank_kind")
    
    if not kind:
      continue
    mine = [w for w in walls if (w.facts or {}).get("tank_kind") in (kind, "TANK")]
    if not mine:
      continue
    s.notes.append(C.note("SITE_TANK_WALLS_ALSO_LISTED", walls=len(mine)))
    s.status = _status(s.notes)
    for w in mine:
      w.notes.append(C.note("SITE_TANK_WALLS_ALSO_LISTED", tank=s.tag))
      w.status = _status(w.notes)
      n += 1
  return n

def _with_site(res: Extraction, index, mm_per_pt: float, kw: dict) -> Extraction:
  """The tanks, boundary wall, gate and ramp of the sheet, read from its whole text once (not plan by plan)."""
  ctx = {"content_factor": {"VECTOR": 1.0, "UNKNOWN": 0.95, "RASTER": 0.85}.get(kw.get("content_kind", "VECTOR"), 0.95) * (SCAN_TEXT_FACTOR if kw.get("text_source", "TEXT") == "OCR" else 1.0)}
  sites = _site_candidates(SI.find(index.words, mm_per_pt, kw.get("tank_details")), ctx)
  res.candidates.extend(sites)
  res.stats["site_items"] = {c.facts["site_kind"]: 1 for c in sites}
  res.stats["site_tank_walls"] = _tank_twin_walls(res, sites)
  return res

def run_extraction(index, mm_per_pt: float, *, composite: bool = False, regions_only: bool = False, **kw) -> Extraction:
  started = time.monotonic()
  budget_s = float(kw.get("budget_s", 25.0))
  regions, found = [], {}
  
  if sum(1 for c in VW.captions(index.words) if c["kind"] == "STRUCT_PLAN") < 2 and sheet_kind(index.words)["kind"] != "STRUCTURAL":
    try:
      regions, found = PR.find(index, mm_per_pt, started + 0.3 * budget_s, composite)
    except W.TimeLimit:
      regions, found = [], {}
  if not regions:
    if regions_only:
      res = Extraction()
      res.stats["plan_regions"] = {"count": 0}
      return res
    return _with_site(_read_sheet(index, mm_per_pt, **kw), index, mm_per_pt, kw)
  return _with_site(_read_regions(index, mm_per_pt, regions, found, started=started, budget_s=budget_s, **{k: v for k, v in kw.items() if k != "budget_s"}), index, mm_per_pt, kw)
