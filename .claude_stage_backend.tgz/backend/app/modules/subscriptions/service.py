from __future__ import annotations
import calendar
from datetime import datetime, timezone
from uuid import UUID, uuid4
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import TraceException
from app.modules.identity.models import Organization
from app.modules.subscriptions.models import BillingInterval, Subscription, SubscriptionStatus, UsageCounter, UsagePeriod
from app.modules.subscriptions.repository import SubscriptionRepository
from app.modules.subscriptions.schemas import ChangePlanRequest, UsageMetricResponse, UsageResponse
from app.modules.identity.enums import PermissionKey
from app.modules.notifications.service import NotificationService
from app.modules.notifications.schemas import NotificationType
from app.modules.audit.models import AuditAction, AuditEntityType
from app.modules.audit.service import AuditLogService
from app.shared.storage import format_bytes
import logging
from datetime import timedelta
from decimal import Decimal
from app.modules.subscriptions.models import Invoice, InvoiceStatus, Plan

logger = logging.getLogger("trace.subscriptions")

BYTE_METRICS = {"storage_bytes"}

METRIC_LABELS = {
  "storage_bytes": "Storage",
  "drawings": "Drawings",
  "projects": "Projects",
  "ai_requests": "AI requests",
  "site_photos": "Site photos",
  "calculation_runs": "Calculation runs",
}

def _metric_label(metric: str) -> str:
  return METRIC_LABELS.get(metric, metric.replace("_", " ").capitalize())

def _format_quantity(metric: str, value: int | None) -> str:
  if metric in BYTE_METRICS:
    return format_bytes(value)
  return "unlimited" if value is None else str(value)

class SubscriptionService:
  def __init__(self, session: AsyncSession):
    self.session = session
    self.repository = SubscriptionRepository(session)
    self.notifications = NotificationService(session)
    self.audit = AuditLogService(session)

  async def list_plans(self):
    return await self.repository.list_public_plans()

  async def get_subscription(
    self,
    organization_id: UUID,
  ) -> Subscription:
    subscription = await self.repository.get_subscription(
      organization_id
    )

    if subscription is None:
      raise TraceException(
        "Subscription not found.",
        status_code=404,
        code="SUBSCRIPTION_NOT_FOUND",
      )

    return subscription
  
  async def get_subscription_summary(
    self,
    organization_id: UUID,
  ):
    subscription = await self.get_subscription(
      organization_id
    )

    return subscription
  
  def _get_effective_price(self, plan: "Plan", interval: BillingInterval) -> Decimal:
   now = datetime.now(timezone.utc)
   if interval == BillingInterval.YEARLY:
    if plan.offer_ends_at and plan.offer_ends_at > now and plan.price_yearly_original is not None:
      return plan.price_yearly  
    return plan.price_yearly
   else:
    if plan.offer_ends_at and plan.offer_ends_at > now and plan.price_monthly_original is not None:
      return plan.price_monthly
    return plan.price_monthly
  
  async def create_invoice_for_subscription(
    self,
    organization_id: UUID,
    *,
    period_start: datetime | None = None,
    period_end: datetime | None = None,
    force: bool = False,
  ) -> "Invoice":

    subscription = await self.get_subscription(organization_id)
    plan = subscription.plan
    start = period_start or subscription.current_period_start
    end = period_end or subscription.current_period_end

    unit_price = self._get_effective_price(plan, subscription.billing_interval)
    quantity = subscription.quantity or 1
    subtotal = (unit_price * quantity).quantize(Decimal("0.01"))
    tax = Decimal("0") 
    total = subtotal + tax

    invoice = Invoice(
      id=uuid4(),
      organization_id=organization_id,
      subscription_id=subscription.id,
      plan_id=plan.id,
      status=InvoiceStatus.DRAFT,
      currency=plan.currency or "PKR",
      subtotal=subtotal,
      tax=tax,
      total=total,
      amount_paid=Decimal("0"),
      amount_due=total,
      period_start=start,
      period_end=end,
      due_date=end,
      provider="manual",
      line_items=[
       {
        "description": f"{plan.name} ({subscription.billing_interval.value})",
        "quantity": quantity,
        "unit_price": str(unit_price),
        "amount": str(subtotal),
       }
      ],
        metadata_={},
    )
    self.session.add(invoice)
    await self.session.flush()
    return invoice

  async def create_initial_subscription(
    self,
    organization: Organization,
    plan_slug: str = "free",
  ) -> Subscription:
    existing = await self.repository.get_subscription(
      organization.id
    )

    if existing is not None:
      return existing

    plan = await self.repository.get_plan_by_slug(
      plan_slug
    )

    if plan is None:
      raise TraceException(
        "Default subscription plan not found.",
        status_code=500,
        code="DEFAULT_PLAN_NOT_FOUND",
      )

    now = datetime.now(timezone.utc)
    billing_interval = BillingInterval.MONTHLY
    period_end = self._advance_period(now, billing_interval)

    trial_ends_at = None
    status = SubscriptionStatus.ACTIVE
    if plan.trial_days and plan.trial_days > 0 and plan.slug != "free":
      trial_ends_at = now + timedelta(days=plan.trial_days)
      status = SubscriptionStatus.TRIALING
      period_end = trial_ends_at

    subscription = Subscription(
      id=uuid4(),
      organization_id=organization.id,
      plan_id=plan.id,
      status=status,
      billing_interval=billing_interval,
      quantity=1,
      started_at=now,
      current_period_start=now,
      current_period_end=period_end,
      trial_ends_at=trial_ends_at,
      next_billing_at=period_end,
      provider="manual",
    )

    try:
      subscription = await self.repository.create_subscription(
        subscription
      )
      await self.session.commit()
    except IntegrityError:
      await self.session.rollback()
      existing = await self.repository.get_subscription(organization.id)
      if existing is not None:
        return existing
      raise TraceException(
        "Unable to create initial subscription.",
        status_code=409,
        code="SUBSCRIPTION_CREATE_CONFLICT",
      )

    return subscription
  
  async def change_plan(
    self,
    organization_id: UUID,
    payload: ChangePlanRequest,
    actor_user_id: UUID,
  ) -> Subscription:
    subscription = await self.repository.get_subscription_for_update(
     organization_id
    )
    if subscription is None:
     raise TraceException(
      "Subscription not found.",
      status_code=404,
      code="SUBSCRIPTION_NOT_FOUND",
     )
    plan = await self.repository.get_plan(payload.plan_id)
    if plan is None or not plan.is_active:
     raise TraceException(
      "Plan not found or inactive.",
      status_code=404,
      code="PLAN_NOT_AVAILABLE",
    )
    if subscription.status in {
      SubscriptionStatus.CANCELLED,
      SubscriptionStatus.EXPIRED,
    }:
      raise TraceException(
       "Cancelled or expired subscriptions cannot be changed.",
        status_code=409,
        code="SUBSCRIPTION_NOT_CHANGEABLE",
      )
      
    old_plan_id = subscription.plan_id
    old_interval = subscription.billing_interval
    old_quantity = subscription.quantity
    interval_changed = old_interval != payload.billing_interval
    quantity = getattr(payload, "quantity", None) or subscription.quantity or 1
    now = datetime.now(timezone.utc)
    total_seconds = (subscription.current_period_end - subscription.current_period_start).total_seconds()
    remaining_seconds = max((subscription.current_period_end - now).total_seconds(), 0)
    proration_factor = remaining_seconds / total_seconds if total_seconds > 0 else 0
  
    old_price = self._get_effective_price(subscription.plan, old_interval)
    new_price = self._get_effective_price(plan, payload.billing_interval)
 
    proration_credit = (old_price * old_quantity * Decimal(str(proration_factor))).quantize(Decimal("0.01"))
    proration_charge = (new_price * quantity * Decimal(str(proration_factor))).quantize(Decimal("0.01"))
    subscription.plan_id = plan.id
    subscription.billing_interval = payload.billing_interval
    subscription.quantity = quantity
    if interval_changed or quantity != old_quantity:
     subscription.next_billing_at = subscription.current_period_end
     
    await self.repository.update_subscription(subscription)
    await self.session.commit()
    await self.audit.log(
      organization_id,
      actor_user_id,
      AuditEntityType.SUBSCRIPTION,
      subscription.id,
      AuditAction.UPDATE,
      f"Changed subscription plan to {plan.name}",
      changes={
        "plan_id": {"old": str(old_plan_id), "new": str(plan.id)},
        "billing_interval": {"old": old_interval.value, "new": payload.billing_interval.value},
        "quantity": {"old": old_quantity, "new": quantity},
        "proration_credit": str(proration_credit),
        "proration_charge": str(proration_charge),
      },
    )
    
    logger.info(
     "subscription.plan_changed",
      extra={
       "organization_id": str(organization_id),
       "new_plan_id": str(plan.id),
       "billing_interval": payload.billing_interval.value,
       "quantity": quantity,
      },
    )
    return subscription

  async def cancel_subscription(
    self,
    organization_id: UUID,
    cancel_at_period_end: bool,
    actor_user_id: UUID,
    reason: str | None = None,
    feedback: str | None = None,
  ) -> Subscription:
    subscription = await self.repository.get_subscription_for_update(
      organization_id
    )

    if subscription is None:
      raise TraceException(
        "Subscription not found.",
        status_code=404,
        code="SUBSCRIPTION_NOT_FOUND",
      )
    if subscription.status in {
      SubscriptionStatus.CANCELLED,
      SubscriptionStatus.EXPIRED,
    }:
      raise TraceException(
        "Subscription is already inactive.",
        status_code=409,
        code="SUBSCRIPTION_ALREADY_INACTIVE",
      )

    if cancel_at_period_end:
      subscription.cancel_at_period_end = True
      subscription.cancellation_reason = reason
      subscription.cancellation_feedback = feedback
    
    else:
      subscription.cancel_at_period_end = False
      subscription.cancelled_at = datetime.now(timezone.utc)
      subscription.status = SubscriptionStatus.CANCELLED
      subscription.cancellation_reason = reason
      subscription.cancellation_feedback = feedback

    await self.session.flush()
    await self.session.commit()

    await self.audit.log(
      organization_id,
      actor_user_id,
      AuditEntityType.SUBSCRIPTION,
      subscription.id,
      AuditAction.UPDATE,
      "Subscription cancelled at period end" if cancel_at_period_end else "Subscription cancelled immediately",
      changes={
        "cancel_at_period_end": cancel_at_period_end,
        "reason": reason,
        "feedback": feedback,
      },
    )
    logger.info(
      "subscription.cancelled",
      extra={"organization_id": str(organization_id), "immediate": not cancel_at_period_end},
    )

    return subscription
  
  async def reactivate_subscription(
    self,
    organization_id: UUID,
    actor_user_id: UUID,
) -> Subscription:
    subscription = await self.repository.get_subscription_for_update(
      organization_id
    )

    if subscription is None:
      raise TraceException(
        "Subscription not found.",
        status_code=404,
        code="SUBSCRIPTION_NOT_FOUND",
      )

    if subscription.status in {
      SubscriptionStatus.CANCELLED,
      SubscriptionStatus.EXPIRED,
    }:
      raise TraceException(
        "Cancelled or expired subscriptions can't be reactivated this way — change to a plan instead.",
        status_code=409,
        code="SUBSCRIPTION_NOT_REACTIVATABLE",
      )

    if not subscription.cancel_at_period_end:
      raise TraceException(
        "Subscription is not scheduled for cancellation.",
        status_code=409,
        code="SUBSCRIPTION_NOT_SCHEDULED_FOR_CANCELLATION",
      )
    subscription.cancel_at_period_end = False
    await self.session.flush()
    await self.session.commit()
    
    await self.audit.log(
      organization_id,
      actor_user_id,
      AuditEntityType.SUBSCRIPTION,
      subscription.id,
      AuditAction.UPDATE,
      "Subscription reactivated (cancel_at_period_end cleared)",
    )

    logger.info(
      "subscription.reactivated",
      extra={
        "organization_id": str(organization_id),
      },
    )

    return subscription

  async def roll_subscription_if_expired(
    self,
    organization_id: UUID,
    now: datetime | None = None,
  ) -> Subscription | None:
    now = now or datetime.now(timezone.utc)
    subscription = await self.repository.get_subscription_for_update(
    organization_id
  )

    if subscription is None:
     return None
    if subscription.status in {
     SubscriptionStatus.CANCELLED,
     SubscriptionStatus.EXPIRED,
    }:
     return None

    if subscription.current_period_end > now:
     return None
    if subscription.cancel_at_period_end:
      subscription.status = SubscriptionStatus.CANCELLED
      subscription.cancelled_at = now
    if subscription.status == SubscriptionStatus.TRIALING:
      plan = subscription.plan
      if (plan.price_monthly or 0) > 0 or (plan.price_yearly or 0) > 0:
        subscription.status = SubscriptionStatus.PAST_DUE
        subscription.grace_period_ends_at = now + timedelta(days=7)
        subscription.next_billing_at = now
      else:
       subscription.status = SubscriptionStatus.EXPIRED

      if subscription.status == SubscriptionStatus.PAST_DUE:
       if subscription.grace_period_ends_at and now > subscription.grace_period_ends_at:
        subscription.status = SubscriptionStatus.EXPIRED

      subscription.current_period_start = subscription.current_period_end
      subscription.current_period_end = self._advance_period(
      subscription.current_period_start, subscription.billing_interval
     )
      subscription.next_billing_at = subscription.current_period_end
      if subscription.status == SubscriptionStatus.TRIALING:
        subscription.status = SubscriptionStatus.ACTIVE
      await self.repository.update_subscription(subscription)
      await self.session.commit()

      logger.info(
        "subscription.period_rolled",
         extra={"organization_id": str(organization_id), "new_status": subscription.status.value},
      )

      return subscription

  async def apply_provider_event(
    self,
    organization_id: UUID,
    *,
    status: SubscriptionStatus,
    provider_subscription_id: str | None = None,
    provider_customer_id: str | None = None,
  ) -> Subscription:
    subscription = await self.repository.get_subscription_for_update(organization_id)


    if subscription is None:
      raise TraceException("Subscription not found.", status_code=404, code="SUBSCRIPTION_NOT_FOUND")


    subscription.status = status
    if provider_subscription_id is not None:
      subscription.provider_subscription_id = provider_subscription_id
    if provider_customer_id is not None:
      subscription.provider_customer_id = provider_customer_id


    await self.repository.update_subscription(subscription)
    await self.session.commit()


    logger.info(
      "subscription.provider_event_applied",
      extra={"organization_id": str(organization_id), "status": status.value},
    )


    return subscription


  async def get_usage(
    self,
    organization_id: UUID,
  ) -> UsageResponse:
    subscription = await self.get_subscription(
      organization_id
    )
    counters = await self.repository.list_usage_counters(
      organization_id,
      subscription.current_period_start,
      subscription.current_period_end,
    )

    quotas = subscription.plan.quotas or {}
    metrics: list[UsageMetricResponse] = []
    for metric, limit in quotas.items():
      counter = next(
        (
          item
          for item in counters
          if item.metric == metric
        ),
        None,
      )
      used = counter.quantity if counter else 0

      if limit is None:
        remaining = None
        percentage = None
      else:
        remaining = max(int(limit) - used, 0)
        percentage = (
          100.0
          if int(limit) <= 0 and used > 0
          else (
            (used / int(limit)) * 100
            if int(limit) > 0
            else 0.0
          )
        )

      metrics.append(
        UsageMetricResponse(
          metric=metric,
          used=used,
          limit=int(limit) if limit is not None else None,
          remaining=remaining,
          percentage=percentage,
        )
      )
    return UsageResponse(
      period_start=subscription.current_period_start,
      period_end=subscription.current_period_end,
      metrics=metrics,
    )

  async def apply_provider_event(
    self,
    organization_id: UUID,
    *,
    status: SubscriptionStatus,
    provider_subscription_id: str | None = None,
    provider_customer_id: str | None = None,
  ) -> Subscription:
    subscription = await self.repository.get_subscription_for_update(organization_id)

    if subscription is None:
      raise TraceException("Subscription not found.", status_code=404, code="SUBSCRIPTION_NOT_FOUND")

    subscription.status = status
    if provider_subscription_id is not None:
      subscription.provider_subscription_id = provider_subscription_id
    if provider_customer_id is not None:
      subscription.provider_customer_id = provider_customer_id

    await self.repository.update_subscription(subscription)
    await self.session.commit()

    logger.info(
      "subscription.provider_event_applied",
      extra={"organization_id": str(organization_id), "status": status.value},
    )

    return subscription

  async def get_usage(
    self,
    organization_id: UUID,
  ) -> UsageResponse:
    subscription = await self.get_subscription(
      organization_id
    )

    counters = await self.repository.list_usage_counters(
      organization_id,
      subscription.current_period_start,
      subscription.current_period_end,
    )

    quotas = subscription.plan.quotas or {}

    metrics: list[UsageMetricResponse] = []

    for metric, limit in quotas.items():
      counter = next(
        (
          item
          for item in counters
          if item.metric == metric
        ),
        None,
      )

      used = counter.quantity if counter else 0

      if limit is None:
        remaining = None
        percentage = None
      else:
        remaining = max(int(limit) - used, 0)

        percentage = (
          100.0
          if int(limit) <= 0 and used > 0
          else (
            (used / int(limit)) * 100
            if int(limit) > 0
            else 0.0
          )
        )

      metrics.append(
        UsageMetricResponse(
          metric=metric,
          used=used,
          limit=int(limit) if limit is not None else None,
          remaining=remaining,
          percentage=percentage,
        )
      )

    return UsageResponse(
      period_start=subscription.current_period_start,
      period_end=subscription.current_period_end,
      metrics=metrics,
    )

  async def check_quota(
    self,
    organization_id: UUID,
    metric: str,
    quantity: int = 1,
  ) -> None:
    if quantity <= 0:
      raise ValueError(
        "Quantity must be greater than zero."
      )

    subscription = await self.get_subscription(
      organization_id
    )

    if subscription.status not in {
      SubscriptionStatus.TRIALING,
      SubscriptionStatus.ACTIVE,
    }:
      raise TraceException(
        "Subscription does not allow this operation.",
        status_code=402,
        code="SUBSCRIPTION_INACTIVE",
      )

    quotas = subscription.plan.quotas or {}

    if metric not in quotas:
      return

    limit = quotas[metric]
    if limit is None:
      return
    
    limit_policy = (subscription.plan.limit_policy or {}).get(metric, "hard")

    counter = await self.repository.get_usage_counter(
      organization_id,
      metric,
      subscription.current_period_start,
      subscription.current_period_end,
    )

    current_quantity = (
      counter.quantity
      if counter is not None
      else 0
    )

    if current_quantity + quantity > int(limit):
      remaining = max(int(limit) - current_quantity, 0)
      if limit_policy == "hard":
       raise TraceException(
        f"{_metric_label(metric)} limit reached. Your plan allows "
        f"{_format_quantity(metric, int(limit))} and "
        f"{_format_quantity(metric, remaining)} is left this period.",
        status_code=402,
        code="USAGE_LIMIT_EXCEEDED",
    )

  async def increment_usage(
    self,
    organization_id: UUID,
    metric: str,
    quantity: int = 1,
  ) -> UsageCounter:
    counters = await self.increment_usage_many(
      organization_id,
      {metric: quantity},
    )
    return counters[metric]
  
  async def decrement_usage(
    self,
    organization_id: UUID,
    metric: str,
    amount: int = 1,
  ) -> UsageCounter | None:
    
    if amount <= 0:
      raise ValueError(
        "Amount must be positive."
      )

    subscription = await self.get_subscription(
      organization_id
    )
    counter = await self.repository.get_usage_counter(
      organization_id,
      metric,
      subscription.current_period_start,
      subscription.current_period_end,
    )

    if counter is None:
      return None
    counter.quantity = max(
      counter.quantity - amount,
      0,
    )

    await self.session.commit()
    return counter
  
  async def increment_usage_many(
    self,
    organization_id: UUID,
    amounts: dict[str, int],
  ) -> dict[str, UsageCounter]:
    if not amounts:
      return {}

    for metric, quantity in amounts.items():
      if quantity <= 0:
        raise ValueError(
          f"Quantity for '{metric}' must be greater than zero."
        )

    subscription = await self.get_subscription(
      organization_id
    )

    if subscription.status not in {
      SubscriptionStatus.TRIALING,
      SubscriptionStatus.ACTIVE,
    }:
      raise TraceException(
        "Subscription does not allow usage.",
        status_code=402,
        code="SUBSCRIPTION_INACTIVE",
      )

    quotas = subscription.plan.quotas or {}
    counters: dict[str, UsageCounter] = {}
    warnings: list[tuple[str, int, int]] = []

    for metric, quantity in amounts.items():
      limit = quotas.get(metric)
      limit_policy = (quotas and (subscription.plan.limit_policy or {}).get(metric, "hard")) or "hard"

      counter = await self.repository.get_usage_counter(
        organization_id,
        metric,
        subscription.current_period_start,
        subscription.current_period_end,
      )

      if counter is None:
        counter = UsageCounter(
          id=uuid4(),
          organization_id=organization_id,
          metric=metric,
          period=UsagePeriod.MONTH,
          period_start=subscription.current_period_start,
          period_end=subscription.current_period_end,
          quantity=0,
        )

        counter = await self.repository.create_usage_counter(
          counter
        )

      if limit is not None and counter.quantity + quantity > int(limit):
       remaining = max(int(limit) - counter.quantity, 0)
       if limit_policy == "hard":
        raise TraceException(
         f"{_metric_label(metric)} limit reached. Your plan allows "
         f"{_format_quantity(metric, int(limit))} and "
         f"{_format_quantity(metric, remaining)} is left this period.",
         status_code=402,
         code="USAGE_LIMIT_EXCEEDED",
      )

      previous_quantity = counter.quantity
      counter.quantity += quantity
      counters[metric] = counter

      if limit is not None and int(limit) > 0:
        previous_ratio = previous_quantity / int(limit)
        new_ratio = counter.quantity / int(limit)
        if previous_ratio < 0.8 <= new_ratio:
          warnings.append((metric, counter.quantity, int(limit)))

    await self.session.flush()

    for metric, used, limit in warnings:
      await self.notifications.notify_by_permission(
        organization_id,
        str(PermissionKey.ORGANIZATION_MANAGE),
        NotificationType.SUBSCRIPTION_USAGE_WARNING,
        f"{_metric_label(metric)} usage is near your plan limit",
        body=(
          f"{_format_quantity(metric, used)} of "
          f"{_format_quantity(metric, limit)} used this billing period."
        ),
        link_path="/app/subscription",
        commit=False,
      )

    await self.session.commit()
    return counters

  @staticmethod
  def _advance_period(value: datetime, interval: BillingInterval) -> datetime:
    if interval == BillingInterval.YEARLY:
      return SubscriptionService._add_years(value, 1)
    return SubscriptionService._add_months(value, 1)

  @staticmethod
  def _add_months(value: datetime, months: int) -> datetime:
    total = value.month - 1 + months
    year = value.year + total // 12
    month = total % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return value.replace(year=year, month=month, day=day)

  @staticmethod
  def _add_years(value: datetime, years: int) -> datetime:
    year = value.year + years
    day = value.day
    if value.month == 2 and value.day == 29 and not calendar.isleap(year):
      day = 28
    return value.replace(year=year, day=day)