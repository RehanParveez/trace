from enum import StrEnum

class TokenType(StrEnum):
  ACCESS = "access"
  REFRESH = "refresh"

class UserStatus(StrEnum):
  ACTIVE = "active"
  INACTIVE = "inactive"
  LOCKED = "locked"

class PermissionKey(StrEnum):
  IDENTITY_READ = "identity.read"
  IDENTITY_MANAGE = "identity.manage"
  
  ORGANIZATION_READ = "organization.read"
  ORGANIZATION_MANAGE = "organization.manage"
  ORGANIZATION_MEMBERS_MANAGE = "organization.members.manage"
  ORGANIZATION_INVITATIONS_MANAGE = "organization.invitations.manage"
  
  PROJECT_READ = "project.read"
  PROJECT_CREATE = "project.create"
  PROJECT_UPDATE = "project.update"
  PROJECT_DELETE = "project.delete"
  PROJECT_VIEW_ALL = "project.view_all"
  
  SUBSCRIPTION_READ = "subscription.read"
  SUBSCRIPTION_MANAGE = "subscription.manage"
  SUBSCRIPTION_BILLING_MANAGE = "subscription.billing.manage"
  
  DRAWING_READ = "drawing:read"
  DRAWING_CREATE = "drawing:create"
  DRAWING_DELETE = "drawing:delete"
  
  BOQ_UPDATE = "boq:update"
  BOQ_APPROVE = "boq:approve"
  
  MATERIAL_LIBRARY_MANAGE = "material_library:manage"
  
  WHATSAPP_CHANNEL_MANAGE = "whatsapp.channel.manage"
  
  SITE_PHOTO_READ = "site_photo.read"
  SITE_PHOTO_MANAGE = "site_photo.manage"
  PROGRESS_CLAIM_READ = "progress_claim:read"
  PROGRESS_CLAIM_CREATE = "progress_claim:create"
  PROGRESS_CLAIM_UPDATE = "progress_claim:update"
  PROGRESS_CLAIM_SUBMIT = "progress_claim:submit"
  PROGRESS_CLAIM_REVIEW = "progress_claim:review"
  
  PHOTO_BOQ_LINK_READ = "photo_boq_link:read" 
  PHOTO_BOQ_LINK_MANAGE = "photo_boq_link:manage"
  BOQ_ITEM_CREATE = "boq_item_create"
  BOQ_EXPORT = "boq_export"
  LABOUR_RATE_MANAGE = "labour_rate_manage"
  
  NOTIFICATION_READ = "notification:read"
  
  AUDIT_LOG_READ = "audit_log:read"
  
  AI_REQUEST_READ = "ai_request:read"

  BUDGET_READ = "budget:read"
  BUDGET_MANAGE = "budget:manage"

  SITE_LOG_READ = "site_log:read"
  SITE_LOG_CREATE = "site_log:create"
  SITE_LOG_MANAGE = "site_log:manage"

  PROCUREMENT_READ = "procurement:read"
  PROCUREMENT_CREATE = "procurement:create"
  PROCUREMENT_MANAGE = "procurement:manage"

  EXPENSE_READ = "expense:read"
  EXPENSE_CREATE = "expense:create"
  EXPENSE_APPROVE = "expense:approve"
  
  RUNNING_BILL_READ = "running_bill:read"
  RUNNING_BILL_CREATE = "running_bill:create"
  RUNNING_BILL_ISSUE = "running_bill:issue"
  
  LABOUR_READ = "labour:read"
  LABOUR_MANAGE = "labour:manage"
  LABOUR_PAYMENT_MANAGE = "labour:payment_manage"
  
  SUBCONTRACTOR_READ = "subcontractor:read"
  SUBCONTRACTOR_MANAGE = "subcontractor:manage"
  SUBCONTRACTOR_PAYMENT_MANAGE = "subcontractor:payment_manage"
  
  WITHHOLDING_TAX_READ = "withholding_tax:read"
  WITHHOLDING_TAX_MANAGE = "withholding_tax:manage"

  MATERIAL_STOCK_READ = "material_stock:read"
  MATERIAL_STOCK_MANAGE = "material_stock:manage"
  
  RETENTION_READ = "retention:read"
  RETENTION_MANAGE = "retention:manage"
  
  CHANGE_ORDER_READ = "change_order:read"
  CHANGE_ORDER_CREATE = "change_order:create"
  CHANGE_ORDER_APPROVE = "change_order:approve"
  
  SCHEDULE_READ = "schedule:read"
  SCHEDULE_MANAGE = "schedule:manage"
  
  PUNCH_LIST_READ = "punch_list:read"
  PUNCH_LIST_MANAGE = "punch_list:manage"
  
  SALES_TAX_READ = "sales_tax:read"
  SALES_TAX_MANAGE = "sales_tax:manage"
  
  BANK_GUARANTEE_READ = "bank_guarantee:read"
  BANK_GUARANTEE_MANAGE = "bank_guarantee:manage"
  BANK_GUARANTEE_RELEASE = "bank_guarantee:release"
  
  CASH_FLOW_READ = "cash_flow:read"
  CASH_FLOW_MANAGE = "cash_flow:manage"
  
  RULESET_MANAGE = "ruleset:manage"
  RULESET_PUBLISH = "ruleset:publish"
  
  CALC_RUN = "calc:run"
  
  BOQ_ADJUST = "boq:adjust"
  BOQ_ISSUE = "boq:issue"
  REVIEW_RESOLVE = "review:resolve"
  
  SPACE_MANAGE = "space:manage"
  FINISH_MANAGE = "finish:manage"
  SCHEDULE_IMPORT = "schedule:import"
  RATEBOOK_MANAGE = "ratebook:manage"
  