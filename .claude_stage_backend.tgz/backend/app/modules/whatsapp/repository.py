from __future__ import annotations
from datetime import date, datetime
from uuid import UUID
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from app.modules.whatsapp.models import PhotoTag, SitePhoto, WhatsAppChannel, WhatsAppMessage, WhatsAppSender

class WhatsAppChannelRepository:
  def __init__(self, session: AsyncSession):
    self.session = session

  async def create(
    self,
    channel: WhatsAppChannel,
  ) -> WhatsAppChannel:
    self.session.add(channel)
    await self.session.flush()
    return channel

  async def get_by_organization(
    self,
    organization_id: UUID,
  ) -> WhatsAppChannel | None:
    result = await self.session.execute(
      select(WhatsAppChannel).where(
        WhatsAppChannel.organization_id == organization_id,
      )
    )
    return result.scalar_one_or_none()

  async def get_by_phone_number_id(
    self,
    phone_number_id: str,
  ) -> WhatsAppChannel | None:
    result = await self.session.execute(
      select(WhatsAppChannel).where(
        WhatsAppChannel.phone_number_id == phone_number_id,
        WhatsAppChannel.is_active.is_(True),
      )
    )
    return result.scalar_one_or_none()
  
  async def get_by_phone_number_id_any_status(
    self,
    phone_number_id: str,
  ) -> WhatsAppChannel | None:
    result = await self.session.execute(
      select(WhatsAppChannel).where(
        WhatsAppChannel.phone_number_id == phone_number_id,
      )
    )
    return result.scalar_one_or_none()

  async def update(
    self,
    channel: WhatsAppChannel,
  ) -> WhatsAppChannel:
    self.session.add(channel)
    await self.session.flush()
    return channel

class WhatsAppMessageRepository:
  def __init__(self, session: AsyncSession):
    self.session = session

  async def try_create(
    self,
    message: WhatsAppMessage,
) -> WhatsAppMessage | None:
    self.session.add(message)

    try:
      async with self.session.begin_nested():
        await self.session.flush()
    except IntegrityError:
      return None

    return message
  
  async def get_by_id_unscoped(
    self,
    message_id: UUID,
  ) -> WhatsAppMessage | None:
    result = await self.session.execute(
      select(WhatsAppMessage).where(
        WhatsAppMessage.id == message_id,
      )
    )
    return result.scalar_one_or_none()

  async def get_by_id(
    self,
    message_id: UUID,
    organization_id: UUID,
  ) -> WhatsAppMessage | None:
    result = await self.session.execute(
      select(WhatsAppMessage).where(
       WhatsAppMessage.id == message_id,
       WhatsAppMessage.organization_id == organization_id,
      )
    )
    return result.scalar_one_or_none()
  
  async def get_by_id_for_update(
    self,
    message_id: UUID,
    organization_id: UUID,
  ) -> WhatsAppMessage | None:
   result = await self.session.execute(
    select(WhatsAppMessage)
    .where(WhatsAppMessage.id == message_id,
      WhatsAppMessage.organization_id == organization_id,       
    )
    .with_for_update()
  )

   return result.scalar_one_or_none()

  async def get_by_prompt_wa_message_id(
    self,
    prompt_wa_message_id: str,
    organization_id: UUID,
  ) -> WhatsAppMessage | None:
    result = await self.session.execute(
      select(WhatsAppMessage).where(
        WhatsAppMessage.prompt_wa_message_id == prompt_wa_message_id,
        WhatsAppMessage.organization_id == organization_id,
      )
    )
    return result.scalar_one_or_none()

  async def update(
    self,
    message: WhatsAppMessage,
  ) -> WhatsAppMessage:
    self.session.add(message)
    await self.session.flush()
    return message

class SitePhotoRepository:
  def __init__(self, session: AsyncSession):
    self.session = session

  async def create(
    self,
    photo: SitePhoto,
  ) -> SitePhoto:
    self.session.add(photo)
    await self.session.flush()
    return photo

  async def get_by_id_and_org(
    self,
    photo_id: UUID,
    organization_id: UUID,
  ) -> SitePhoto | None:
    result = await self.session.execute(
      select(SitePhoto)
      .where(
        SitePhoto.id == photo_id,
        SitePhoto.organization_id == organization_id,
      )
      .options(selectinload(SitePhoto.tags))
    )
    return result.scalar_one_or_none()

  async def get_by_whatsapp_message_id(
    self,
    whatsapp_message_id: UUID,
    organization_id: UUID,
  ) -> SitePhoto | None:
    result = await self.session.execute(
      select(SitePhoto).where(
        SitePhoto.whatsapp_message_id == whatsapp_message_id,
        SitePhoto.organization_id == organization_id,
      )
    )
    return result.scalar_one_or_none()

  async def list_by_org(
    self,
    organization_id: UUID,
    *,
    project_id: UUID | None = None,
    photo_date_from: date | None = None,
    photo_date_to: date | None = None,
    tag: str | None = None,
    unassigned_only: bool = False,
    skip: int = 0,
    limit: int = 100,
  ) -> list[SitePhoto]:
    query = (
      select(SitePhoto)
      .where(SitePhoto.organization_id == organization_id)
      .options(selectinload(SitePhoto.tags))
    )

    if project_id is not None:
      query = query.where(SitePhoto.project_id == project_id)
    if unassigned_only:                                 
      query = query.where(SitePhoto.project_id.is_(None))
    if photo_date_from is not None:
      query = query.where(SitePhoto.photo_date >= photo_date_from)
    if photo_date_to is not None:
      query = query.where(SitePhoto.photo_date <= photo_date_to)
    if tag is not None:
      query = query.join(PhotoTag).where(PhotoTag.tag == tag)

    query = (
      query.order_by(SitePhoto.created_at.desc())
      .offset(skip)
      .limit(limit)
    )

    result = await self.session.execute(query)
    return list(result.scalars().unique())

  async def get_latest_by_project(
    self,
    organization_id: UUID,
  ) -> list[SitePhoto]:
    result = await self.session.execute(
      select(SitePhoto)
      .distinct(SitePhoto.project_id)
      .where(
        SitePhoto.organization_id == organization_id,
        SitePhoto.project_id.is_not(None),
      )
      .order_by(SitePhoto.project_id, SitePhoto.created_at.desc())
    )
    return list(result.scalars().unique())

  async def update(
    self,
    photo: SitePhoto,
  ) -> SitePhoto:
    self.session.add(photo)
    await self.session.flush()
    return photo

class PhotoTagRepository:
  def __init__(self, session: AsyncSession):
    self.session = session

  async def create(
    self,
    tag: PhotoTag,
  ) -> PhotoTag:
    self.session.add(tag)
    await self.session.flush()
    return tag

  async def bulk_create(
    self,
    tags: list[PhotoTag],
  ) -> list[PhotoTag]:
    self.session.add_all(tags)
    await self.session.flush()
    return tags

  async def delete(
    self,
    tag: PhotoTag,
  ) -> None:
    await self.session.delete(tag)
    await self.session.flush()
    
class WhatsAppSenderRepository:
  def __init__(self, session: AsyncSession):
    self.session = session

  async def list_by_org(self, organization_id: UUID) -> list[WhatsAppSender]:
    result = await self.session.execute(
      select(WhatsAppSender)
      .where(WhatsAppSender.organization_id == organization_id)
      .order_by(WhatsAppSender.display_name.asc())
    )
    return list(result.scalars().all())

  async def get_by_id(self, sender_id: UUID, organization_id: UUID) -> WhatsAppSender | None:
    result = await self.session.execute(
      select(WhatsAppSender).where(
        WhatsAppSender.id == sender_id, WhatsAppSender.organization_id == organization_id,
      )
    )
    return result.scalar_one_or_none()

  async def get_by_phone(self, organization_id: UUID, phone_number: str) -> WhatsAppSender | None:
    result = await self.session.execute(
      select(WhatsAppSender).where(
        WhatsAppSender.organization_id == organization_id, WhatsAppSender.phone_number == phone_number,
      )
    )
    return result.scalar_one_or_none()

  async def create(self, sender: WhatsAppSender) -> WhatsAppSender:
    self.session.add(sender)
    await self.session.flush()
    return sender

  async def delete(self, sender: WhatsAppSender) -> None:
    await self.session.delete(sender)
    await self.session.flush()

  async def get_recent_project_for_sender(
    self, organization_id: UUID, phone_number: str, since: datetime,
  ) -> UUID | None:
    result = await self.session.execute(
      select(SitePhoto.project_id)
      .where(
        SitePhoto.organization_id == organization_id,
        SitePhoto.sender_phone_number == phone_number,
        SitePhoto.project_id.isnot(None),
        SitePhoto.created_at >= since,
      )
      .order_by(SitePhoto.created_at.desc())
      .limit(1)
    )
    return result.scalar_one_or_none()
    