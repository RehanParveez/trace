from __future__ import annotations
import json
from uuid import UUID
from fastapi import APIRouter, Depends, Query, Request, Response, status, Form, File, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.dependencies.permissions import require_permission
from app.modules.identity.enums import PermissionKey
from app.modules.identity.models import User
from app.modules.whatsapp.schemas import (SenderCreateRequest, SenderResponse, SenderUpdateRequest, ChannelConnectRequest, ChannelResponse, PhotoTagCreateRequest, PhotoTagResponse, ProjectPhotoThumbnailResponse, SitePhotoAssignProjectRequest, 
  SitePhotoUrlResponse, SitePhotoResponse, SitePhotoUpdateRequest,
)
from app.modules.whatsapp.service import WhatsAppService
from datetime import date
from app.dependencies.rate_limit import rate_limit_webhook

router = APIRouter(
  prefix="/whatsapp",
  tags=["WhatsApp & Site Photos"],
)

def _service(session: AsyncSession) -> WhatsAppService:
  return WhatsAppService(session)

@router.get("/webhook")
async def verify_webhook(
  hub_mode: str | None = Query(default=None, alias="hub.mode"),
  hub_verify_token: str | None = Query(default=None, alias="hub.verify_token"),
  hub_challenge: str | None = Query(default=None, alias="hub.challenge"),
):
  if WhatsAppService.verify_subscription_challenge(hub_mode, hub_verify_token):
    return Response(content=hub_challenge or "", media_type="text/plain")
  return Response(status_code=403)

@router.post("/webhook")
async def receive_webhook(
  request: Request,
  session: AsyncSession = Depends(get_db),
  _rate_limit: None = Depends(rate_limit_webhook()),
):
  raw_body = await request.body()
  signature = request.headers.get("X-Hub-Signature-256")
  if not WhatsAppService.verify_signature(raw_body, signature):
    return Response(status_code=403)
  try:
    payload = json.loads(raw_body)
  except json.JSONDecodeError:
    return Response(status_code=400)
  service = _service(session)
  await service.handle_webhook_payload(payload)
  return {"status": "received"}

@router.post(
  "/channel",
  response_model=ChannelResponse,
  status_code=status.HTTP_201_CREATED,
)
async def connect_channel(
  payload: ChannelConnectRequest,
  current_user: User = Depends(
    require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.connect_channel(
    current_user.active_membership.organization_id,
    payload,
    current_user.id,
  )

@router.get("/senders", response_model=list[SenderResponse])
async def list_senders(
  current_user: User = Depends(require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)),
  session: AsyncSession = Depends(get_db),
):
  return await _service(session).list_senders(current_user.active_membership.organization_id)

@router.post("/senders", response_model=SenderResponse, status_code=status.HTTP_201_CREATED)
async def create_sender(
  payload: SenderCreateRequest,
  current_user: User = Depends(require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)),
  session: AsyncSession = Depends(get_db),
):
  return await _service(session).create_sender(current_user.active_membership.organization_id, payload)

@router.patch("/senders/{sender_id}", response_model=SenderResponse)
async def update_sender(
  sender_id: UUID,
  payload: SenderUpdateRequest,
  current_user: User = Depends(require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)),
  session: AsyncSession = Depends(get_db),
):
  return await _service(session).update_sender(
    current_user.active_membership.organization_id, sender_id, payload,
  )

@router.delete("/senders/{sender_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_sender(
  sender_id: UUID,
  current_user: User = Depends(require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)),
  session: AsyncSession = Depends(get_db),
):
  await _service(session).delete_sender(current_user.active_membership.organization_id, sender_id)

@router.get("/channel", response_model=ChannelResponse)
async def get_channel(
  current_user: User = Depends(
    require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.get_channel(current_user.active_membership.organization_id)

@router.delete("/channel", status_code=status.HTTP_204_NO_CONTENT)
async def disconnect_channel(
  current_user: User = Depends(
    require_permission(PermissionKey.WHATSAPP_CHANNEL_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  await service.disconnect_channel(
    current_user.active_membership.organization_id,
    current_user.id,
  )

@router.get("/photos", response_model=list[SitePhotoResponse])
async def list_photos(
  project_id: UUID | None = Query(default=None),
  tag: str | None = Query(default=None),
  photo_date_from: date | None = Query(default=None),
  photo_date_to: date | None = Query(default=None),
  unassigned_only: bool = Query(default=False),
  skip: int = Query(default=0, ge=0),
  limit: int = Query(default=100, ge=1, le=100),
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_READ)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.list_photos(
    current_user.active_membership.organization_id,
    project_id=project_id,
    tag=tag,
    photo_date_from=photo_date_from,
    photo_date_to=photo_date_to,
    unassigned_only=unassigned_only,
    skip=skip,
    limit=limit,
  )
  
@router.post(
  "/photos/upload",
  response_model=SitePhotoResponse,
  status_code=status.HTTP_201_CREATED,
)
async def upload_photo(
  project_id: UUID = Form(...),
  file: UploadFile = File(...),
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  return await _service(session).upload_photo(
    organization_id=current_user.active_membership.organization_id,
    project_id=project_id,
    user_id=current_user.id,
    file=file,
  )

@router.get(
  "/photos/latest-by-project",
  response_model=list[ProjectPhotoThumbnailResponse],
)
async def get_latest_photo_by_project(
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_READ)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.get_latest_photo_by_project(
    current_user.active_membership.organization_id,
  )

@router.get("/photos/{photo_id}", response_model=SitePhotoResponse)
async def get_photo(
  photo_id: UUID,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_READ)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.get_photo(
    current_user.active_membership.organization_id, photo_id
  )

@router.get("/photos/{photo_id}/url", response_model=SitePhotoUrlResponse)
async def get_photo_url(
  photo_id: UUID,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_READ)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.get_photo_url(
    current_user.active_membership.organization_id, photo_id
  )

@router.patch("/photos/{photo_id}", response_model=SitePhotoResponse)
async def update_photo(
  photo_id: UUID,
  payload: SitePhotoUpdateRequest,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.update_photo(
    current_user.active_membership.organization_id,
    photo_id,
    payload,
    current_user.id,
  )

@router.post(
  "/photos/{photo_id}/assign-project",
  response_model=SitePhotoResponse,
)
async def assign_project(
  photo_id: UUID,
  payload: SitePhotoAssignProjectRequest,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.assign_project(
    current_user.active_membership.organization_id,
    photo_id,
    payload,
    current_user.id,
  )

@router.post(
  "/photos/{photo_id}/tags",
  response_model=PhotoTagResponse,
  status_code=status.HTTP_201_CREATED,
)
async def add_tag(
  photo_id: UUID,
  payload: PhotoTagCreateRequest,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  return await service.add_tag(
    current_user.active_membership.organization_id,
    photo_id,
    payload,
    current_user.id,
  )

@router.delete(
  "/photos/{photo_id}/tags/{tag_id}",
  status_code=status.HTTP_204_NO_CONTENT,
)
async def remove_tag(
  photo_id: UUID,
  tag_id: UUID,
  current_user: User = Depends(
    require_permission(PermissionKey.SITE_PHOTO_MANAGE)
  ),
  session: AsyncSession = Depends(get_db),
):
  service = _service(session)
  await service.remove_tag(
    current_user.active_membership.organization_id,
    photo_id,
    tag_id,
    current_user.id,
  )