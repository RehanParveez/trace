from __future__ import annotations
import asyncio
import hashlib
import hmac
import re
from datetime import date, datetime, timedelta, timezone
from app.shared.timeutils import to_local_date
from io import BytesIO
from typing import Any
from uuid import UUID, uuid4
import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.core.exceptions import TraceException
from app.modules.identity.models import Organization
from app.modules.projects.models import ProjectStatus
from app.modules.projects.repository import ProjectRepository
from app.modules.subscriptions.service import SubscriptionService
from app.modules.whatsapp.models import PhotoTag, PhotoTagSource, SitePhoto, WhatsAppChannel, WhatsAppMessage, WhatsAppMessageStatus, WhatsAppMessageType, WhatsAppSender
from app.modules.whatsapp.repository import PhotoTagRepository, SitePhotoRepository, WhatsAppChannelRepository, WhatsAppMessageRepository, WhatsAppSenderRepository
from app.modules.whatsapp.schemas import SenderCreateRequest, SenderUpdateRequest, ChannelConnectRequest
from app.modules.whatsapp.schemas import ChannelConnectRequest, PhotoTagCreateRequest, ProjectPhotoThumbnailResponse, SitePhotoAssignProjectRequest, SitePhotoUpdateRequest, SitePhotoResponse, SitePhotoUrlResponse, PhotoTagResponse
from app.shared.storage import build_site_photo_storage_key, delete_object, generate_presigned_url, object_exists, upload_fileobj
from app.modules.whatsapp.tasks import process_whatsapp_photo_task
from app.modules.notifications.service import NotificationService
from app.modules.notifications.schemas import NotificationType
from app.modules.audit.models import AuditAction, AuditEntityType
from app.modules.audit.service import AuditLogService
from app.dependencies.tenancy import scope_session_as_platform_admin, scope_session_to_org
from app.modules.identity.enums import PermissionKey
import logging
from fastapi import UploadFile

logger = logging.getLogger(__name__)

GRAPH_API_BASE = (
  f"https://graph.facebook.com/{settings.whatsapp_graph_api_version}"
)
MAX_QUICK_REPLY_PROJECTS = 3
STICKY_PROJECT_WINDOW = timedelta(hours=2)

def normalize_phone_number(raw: str) -> str:
  digits = re.sub(r"\D", "", raw or "")
  if digits.startswith("00"):
    digits = digits[2:]
  if digits.startswith("0") and len(digits) == 11:
    digits = "92" + digits[1:]
  return digits

def match_project_in_caption(projects: list, caption: str) -> UUID | None:
  text = caption.lower()
  hits = []
  for project in projects:
    if project.status != ProjectStatus.ACTIVE:
      continue
    code = (project.code or "").strip().lower()
    name = project.name.strip().lower()
    code_hit = bool(code) and re.search(r"(?<![a-z0-9])" + re.escape(code) + r"(?![a-z0-9])", text) is not None
    if code_hit or (name and name in text):
      hits.append(project.id)
  return hits[0] if len(hits) == 1 else None

class WhatsAppService:
  def __init__(self, session: AsyncSession):
    self.session = session
    self.channels = WhatsAppChannelRepository(session)
    self.messages = WhatsAppMessageRepository(session)
    self.photos = SitePhotoRepository(session)
    self.tags = PhotoTagRepository(session)
    self.projects = ProjectRepository(session)
    self.senders = WhatsAppSenderRepository(session)
    self.subscriptions = SubscriptionService(session)
    self.notifications = NotificationService(session)
    self.audit = AuditLogService(session)

  async def connect_channel(
    self,
    organization_id: UUID,
    payload: ChannelConnectRequest,
    user_id: UUID,
  ) -> WhatsAppChannel:
    existing = await self.channels.get_by_organization(organization_id)
    if existing is not None and existing.is_active:
      raise TraceException(
        "This organization already has a connected WhatsApp channel.",
        status_code=409,
        code="WHATSAPP_CHANNEL_ALREADY_EXISTS",
      )

    conflicting = await self.channels.get_by_phone_number_id_any_status(
      payload.phone_number_id
    )
    if conflicting is not None and conflicting.organization_id != organization_id:
      raise TraceException(
        "This WhatsApp phone number is already connected to another organization.",
        status_code=409,
        code="WHATSAPP_PHONE_NUMBER_ALREADY_CONNECTED",
      )

    if existing is not None:
      existing.phone_number_id = payload.phone_number_id
      existing.business_account_id = payload.business_account_id
      existing.display_phone_number = payload.display_phone_number
      existing.access_token = payload.access_token
      existing.is_active = True
      channel = await self.channels.update(existing)
    else:
      channel = WhatsAppChannel(
        id=uuid4(),
        organization_id=organization_id,
        phone_number_id=payload.phone_number_id,
        business_account_id=payload.business_account_id,
        display_phone_number=payload.display_phone_number,
        access_token=payload.access_token,
        is_active=True,
      )
      channel = await self.channels.create(channel)

    await self.session.commit()
    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.WHATSAPP_CHANNEL,
      channel.id,
      AuditAction.CREATE,
      f"Connected WhatsApp number {channel.display_phone_number or channel.phone_number_id}",
    )

    return channel

  async def get_channel(
    self,
    organization_id: UUID,
  ) -> WhatsAppChannel:
    channel = await self.channels.get_by_organization(organization_id)
    if channel is None:
      raise TraceException(
        "No WhatsApp channel connected for this organization.",
        status_code=404,
        code="WHATSAPP_CHANNEL_NOT_FOUND",
      )
    return channel

  async def disconnect_channel(
    self,
    organization_id: UUID,
    user_id: UUID,
  ) -> None:
    channel = await self.get_channel(organization_id)
    channel.is_active = False
    await self.channels.update(channel)
    await self.session.commit()

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.WHATSAPP_CHANNEL,
      channel.id,
      AuditAction.UPDATE,
      (
        f"Disconnected WhatsApp number "
        f"{channel.display_phone_number or channel.phone_number_id}"
      ),
    )

  @staticmethod
  def verify_subscription_challenge(
    mode: str | None,
    verify_token: str | None,
  ) -> bool:
    return (
      mode == "subscribe"
      and verify_token is not None
      and hmac.compare_digest(
        verify_token, settings.whatsapp_webhook_verify_token
      )
    )

  @staticmethod
  def verify_signature(
    raw_body: bytes,
    signature_header: str | None,
  ) -> bool:
    if not signature_header or not signature_header.startswith("sha256="):
      return False

    expected = hmac.new(
      settings.whatsapp_app_secret.encode("utf-8"),
      raw_body,
      hashlib.sha256,
    ).hexdigest()

    provided = signature_header.removeprefix("sha256=")
    return hmac.compare_digest(expected, provided)
  
  
  async def handle_webhook_payload(
    self,
    payload: dict,
) -> None:
    for entry in payload.get("entry", []):
      for change in entry.get("changes", []):
        value = change.get("value", {})
        phone_number_id = (
          value.get("metadata", {})
          .get("phone_number_id")
        )

        if not phone_number_id:
          continue

        await scope_session_as_platform_admin(self.session)
        channel = await self.channels.get_by_phone_number_id(
          phone_number_id
        )
        if channel is None:
          logger.warning(
            "whatsapp_webhook_unknown_or_inactive_channel",
            extra={"phone_number_id": phone_number_id},
          )
          continue
        await scope_session_to_org(
          self.session,
          channel.organization_id,
        )
        for raw_message in value.get("messages", []):
          await self._handle_inbound_message(
            channel,
            raw_message,
        )

  async def _handle_inbound_message(
   self,
   channel: WhatsAppChannel,
   raw_message: dict,
  ) -> None:
   wa_message_id = raw_message.get("id")
   if not wa_message_id:
    return

   message_type_raw = raw_message.get("type", "")

   from_phone_number = raw_message.get("from", "")
   timestamp = raw_message.get("timestamp")
   received_at = (
    datetime.fromtimestamp(int(timestamp), tz=timezone.utc)
    if timestamp
    else datetime.now(timezone.utc)
   )

   if message_type_raw == "image":
    message_type = WhatsAppMessageType.IMAGE
    media_id = raw_message.get("image", {}).get("id")
    caption_text = raw_message.get("image", {}).get("caption")
   elif message_type_raw == "text":
    message_type = WhatsAppMessageType.TEXT
    media_id = None
    caption_text = raw_message.get("text", {}).get("body")
   elif message_type_raw == "interactive":
    message_type = WhatsAppMessageType.INTERACTIVE
    media_id = None
    caption_text = None
   else:
    message_type = WhatsAppMessageType.OTHER
    media_id = None
    caption_text = None

   message = WhatsAppMessage(
    id=uuid4(),
    organization_id=channel.organization_id,
    channel_id=channel.id,
    wa_message_id=wa_message_id,
    from_phone_number=from_phone_number,
    message_type=message_type,
    caption_text=caption_text,
    media_id=media_id,
    status=WhatsAppMessageStatus.RECEIVED,
    received_at=received_at,
    raw_payload=raw_message,
   )

   created = await self.messages.try_create(message)
   if created is None:
    return

   await self.session.commit()

   allowed, _sender = await self._check_sender(channel.organization_id, from_phone_number)
   if not allowed:
    created.status = WhatsAppMessageStatus.IGNORED
    created.error_message = "Sender is not on this organization's approved WhatsApp sender list."
    await self.messages.update(created)
    await self.session.commit()
    return

   if message_type == WhatsAppMessageType.IMAGE:
    process_whatsapp_photo_task.apply_async(
      args=[str(created.id)],
      queue="whatsapp_priority",
    )
   elif message_type == WhatsAppMessageType.INTERACTIVE:
    await self._handle_interactive_reply(created)
    created.status = WhatsAppMessageStatus.IGNORED
    await self.messages.update(created)
    await self.session.commit()
   else:
    created.status = WhatsAppMessageStatus.IGNORED
    await self.messages.update(created)
    await self.session.commit()

  async def _handle_interactive_reply(
   self,
   interactive_message: WhatsAppMessage,
  ) -> None:
   raw_message = interactive_message.raw_payload

   interactive = raw_message.get("interactive", {})
   button_reply = (
    interactive.get("button_reply")
    or interactive.get("list_reply")
   )

   if not button_reply:
    return

   context_id = raw_message.get("context", {}).get("id")
   if not context_id:
    return

   pending_message = await self.messages.get_by_prompt_wa_message_id(
    context_id, interactive_message.organization_id,
   )

   if pending_message is None:
    return

   if pending_message.status != WhatsAppMessageStatus.AWAITING_PROJECT_SELECTION:
    return

   try:
    project_uuid = UUID(button_reply.get("id", ""))
   except (ValueError, TypeError):
    return

   project = await self.projects.get_by_id_and_org(
    project_uuid,
    pending_message.organization_id,
  )

   if project is None:
    return

   await self._finalize_photo_for_message(
    pending_message,
    project.id,
  )
   
  async def upload_photo(
    self,
    organization_id: UUID,
    project_id: UUID,
    user_id: UUID,
    file: UploadFile,
    *,
    location_text: str | None = None,
    photo_date: date | None = None,
  ) -> SitePhotoResponse:
    project = await self.projects.get_by_id_and_org(
    project_id,
    organization_id,
  )
    if project is None:
      raise TraceException(
       "Project not found in this organization.",
        status_code=404,
        code="PROJECT_NOT_FOUND",
      )

    mime_type = (file.content_type or "").strip().lower()
    try:
      extension = _extension_for_mime_type(mime_type)
    except ValueError as exc:
      raise TraceException(
        "Upload a JPEG, PNG, or WebP image.",
        status_code=415,
        code="UNSUPPORTED_PHOTO_TYPE",
        ) from exc

    max_bytes = settings.whatsapp_max_photo_bytes
    contents = await file.read(max_bytes + 1)

    if not contents:
      raise TraceException(
        "The uploaded image is empty.",
        status_code=422,
        code="EMPTY_UPLOAD",
      )

    if len(contents) > max_bytes:
      raise TraceException(
        "The image exceeds the maximum upload size.",
        status_code=413,
        code="PHOTO_TOO_LARGE",
      )

    await self.subscriptions.check_quota(
      organization_id,
      "site_photos",
    )
    await self.subscriptions.check_quota(
      organization_id,
      "storage_bytes",
      len(contents),
    )

    storage_key = build_site_photo_storage_key(
      organization_id,
      f"{uuid4().hex}{extension}",
      project_id,
    )
    try:
      await asyncio.to_thread(
        upload_fileobj,
        storage_key,
        BytesIO(contents),
        mime_type,
      )

      photo = SitePhoto(
        id=uuid4(),
        organization_id=organization_id,
        project_id=project_id,
        whatsapp_message_id=None,
        storage_key=storage_key,
        sender_phone_number=None,
        caption_raw=None,
        caption_parsed={},
        location_text=location_text.strip() if location_text else None,
        photo_date=photo_date,
        is_ai_tagged=False,
      )

      await self.photos.create(photo)
      await self.subscriptions.increment_usage_many(
        organization_id,
        {
          "site_photos": 1,
          "storage_bytes": len(contents),
        },
      )
      await self.session.commit()
    except Exception:
      await self.session.rollback()
      try:
        await asyncio.to_thread(delete_object, storage_key)
      except Exception:
        pass
      raise

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.SITE_PHOTO,
      photo.id,
      AuditAction.CREATE,
      f"Uploaded site photo {photo.id}",
    )

    photo = await self.photos.get_by_id_and_org(photo.id, organization_id)
    if photo is None:
      raise TraceException(
        "Uploaded photo could not be reloaded.",
        status_code=500,
        code="SITE_PHOTO_RESPONSE_LOAD_FAILED",
    )

    return _to_photo_response(photo)

  async def _finalize_photo_for_message(
    self,
    message: WhatsAppMessage,
    project_id: UUID,
  ) -> None:
    photo = await self.photos.get_by_whatsapp_message_id(message.id, message.organization_id)
    if photo is None:
      return

    photo.project_id = project_id
    await self.photos.update(photo)

    message.status = WhatsAppMessageStatus.PROCESSED
    message.processed_at = datetime.now(timezone.utc)
    await self.messages.update(message)

    await self.session.commit()

  async def process_photo_message(self, message_id: UUID) -> None:
    message = await self.messages.get_by_id_unscoped(message_id)
    if message is None:
      return
    message = await self.messages.get_by_id_for_update(
      message_id,
      message.organization_id,
    )
    if message is None:
      return
    if message.status != WhatsAppMessageStatus.RECEIVED:
      return

    channel = await self.channels.get_by_organization(message.organization_id)
    if channel is None or not channel.is_active:
      message.status = WhatsAppMessageStatus.FAILED
      message.error_message = "WhatsApp channel is no longer connected."
      await self.messages.update(message)
      await self.session.commit()
      return

    existing_photo = await self.photos.get_by_whatsapp_message_id(
      message.id,
      message.organization_id,        
    )
    if existing_photo is not None:
      message.status = WhatsAppMessageStatus.PROCESSED
      message.processed_at = datetime.now(timezone.utc)
      await self.messages.update(message)
      await self.session.commit()
      return

    try:
      await self.subscriptions.check_quota(
        message.organization_id, "site_photos"
      )
      await self.subscriptions.check_quota(
        message.organization_id,
        "storage_bytes",
        settings.whatsapp_max_photo_bytes,
      )
    except TraceException as exc:
      message.status = WhatsAppMessageStatus.FAILED
      message.error_message = str(exc)[:2000]
      await self.messages.update(message)
      await self.session.commit()
      return

    message.status = WhatsAppMessageStatus.MEDIA_DOWNLOADING
    await self.messages.update(message)
    await self.session.commit()

    try:
      try:
        media_bytes, mime_type = await _download_whatsapp_media(
          channel.access_token, message.media_id
        )
      except Exception:
        await asyncio.sleep(3)
        media_bytes, mime_type = await _download_whatsapp_media(
          channel.access_token, message.media_id
        )
    except Exception as exc:
      message.status = WhatsAppMessageStatus.FAILED
      message.error_message = f"Media download failed: {exc}"[:2000]
      await self.messages.update(message)
      await self.session.commit()
      return

    photo_size_bytes = len(media_bytes)
    organization_id = message.organization_id

    try:
      await self.subscriptions.check_quota(
        message.organization_id, "storage_bytes", photo_size_bytes
      )
    except TraceException as exc:
      message.status = WhatsAppMessageStatus.FAILED
      message.error_message = str(exc)[:2000]
      await self.messages.update(message)
      await self.session.commit()
      await self.notifications.notify_by_permission(
        message.organization_id,
        str(PermissionKey.ORGANIZATION_MANAGE),
        NotificationType.SUBSCRIPTION_USAGE_WARNING,
        "A site photo was rejected — storage is full",
        body=(
          "Incoming WhatsApp photos are being dropped because your plan's "
          "storage limit is reached. Upgrade or free up space to resume."
        ),
        link_path="/app/subscription",
      )
      return

    storage_key: str | None = None

    try:
      mime_type = mime_type.strip().lower()
      extension = _extension_for_mime_type(mime_type)

      storage_key = build_site_photo_storage_key(
      message.organization_id,
      f"{message.id}{extension}",
     )

      await asyncio.to_thread(
       upload_fileobj,
       storage_key,
       BytesIO(media_bytes),
       mime_type,
     )

      caption_parsed: dict[str, Any] = {}
      project_match: UUID | None = None
      photo_date = to_local_date(message.received_at)

      caption_text = (message.caption_text or "")[:2000]

      if caption_text and await self._is_ai_enabled(message.organization_id):
       caption_parsed = await _parse_caption(caption_text) or {}

       if not isinstance(caption_parsed, dict):
        caption_parsed = {}

       parsed = _parse_photo_date(caption_parsed.get("date"))
       if parsed is not None:
        photo_date = parsed

       project_name_guess = caption_parsed.get("project")

       if project_name_guess:
        project_match = await self._match_project_by_name(
          message.organization_id,
          project_name_guess,
        )

      if project_match is None:
        project_match = await self._resolve_project_for_photo(message, caption_text)

      if project_match is None:
        project_match = await self._resolve_project_for_photo(message, caption_text)

      photo = SitePhoto(
        id=uuid4(),
        organization_id=message.organization_id,
        project_id=project_match,
        whatsapp_message_id=message.id,
        storage_key=storage_key,
        sender_phone_number=message.from_phone_number,
        caption_raw=message.caption_text,
        caption_parsed=caption_parsed,
        location_text=caption_parsed.get("location"),
        photo_date=photo_date,
        is_ai_tagged=bool(caption_parsed),
      )
      await self.photos.create(photo)
      await self.subscriptions.increment_usage_many(
        message.organization_id,
        {"site_photos": 1, "storage_bytes": photo_size_bytes},
      )
    except Exception as exc:
     await self.session.rollback()

     if storage_key is not None:
       try:
         await asyncio.to_thread(delete_object, storage_key)
       except Exception:
         pass

     failed_message = await self.messages.get_by_id(message_id, organization_id)
     if failed_message is None:
        return

     failed_message.status = WhatsAppMessageStatus.FAILED
     failed_message.error_message = str(exc)[:2000]

     await self.messages.update(failed_message)
     await self.session.commit()
     return
    
    if project_match is not None:
      message.status = WhatsAppMessageStatus.PROCESSED
      message.processed_at = datetime.now(timezone.utc)
      await self.messages.update(message)
      await self.session.commit()
    else:
      message.status = WhatsAppMessageStatus.AWAITING_PROJECT_SELECTION
      await self.messages.update(message)
      await self.session.commit()
      await self._send_project_disambiguation_prompt(channel, message)

  async def _check_sender(
    self, organization_id: UUID, from_phone_number: str,
  ) -> tuple[bool, WhatsAppSender | None]:
    senders = await self.senders.list_by_org(organization_id)
    if not senders:
      return True, None
    phone = normalize_phone_number(from_phone_number)
    match = next((s for s in senders if s.phone_number == phone and s.is_active), None)
    return match is not None, match

  async def _resolve_project_for_photo(
    self, message: WhatsAppMessage, caption_text: str,
  ) -> UUID | None:
    """Work out the project without bothering the sender: a project code/name in the caption, else the sender's
    default project, else the project of their photos from the last couple of hours."""
    projects = await self.projects.list_by_org(message.organization_id)
    active = {p.id for p in projects if p.status == ProjectStatus.ACTIVE}

    if caption_text:
      matched = match_project_in_caption(projects, caption_text)
      if matched is not None:
        return matched

    _allowed, sender = await self._check_sender(message.organization_id, message.from_phone_number)
    if sender is not None and sender.default_project_id in active:
      return sender.default_project_id

    recent = await self.senders.get_recent_project_for_sender(
      message.organization_id, message.from_phone_number,
      datetime.now(timezone.utc) - STICKY_PROJECT_WINDOW,
    )
    if recent is not None and recent in active:
      return recent
    return None

  async def list_senders(self, organization_id: UUID) -> list[WhatsAppSender]:
    return await self.senders.list_by_org(organization_id)

  async def create_sender(self, organization_id: UUID, payload: SenderCreateRequest) -> WhatsAppSender:
    phone = normalize_phone_number(payload.phone_number)
    if len(phone) < 8:
      raise TraceException("Enter a valid phone number.", status_code=422, code="INVALID_PHONE_NUMBER")
    if await self.senders.get_by_phone(organization_id, phone) is not None:
      raise TraceException(
        "This number is already on the sender list.", status_code=409, code="SENDER_ALREADY_EXISTS",
      )
    await self._check_default_project(organization_id, payload.default_project_id)
    sender = WhatsAppSender(
      id=uuid4(), organization_id=organization_id, phone_number=phone,
      display_name=payload.display_name.strip(), default_project_id=payload.default_project_id,
    )
    await self.senders.create(sender)
    await self.session.commit()
    return sender

  async def update_sender(
    self, organization_id: UUID, sender_id: UUID, payload: SenderUpdateRequest,
  ) -> WhatsAppSender:
    sender = await self.senders.get_by_id(sender_id, organization_id)
    
    if sender is None:
      raise TraceException("Sender not found.", status_code=404, code="SENDER_NOT_FOUND")
    if payload.display_name is not None:
      sender.display_name = payload.display_name.strip()
    if payload.clear_default_project:
      sender.default_project_id = None
    elif payload.default_project_id is not None:
      await self._check_default_project(organization_id, payload.default_project_id)
      sender.default_project_id = payload.default_project_id
      
    if payload.is_active is not None:
      sender.is_active = payload.is_active
    await self.session.commit()
    return sender

  async def delete_sender(self, organization_id: UUID, sender_id: UUID) -> None:
    sender = await self.senders.get_by_id(sender_id, organization_id)
    if sender is None:
      raise TraceException("Sender not found.", status_code=404, code="SENDER_NOT_FOUND")
    await self.senders.delete(sender)
    await self.session.commit()

  async def _check_default_project(self, organization_id: UUID, project_id: UUID | None) -> None:
    if project_id is None:
      return
    if await self.projects.get_by_id_and_org(project_id, organization_id) is None:
      raise TraceException("Project not found.", status_code=404, code="PROJECT_NOT_FOUND")

  async def _is_ai_enabled(self, organization_id: UUID) -> bool:
    result = await self.session.execute(
      select(Organization.ai_enabled).where(
        Organization.id == organization_id
      )
    )
    return bool(result.scalar_one_or_none())

  async def _match_project_by_name(
    self,
    organization_id: UUID,
    name_guess: str,
  ) -> UUID | None:
    projects = await self.projects.list_by_org(organization_id)
    normalized_guess = name_guess.strip().lower()

    matches = [
      p for p in projects
      if p.status == ProjectStatus.ACTIVE
      and p.name.strip().lower() == normalized_guess
    ]
    return matches[0].id if len(matches) == 1 else None

  async def _send_project_disambiguation_prompt(
    self,
    channel: WhatsAppChannel,
    message: WhatsAppMessage,
  ) -> None:
    projects = await self.projects.list_by_org(message.organization_id)
    active_projects = [
      p for p in projects if p.status == ProjectStatus.ACTIVE
    ]

    if not active_projects:
      await self.notifications.notify_by_permission(
        message.organization_id,
        PermissionKey.SITE_PHOTO_MANAGE,
        NotificationType.SITE_PHOTO_NEEDS_PROJECT,
        "A site photo needs a project assigned",
        body=(
          "No active projects were available to prompt the sender — "
          "assign it manually."
        ),
        link_path="/app/site-photos",
      )
      return

    if len(active_projects) <= 3:
      body = {
        "messaging_product": "whatsapp",
        "to": message.from_phone_number,
        "type": "interactive",
        "interactive": {
          "type": "button",
          "body": {"text": "Which project is this photo for?"},
          "action": {
            "buttons": [
              {
                "type": "reply",
                "reply": {
                  "id": str(project.id),
                  "title": project.name[:20],
                },
              }
              for project in active_projects
            ]
          },
        },
      }
    else:
    
      body = {
        "messaging_product": "whatsapp",
        "to": message.from_phone_number,
        "type": "interactive",
        "interactive": {
          "type": "list",
          "body": {"text": "Which project is this photo for?"},
          "action": {
            "button": "Select Project",
            "sections": [
              {
                "title": "Active Projects",
                "rows": [
                  {
                    "id": str(project.id),
                    "title": project.name[:24],
                    "description": (project.code or "")[:72] if hasattr(project, "code") else "",
                  }
                  for project in active_projects[:10]
                ],
              }
            ],
          },
        },
      }

    try:
      prompt_wa_message_id = await _send_whatsapp_message(
        channel.phone_number_id, channel.access_token, body
      )
    except Exception as exc:
      message.error_message = f"Failed to send project-selection prompt: {exc}"[:2000]
      await self.messages.update(message)
      await self.session.commit()
      await self.notifications.notify_by_permission(
        message.organization_id,
        PermissionKey.SITE_PHOTO_MANAGE,
        NotificationType.SITE_PHOTO_NEEDS_PROJECT,
        "A site photo needs a project assigned",
        body=(
          "Couldn't send the project-selection prompt on WhatsApp — "
          "assign it manually."
        ),
        link_path="/app/site-photos",
      )
      return

    if prompt_wa_message_id:
      message.prompt_wa_message_id = prompt_wa_message_id
      await self.messages.update(message)
      await self.session.commit()

  async def list_photos(
    self,
    organization_id: UUID,
    *,
    project_id: UUID | None = None,
    photo_date_from: date | None = None,
    photo_date_to: date | None = None,
    tag: str | None = None,
    unassigned_only: bool = False,
    skip: int = 0,
    limit: int = 100,
) -> list[SitePhotoResponse]:
    photos = await self.photos.list_by_org(
      organization_id,
      project_id=project_id,
      photo_date_from=photo_date_from,
      photo_date_to=photo_date_to,
      tag=tag,
      unassigned_only=unassigned_only,
      skip=skip,
      limit=limit,
    )
    return [_to_photo_response(photo) for photo in photos]

  async def get_latest_photo_by_project(
    self,
    organization_id: UUID,
  ) -> list[ProjectPhotoThumbnailResponse]:
    photos = await self.photos.get_latest_by_project(organization_id)
    return [
      ProjectPhotoThumbnailResponse(
        project_id=photo.project_id,
        photo_id=photo.id,
        photo_url=generate_presigned_url(photo.storage_key),
      )
      for photo in photos
      if photo.project_id is not None
    ]

  async def _get_photo_model(
    self,
    organization_id: UUID,
    photo_id: UUID,
) -> SitePhoto:
    photo = await self.photos.get_by_id_and_org(
      photo_id,
      organization_id,
    )

    if photo is None:
      raise TraceException(
        "Site photo not found.",
        status_code=404,
        code="SITE_PHOTO_NOT_FOUND",
      )

    return photo

  async def get_photo(
    self,
    organization_id: UUID,
    photo_id: UUID,
) -> SitePhotoResponse:
    photo = await self._get_photo_model(
      organization_id,
      photo_id,
    )
    return _to_photo_response(photo)

  async def get_photo_url(
    self,
    organization_id: UUID,
    photo_id: UUID,
  ) -> SitePhotoUrlResponse:
    photo = await self._get_photo_model(organization_id, photo_id)
    exists = await asyncio.to_thread(object_exists, photo.storage_key)
    
    if not exists:
      raise TraceException(
        "The image file for this photo is missing from storage.",
        status_code=404,
        code="SITE_PHOTO_FILE_MISSING",
      )
    return SitePhotoUrlResponse(
      photo_id=photo.id,
      photo_url=generate_presigned_url(photo.storage_key),
      photo_url_expires_in=settings.site_photo_url_ttl_seconds,
    )

  async def assign_project(
    self,
    organization_id: UUID,
    photo_id: UUID,
    payload: SitePhotoAssignProjectRequest,
    user_id: UUID,
  ) -> SitePhotoResponse:
    photo = await self._get_photo_model(organization_id, photo_id)

    project = await self.projects.get_by_id_and_org(
      payload.project_id, organization_id
    )
    if project is None:
      raise TraceException(
        "Project not found in this organization.",
        status_code=404,
        code="PROJECT_NOT_FOUND",
      )

    photo.project_id = project.id
    await self.photos.update(photo)
    await self.session.commit()

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.SITE_PHOTO,
      photo.id,
      AuditAction.UPDATE,
      f"Assigned site photo {photo.id} to project {project.id}",
    )

    return _to_photo_response(photo)

  async def update_photo(
    self,
    organization_id: UUID,
    photo_id: UUID,
    payload: SitePhotoUpdateRequest,
    user_id: UUID,
  ) -> SitePhotoResponse:
    photo = await self._get_photo_model(organization_id, photo_id)

    if "location_text" in payload.model_fields_set:
     photo.location_text = payload.location_text
    if "photo_date" in payload.model_fields_set:
     photo.photo_date = payload.photo_date
    await self.photos.update(photo)
    await self.session.commit()

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.SITE_PHOTO,
      photo.id,
      AuditAction.UPDATE,
      f"Updated site photo {photo.id}",
    )

    return _to_photo_response(photo)

  async def add_tag(
    self,
    organization_id: UUID,
    photo_id: UUID,
    payload: PhotoTagCreateRequest,
    user_id: UUID,
  ) -> PhotoTagResponse:
    photo = await self._get_photo_model(organization_id, photo_id)
    
    tag_value = payload.tag.strip()
    if not tag_value:
      raise TraceException(
        "Photo tag cannot be empty.",
        status_code=400,
        code="PHOTO_TAG_EMPTY",
      )
    if any(t.tag == tag_value for t in photo.tags):
      raise TraceException(
        "This tag already exists on this photo.",
        status_code=409,
        code="PHOTO_TAG_ALREADY_EXISTS",
      )

    tag = PhotoTag(
      id=uuid4(),
      organization_id=organization_id,
      site_photo_id=photo.id,
      tag=tag_value,
      source=PhotoTagSource.MANUAL,
    )
    tag = await self.tags.create(tag)
    await self.session.commit()

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.SITE_PHOTO,
      photo.id,
      AuditAction.CREATE,
      f"Added tag '{tag.tag}' to site photo {photo.id}",
    )

    return PhotoTagResponse.model_validate(tag)

  async def remove_tag(
    self,
    organization_id: UUID,
    photo_id: UUID,
    tag_id: UUID,
    user_id: UUID,
  ) -> None:
    photo = await self._get_photo_model(organization_id, photo_id)

    matching = next((t for t in photo.tags if t.id == tag_id), None)
    if matching is None:
      raise TraceException(
        "Tag not found on this photo.",
        status_code=404,
        code="PHOTO_TAG_NOT_FOUND",
      )
    removed_tag_value = matching.tag
    await self.tags.delete(matching)
    await self.session.commit()

    await self.audit.log(
      organization_id,
      user_id,
      AuditEntityType.SITE_PHOTO,
      photo.id,
      AuditAction.DELETE,
      f"Removed tag '{removed_tag_value}' from site photo {photo.id}",
    )
    
MIME_EXTENSIONS = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
}

def _extension_for_mime_type(mime_type: str) -> str:
  normalized = mime_type.strip().lower()
  extension = MIME_EXTENSIONS.get(normalized)

  if extension is None:
    raise ValueError(
      f"Unsupported image MIME type: {mime_type}"
  )
  return extension

async def _download_whatsapp_media(
  access_token: str,
  media_id: str | None,
) -> tuple[bytes, str]:
  if not media_id:
    raise ValueError("Message has no media_id to download.")

  async with httpx.AsyncClient(
    timeout=settings.whatsapp_media_download_timeout_seconds
  ) as client:
    meta_response = await client.get(
      f"{GRAPH_API_BASE}/{media_id}",
      headers={"Authorization": f"Bearer {access_token}"},
    )
    meta_response.raise_for_status()

    meta_data = meta_response.json()
    media_url = meta_data["url"]
    mime_type = meta_data.get("mime_type", "image/jpeg")

    async with client.stream(
      "GET",
      media_url,
      headers={"Authorization": f"Bearer {access_token}"},
    ) as media_response:
      media_response.raise_for_status()

      content_length = media_response.headers.get("Content-Length")

      if (
        content_length is not None
        and int(content_length) > settings.whatsapp_max_photo_bytes
      ):
        raise ValueError(
          "WhatsApp media exceeds the maximum allowed size."
        )

      chunks: list[bytes] = []
      total_size = 0
      async for chunk in media_response.aiter_bytes():
        total_size += len(chunk)

        if total_size > settings.whatsapp_max_photo_bytes:
          raise ValueError(
            "WhatsApp media exceeds the maximum allowed size."
          )
        chunks.append(chunk)

      return b"".join(chunks), mime_type

async def _send_whatsapp_message(
  phone_number_id: str,
  access_token: str,
  body: dict,
) -> str | None:
  async with httpx.AsyncClient(timeout=30.0) as client:
    response = await client.post(
      f"{GRAPH_API_BASE}/{phone_number_id}/messages",
      headers={"Authorization": f"Bearer {access_token}"},
      json=body,
    )
    response.raise_for_status()
    messages = response.json().get("messages", [])
    return messages[0]["id"] if messages else None
  
def _to_photo_response(photo: SitePhoto) -> SitePhotoResponse:
  return SitePhotoResponse(
    id=photo.id,
    project_id=photo.project_id,
    storage_key=photo.storage_key,
    photo_url=generate_presigned_url(photo.storage_key),
    photo_url_expires_in=settings.site_photo_url_ttl_seconds,
    sender_phone_number=photo.sender_phone_number,
    caption_raw=photo.caption_raw,
    caption_parsed=photo.caption_parsed,
    location_text=photo.location_text,
    photo_date=photo.photo_date,
    is_ai_tagged=photo.is_ai_tagged,
    tags=[PhotoTagResponse.model_validate(t) for t in photo.tags],
    created_at=photo.created_at,
  )

def _parse_photo_date(
  value: Any,
) -> date | None:
  if not value:
    return None
  try:
    return date.fromisoformat(str(value))
  except (TypeError, ValueError):
    return None

async def _call_ollama_parse_caption(caption_text: str) -> dict | None:
  import json

  prompt = (
    "Extract structured information from this WhatsApp caption sent by a "
    "site engineer along with a construction site photo. The caption may "
    "mix English and Urdu. Respond with strict JSON only: "
    '{"project": "... or null", "location": "... or null", '
    '"date": "... or null", "notes": "..."}. Caption: ' + caption_text
  )
  try:
    async with httpx.AsyncClient(timeout=30.0) as client:
      response = await client.post(
        f"{settings.ollama_base_url}/api/generate",
        json={
          "model": settings.ollama_model,
          "prompt": prompt,
          "stream": False,
          "format": "json",
        },
      )
      response.raise_for_status()
      return json.loads(response.json()["response"])
  except Exception:
    return None
        
async def _parse_caption(caption_text: str) -> dict | None:
  if settings.ai_provider == "anthropic":
    return await _call_cloud_parse_caption(caption_text)
  return await _call_ollama_parse_caption(caption_text)

async def _call_cloud_parse_caption(caption_text: str) -> dict | None:
  import json
  prompt = (
    "Extract structured information from this WhatsApp caption sent by a "
    "site engineer along with a construction site photo. The caption may "
    "mix English and Urdu. Respond with strict JSON only: "
    '{"project": "... or null", "location": "... or null", '
    '"date": "... or null", "notes": "..."}. Caption: ' + caption_text
  )
  try:
    async with httpx.AsyncClient(timeout=30.0) as client:
      response = await client.post(
        "https://api.anthropic.com/v1/messages",
        headers={
          "x-api-key": settings.ai_api_key,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
        },
        json={
          "model": settings.ai_model,
          "max_tokens": 300,
          "messages": [{"role": "user", "content": prompt}],
        },
      )
      response.raise_for_status()
      text = response.json()["content"][0]["text"]
      return json.loads(text)
  except Exception:
    return None