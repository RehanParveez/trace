from __future__ import annotations
from app.engine.measure import rulebook as RB
from app.modules.drawings_boq.takeoff.extract import room_types as RT

FLOOR_ITEM = "finish.floor_item"
DADO_HEIGHT = "finish.dado_height_mm"
KITCHEN_BAND = "finish.kitchen_band"
CEILING_INCLUDES = "finish.ceiling_includes"
PCC_UNDER = "finish.pcc_under"
ROOM_TYPE = RT.ROOM_TYPE_KEY
WALL_FACES = "finish.wall_faces"
EXTENT = "finish.extent"
STRIP_WIDTHS = "finish.strip_widths_mm"
SITE_ITEM = "finish.site_item"
SITE_LAYERS = "finish.site_layers"
FACADE_ITEM = "finish.facade_item"
SILL_ITEM = "finish.sill_item"
SILL_DEPTH = "finish.sill_depth_mm"
STOPPER_ITEM = "finish.stopper_item"
STAIR_EXTERNAL = "finish.stair_external"
BILL_SEPARATE, WITH_STAIR, EXCLUDE = "BILL_SEPARATE", "WITH_STAIR", "EXCLUDE"
STAIR_EXTERNAL_MODES = (BILL_SEPARATE, WITH_STAIR, EXCLUDE)
SILL_DEPTH_FALLBACK_MM = 230.0
SILL_DEPTH_MIN_MAX_MM = (50.0, 600.0)
ELEVATIONS = ("FRONT", "REAR", "SIDE", "LEFT", "RIGHT", "UNNAMED")
SITE_REGIONS = ("PASSAGE", "DRIVE", "PORCH", "RAMP", "COURTYARD", "LAWN", "OPEN_SITE")
LAYER_MM = (10.0, 1000.0)
LAYERS_MAX = 6
FLOOR_AREA, GROSS, STRIPS, ROOMS = "FLOOR_AREA", "GROSS", "STRIPS", "ROOMS"
EXTENT_MODES = (FLOOR_AREA, GROSS, STRIPS, ROOMS)
EXTENT_ITEMS = ("termite", "pcc_floor", "fill", "ceiling")
STRIP_ITEMS = ("termite_strip", "pcc_strip")
STRIP_CLASSES = ("outer", "inner", "thin")
STRIP_WIDTH_MM = (100.0, 3000.0)
OUTLINE, GRAPH = "OUTLINE", "GRAPH"
KEYS = (FLOOR_ITEM, DADO_HEIGHT, KITCHEN_BAND, CEILING_INCLUDES, PCC_UNDER, ROOM_TYPE, WALL_FACES, EXTENT, STRIP_WIDTHS, SITE_ITEM, SITE_LAYERS, FACADE_ITEM, SILL_ITEM, SILL_DEPTH, STOPPER_ITEM, STAIR_EXTERNAL)

TO_CEILING = "CEILING"
FULL = "full"
NONE = "NONE"
DADO_FALLBACK_MM = 2134.0
DEFAULT_FLOOR_ITEM = "FIN-FLOOR"
DEFAULT_SITE_ITEM = "FIN-PAVING"
HEIGHT_MIN_MM, HEIGHT_MAX_MM = 300.0, 6000.0
SCOPE_KEYS = {FLOOR_ITEM: ("room_type",), DADO_HEIGHT: ("room_type",), KITCHEN_BAND: ("room_type",), CEILING_INCLUDES: ("level",), PCC_UNDER: ("level",), ROOM_TYPE: ("room_name",), WALL_FACES: (), EXTENT: ("item", "level"), STRIP_WIDTHS: ("item",), SITE_ITEM: ("region",), SITE_LAYERS: ("region",), FACADE_ITEM: ("elevation",), SILL_ITEM: (), SILL_DEPTH: (), STOPPER_ITEM: (), STAIR_EXTERNAL: ()}
HEIGHT_TYPES = (*RT.WET, RT.KITCHEN)
TYPED_FLOORS = {RT.PORCH: "FLOOR_PORCH", RT.TERRACE: "FLOOR_TERRACE", RT.PASSAGE: "FLOOR_PASSAGE", RT.LAWN: "FLOOR_LAWN"}
TYPED_ITEM_CODE = {"FLOOR_PORCH": "FIN-PORCH-TILE", "FLOOR_TERRACE": "FIN-TERreturn str(rv.value) if rv.value is not None else DEFAULT_FLOOR_ITEMRACE-TILE", "FLOOR_PASSAGE": "FIN-PAVING", "FLOOR_LAWN": "FIN-PAVING"}
TYPED_TEXT = {"FLOOR_PORCH": "Floor tile of the porch", "FLOOR_TERRACE": "Floor tile of the terraces", "FLOOR_PASSAGE": "Paving of the passages", "FLOOR_LAWN": "Paving of the lawns and yards"}

def rule(key: str, **scope) -> RB.RuleValue:
  return RB.resolve(key, scope or None)

def evidence(key: str, rv: RB.RuleValue, **scope) -> dict:
  return {"key": key, "scope": dict(scope), "value": rv.value, "origin": rv.origin, "cls": rv.cls, "rule_id": rv.rule_id, "version": rv.version}

def is_default(rv: RB.RuleValue) -> bool:
  return rv.origin == RB.CODE_DEFAULT_ASSUMED

def floor_item(room_type: str) -> tuple:
  rv = rule(FLOOR_ITEM, room_type=room_type)
  return (str(rv.value) if rv.value is not None else DEFAULT_FLOOR_ITEM), rv

def default_floor_item() -> str:
  rv = rule(FLOOR_ITEM)
  return str(rv.value) if rv.value is not None else DEFAULT_FLOOR_ITEM

def site_item(region: str) -> tuple:
  rv = rule(SITE_ITEM, region=region)
  return (str(rv.value) if rv.value is not None else NONE), rv

def facade_item(view: str) -> tuple:
  rv = rule(FACADE_ITEM, elevation=view)
  return (str(rv.value) if rv.value is not None else NONE), rv

def sill_item() -> tuple:
  rv = rule(SILL_ITEM)
  return (str(rv.value) if rv.value is not None else NONE), rv

def sill_depth() -> tuple:
  rv = rule(SILL_DEPTH)
  return (float(rv.value) if rv.value is not None else SILL_DEPTH_FALLBACK_MM), rv

def stair_external() -> tuple:
  rv = rule(STAIR_EXTERNAL)
  return (str(rv.value) if rv.value in STAIR_EXTERNAL_MODES else BILL_SEPARATE), rv

def stopper_item() -> tuple:
  rv = rule(STOPPER_ITEM)
  return (str(rv.value) if rv.value is not None else NONE), rv

def site_layers(region: str) -> tuple:
  rv = rule(SITE_LAYERS, region=region)
  return (list(rv.value) if isinstance(rv.value, (list, tuple)) else []), rv

def height_mm(room_type: str, clear_mm: float | None) -> tuple:
  rv = rule(DADO_HEIGHT, room_type=room_type)
  v = rv.value
  if isinstance(v, str) and v.strip().upper() == TO_CEILING:
    if clear_mm:
      return float(clear_mm), rv, False
    return DADO_FALLBACK_MM, rv, True
  try:
    return float(v), rv, False
  except (TypeError, ValueError):
    return DADO_FALLBACK_MM, rv, True

def kitchen_band(room_type: str = RT.KITCHEN) -> tuple:
  rv = rule(KITCHEN_BAND, room_type=room_type)
  v = rv.value
  if isinstance(v, dict):
    try:
      lo, hi = float(v["from_mm"]), float(v["to_mm"])
    except (KeyError, TypeError, ValueError):
      return None, rv
    if hi > lo >= 0.0:
      return (lo, hi), rv
  return None, rv

def room_types_in(key: str, level: str | None) -> tuple:
  rv = rule(key, level=level) if level else rule(key)
  v = rv.value
  return ({str(t) for t in v} if isinstance(v, (list, tuple)) else set(RT.TYPES)), rv

def _scope_problem(key: str, scope) -> str | None:
  allowed = SCOPE_KEYS[key]
  scope = scope or {}
  if not isinstance(scope, dict) or any(k not in allowed for k in scope):
    return f"{key} can be scoped by {', '.join(allowed)} only."
  if scope.get("item") is not None and scope["item"] not in (EXTENT_ITEMS if key == EXTENT else (*EXTENT_ITEMS, *STRIP_ITEMS)):
    return f"{scope['item']} is not an item with an extent: {', '.join(EXTENT_ITEMS if key == EXTENT else (*EXTENT_ITEMS, *STRIP_ITEMS))}."
  t = scope.get("room_type")
  if t is not None and t not in RT.TYPES:
    return f"{t} is not a room type."
  if scope.get("region") is not None and scope["region"] not in SITE_REGIONS:
    return f"{scope['region']} is not an outdoor region: {', '.join(SITE_REGIONS)}."
  if scope.get("elevation") is not None and scope["elevation"] not in ELEVATIONS:
    return f"{scope['elevation']} is not an elevation: {', '.join(ELEVATIONS)}."
  return None

def checked(key: str, scope, raw):
  if key not in KEYS:
    raise ValueError(f"{key} is not a finish rule.")
  bad = _scope_problem(key, scope)
  
  if bad:
    raise ValueError(bad)
  t = (scope or {}).get("room_type")
  if key == SITE_ITEM:
    region = (scope or {}).get("region")
    if not isinstance(raw, str) or not raw.strip():
      raise ValueError("The item of an outdoor region is a work item code, or NONE to leave the region out.")
    code = raw.strip().upper()
    
    if region is None and code == NONE:
      raise ValueError("NONE is for one region; it cannot be the item of every region.")
    if region == "OPEN_SITE" and code != NONE:
      raise ValueError("Open site has no label to say what it is, so it is listed and not billed: its item is NONE.")
    return code
  if key == STAIR_EXTERNAL:
    mode = raw.strip().upper() if isinstance(raw, str) else None
    if mode not in STAIR_EXTERNAL_MODES:
      raise ValueError(f"A stair outside the building is {', '.join(STAIR_EXTERNAL_MODES)}.")
    return mode
  if key == SILL_DEPTH:
    lo, hi = SILL_DEPTH_MIN_MAX_MM
    if isinstance(raw, bool) or not isinstance(raw, (int, float)) or not lo <= float(raw) <= hi:
      raise ValueError(f"The depth of a window sill is {lo:g} to {hi:g} mm.")
    return float(raw)
  if key in (SILL_ITEM, STOPPER_ITEM):
    if not isinstance(raw, str) or not raw.strip():
      raise ValueError("The item is a work item code, or NONE to bill nothing.")
    return raw.strip().upper()
  if key == FACADE_ITEM:
    if not isinstance(raw, str) or not raw.strip():
      raise ValueError("The item of the patterned zones of an elevation is a work item code, or NONE to bill nothing from it.")
    return raw.strip().upper()
  if key == SITE_LAYERS:
    if not isinstance(raw, (list, tuple)) or len(raw) > LAYERS_MAX:
      raise ValueError(f"Give a list of at most {LAYERS_MAX} layers, each {{work_item, thickness_mm}}, top to bottom (an empty list for none).")
    
    layers = []
    for layer in raw:
      ok = isinstance(layer, dict) and set(layer) == {"work_item", "thickness_mm"} and isinstance(layer["work_item"], str) and layer["work_item"].strip()
      ok = ok and isinstance(layer["thickness_mm"], (int, float)) and not isinstance(layer["thickness_mm"], bool) and LAYER_MM[0] <= float(layer["thickness_mm"]) <= LAYER_MM[1]
      if not ok:
        raise ValueError(f"A layer is {{work_item, thickness_mm}} with the thickness {LAYER_MM[0]:g} to {LAYER_MM[1]:g} mm.")
      layers.append({"work_item": layer["work_item"].strip().upper(), "thickness_mm": float(layer["thickness_mm"])})
    return layers
  if key == FLOOR_ITEM:
    if not isinstance(raw, str) or not raw.strip():
      raise ValueError("The floor item is a work item code, or NONE to leave the room out.")
    code = raw.strip().upper()
    if t in RT.WET:
      raise ValueError("The floor of a bath, toilet or powder room is its own line; its work item is not a rule.")
    if t is not None and code != NONE and t not in TYPED_FLOORS:
      raise ValueError(f"Only {', '.join(TYPED_FLOORS)} can have a floor item of their own; use NONE to leave {t} out, or set the item for every room.")
    if t is None and code == NONE:
      raise ValueError("NONE is for one room type; it cannot be the item of every room.")
    return code

  if key == DADO_HEIGHT:
    if t is not None and t not in HEIGHT_TYPES:
      raise ValueError(f"A tile height can be set for {', '.join(HEIGHT_TYPES)}.")
    if isinstance(raw, str) and raw.strip().upper() == TO_CEILING:
      return TO_CEILING
    if isinstance(raw, bool) or not isinstance(raw, (int, float)) or not HEIGHT_MIN_MM <= float(raw) <= HEIGHT_MAX_MM:
      raise ValueError(f"The tile height is {HEIGHT_MIN_MM:g} to {HEIGHT_MAX_MM:g} mm, or CEILING.")
    return float(raw)
  if key == KITCHEN_BAND:
    if t is not None and t != RT.KITCHEN:
      raise ValueError("The band is for the kitchen.")
    if isinstance(raw, str) and raw.strip().lower() == FULL:
      return FULL
    if isinstance(raw, dict) and set(raw) == {"from_mm", "to_mm"} and all(isinstance(raw[k], (int, float)) and not isinstance(raw[k], bool) for k in raw):
      lo, hi = float(raw["from_mm"]), float(raw["to_mm"])
      if 0.0 <= lo < hi <= HEIGHT_MAX_MM:
        return {"from_mm": lo, "to_mm": hi}
    
    raise ValueError(f"The kitchen band is full, or {{from_mm, to_mm}} above the floor with from below to and to at most {HEIGHT_MAX_MM:g}.")
  if key in (CEILING_INCLUDES, PCC_UNDER):
    if not isinstance(raw, (list, tuple)) or not raw or any(x not in RT.TYPES for x in raw) or len(set(raw)) != len(raw):
      raise ValueError("Give a list of room types, each once.")
    return [str(x) for x in raw]
  if key == EXTENT:
    v = raw.strip().upper() if isinstance(raw, str) else ""
    if v not in EXTENT_MODES:
      raise ValueError(f"The extent of an item is one of {', '.join(EXTENT_MODES)}.")
    return v
  if key == STRIP_WIDTHS:
    ok = isinstance(raw, dict) and set(raw) == set(STRIP_CLASSES) and all(isinstance(x, (int, float)) and not isinstance(x, bool) and STRIP_WIDTH_MM[0] <= float(x) <= STRIP_WIDTH_MM[1] for x in raw.values())
    if not ok:
      raise ValueError(f"Strip widths are {{outer, inner, thin}} in mm, each {STRIP_WIDTH_MM[0]:g} to {STRIP_WIDTH_MM[1]:g}: outer for a wall on the outline, thin for an inner wall under 150 mm, inner for the others.")
    return {k: float(raw[k]) for k in STRIP_CLASSES}
  if key == WALL_FACES:
    v = raw.strip().upper() if isinstance(raw, str) else ""
    if v not in (OUTLINE, GRAPH):
      raise ValueError(f"The sides of a wall are decided by {OUTLINE} (the outline of the floor) or {GRAPH} (the wall graph).")
    return v
  if not isinstance(raw, str) or raw not in RT.TYPES:
    raise ValueError("The type of a room is one of " + ", ".join(RT.TYPES) + ".")
  if not (scope or {}).get("room_name"):
    raise ValueError("A room's type is set by the name of the room.")
  return raw

def seed_expect() -> dict:
  every = [t for t in RT.TYPES if t not in RT.NOT_FLOORED]
  return {FLOOR_ITEM: DEFAULT_FLOOR_ITEM, DADO_HEIGHT: DADO_FALLBACK_MM, KITCHEN_BAND: FULL, CEILING_INCLUDES: every, PCC_UNDER: list(every), WALL_FACES: OUTLINE, EXTENT: FLOOR_AREA, SITE_ITEM: DEFAULT_SITE_ITEM, SITE_LAYERS: [], FACADE_ITEM: NONE, SILL_ITEM: NONE, SILL_DEPTH: SILL_DEPTH_FALLBACK_MM, STOPPER_ITEM: NONE, STAIR_EXTERNAL: BILL_SEPARATE}
