from app.modules.identity.enums import PermissionKey

DRAWINGS_BOQ_PERMISSIONS = {
  PermissionKey.DRAWING_READ: "View drawings and parsed BOQ data.",
  PermissionKey.DRAWING_CREATE: "Upload drawings for BIM/IFC ingestion.",
  PermissionKey.DRAWING_DELETE: "Delete uploaded drawings.",
  PermissionKey.BOQ_UPDATE: "Edit draft BOQ items.",
  PermissionKey.BOQ_APPROVE: "Approve BOQ items for export.",
  PermissionKey.BOQ_ITEM_CREATE: "Add custom line items to a BOQ.",
  PermissionKey.BOQ_EXPORT: "Generate priced BOQ PDF/Excel exports.",
  PermissionKey.MATERIAL_LIBRARY_MANAGE: "Manage the organization's material library.",
  PermissionKey.LABOUR_RATE_MANAGE: "Manage the organization's labour rates.",
  PermissionKey.RULESET_MANAGE: "Create and edit draft rule sets, work items and recipes.",
  PermissionKey.RULESET_PUBLISH: "Publish (freeze) rule sets.",
  PermissionKey.CALC_RUN: "Start measurement engine calculation runs.",
  PermissionKey.BOQ_ADJUST: "Adjust calculated BOQ quantities with a recorded reason.",
  PermissionKey.BOQ_ISSUE: "Issue and archive BOQ versions.",
  PermissionKey.REVIEW_RESOLVE: "Resolve or waive BOQ review issues.",
  PermissionKey.SPACE_MANAGE: "Create and edit rooms (spaces) and their boundaries.",
  PermissionKey.FINISH_MANAGE: "Set room finishes.",
  PermissionKey.SCHEDULE_IMPORT: "Import, review and confirm schedules and bar bending schedules.",
  PermissionKey.RATEBOOK_MANAGE: "Create, edit and publish rate books, rate analyses and escalations.",
}