from __future__ import annotations

PROPOSED_BY = "proposed from the QS's answers to sections A to D and from his workbook; not given by the QS"

WORKBOOK, PRINTED, PRACTICE, SOFTWARE = "WORKBOOK", "PRINTED", "PRACTICE", "SOFTWARE"
BASES = (WORKBOOK, PRINTED, PRACTICE, SOFTWARE)
BASIS_TEXT = {
  WORKBOOK: "His workbook shows it.",
  PRINTED: "The drawing prints it.",
  PRACTICE: "Usual site practice; his workbook is silent. Check it.",
  SOFTWARE: "His workbook is silent; the software's present behaviour is proposed and stays.",
}

VALUE, SUGGESTION, KEPT, HOLD = "VALUE", "SUGGESTION", "KEPT", "HOLD"
EFFECTS = (VALUE, SUGGESTION, KEPT, HOLD)
EFFECT_TEXT = {
  VALUE: "Changes the standard value. Still marked assumed; type a value to override.",
  SUGGESTION: "Shown as a suggestion on the measurement. Nothing is filled in.",
  KEPT: "No change. The software already does this.",
  HOLD: "Not proposed. Waits for the rate list.",
}

from app.engine.measure import company as CO

PARAM_VALUES = {}              
PARAM_EVIDENCE = {
  "footing_formwork": "Form Work, FOOTING: F-1 x10, F-2 x4, F-3 x3, perimeter x 0.75 ft = 179.25 sft. Every footing, all four sides, 0.75 ft deep.",
  "steel_wastage_pct": "Steel Summary: 22.62 t plus 'Steel Waistage 5%' of 1.13 t = 23.75 t.",
  "pcc_thickness_mm": "PCC 1:4:8: every line is 0.25 ft thick (3 in, 76.2 mm).",
  "slab_steel_kg_per_m2": "Steel Summary: slab steel = slab area x 1.6 kg/sft (1,554.547 sft x 1.6 = 2,487.275 kg), a rule of thumb, not bar by bar. 1.6 kg/sft = 17.2223 kg/m2.",
}

BASEMENT_DIG_MM = 2438.4    
TRENCH_DEPTH_MM = 914.4     
WORKING_SPACE_QS_MM = 304.8   
FILL_DEPTH_MM = 457.2         
PROPS_STEP_MM = 1000.0        
ARCH_RISE_RATIO = 0.5         
ARCH_WALL_MM = 228.6          
CONCRETE_DRY_FACTOR = 1.54    
MORTAR_DRY_FACTOR = 1.27      
PLASTER_DRY_FACTOR = 1.33     
BAG_KG = 50.0                 
CEMENT_KG_M3 = 1440.0         
BRICK_MM = (228.6, 114.3, 76.2)   
JOINT_MM = 10.0               
DEFAULT_RCC_MIX = (1.0, 2.0, 4.0)     
DEFAULT_PCC_MIX = (1.0, 4.0, 8.0)     
DEFAULT_BRICK_MORTAR = (1.0, 5.0)
DEFAULT_PLASTER_MORTAR = (1.0, 4.0)   
NOMINAL_MIX_BY_GRADE = {"M10": (1.0, 3.0, 6.0), "M15": (1.0, 2.0, 4.0), "M20": (1.0, 1.5, 3.0), "M25": (1.0, 1.0, 2.0)}   
NOMINAL_MIX_BY_PSI = {"3000psi": (1.0, 2.0, 4.0), "4000psi": (1.0, 1.5, 3.0)}                                              
BARE_FIGURE_INCHES_BELOW = 100.0   
RAFT_PCC_MM = 76.2            
BRICK_STEP_OFFSET_MM = 114.3  
BRICK_STEP_HEIGHTS_MM = {
  "THIN": (152.4, 228.6, 381.0),
  "THICK": (152.4, 152.4, 381.0, 228.6),
}

def _p(ident, section, topic, question, proposed, basis, effect, evidence, params=(), confirm=None):
  return {"id": ident, "section": section, "topic": topic, "question": question, "proposed": proposed, "basis": basis, "effect": effect,
    "evidence": evidence, "params": list(params), "confirm": confirm}

PROPOSALS = [
  _p("P97-1", "L", "One concrete grade for the project fills every member that prints none", "A model that names its concrete only as 'Concrete' leaves a 'mix missing' note on every row. Can the grade be stated once?",
    "The estimator states the concrete grade once for the project (25 for M25). It fills only the concrete members whose own material text carries no grade; a grade the model prints is never replaced. The rows say the grade came from the project, not from the model, and the 'mix missing' note goes. Nothing is filled in until a grade is stated, and no grade is proposed: 0 means none stated.",
    SOFTWARE, SUGGESTION,
    "The 'mix missing' note is on every concrete row of a model whose material is only 'Concrete'. The drawings of the supplied jobs print the grade in a note (the grade reader of the PDF stage), which this setting does not replace.",
    params=[], confirm="Which grade is the standard for your structural concrete, and does the footing take a different one?"),
  _p("P87-3", "L", "Pile caps, steel, excavation and head allowances are left out of the lines", "J: what does a pile line and a raft line carry?",
    "The pile lines are the boring (metres of pile) and the concrete in the shaft. The raft lines are the slab, the 3 in concrete bed and the edge shuttering. Pile caps, the steel in piles and rafts, the cut-off and the extra length above the cut-off level, test piles, the excavation for the raft and the starter bars are not taken; each item says so, and the value at risk lists the piling lines as carrying that convention. The boring and the concrete are separate lines because a piling contractor's rate may be for boring and concrete together or apart; the rate book decides, and only one of the two should carry a price where the rate is for both.",
    PRACTICE, SUGGESTION,
    "Made-up sheet: 24 piles of 600 mm dia and 18 m give 432 m of boring and 122.2 m3 of concrete; a 900 mm raft over a 12.0 x 9.0 m outline gives 97.2 m3 of slab, 8.23 m3 of bed and 37.8 m2 of shuttering. Plot_1 has no piles; its tank raft footing is not read as a raft.",
    params=[], confirm="Is your piling rate for the pile complete (boring, concrete and cut-off) or for the boring alone? Should the cut-off allowance and the pile caps be taken from the same note?"),
  _p("P87-2", "L", "A raft: slab, bed and edge shuttering over the covered area of the lowest floor", "J: how is a raft foundation measured when the plan gives its thickness but no outline?",
    "A line that names a raft (or a mat foundation) and gives a thickness, in mm, in inches or in feet and inches, makes three items over the covered area of the lowest floor in the area table: the slab (length x width x thickness, grade from the same line), a concrete bed of 3 in under it (the workbook's thickness for the plain concrete lines), and shuttering round the outline as high as the raft is thick. The outline is the covered area of the lowest floor because a raft is not dimensioned on the architectural plans; it is marked assumed and the length and width can be replaced. A line that mentions a tank (the overhead tank's raft footing) is not read as a raft. If the area table gives no outline, no item is made and the sheet carries a note.",
    PRACTICE, SUGGESTION,
    "Made-up sheet and made-up area table, as above; the Plot_1 run shows no change.",
    params=[], confirm="Does the raft project beyond the outer walls on your jobs (and by how much)? Do you take the bed under a raft at 3 in, and the edge shuttering at the thickness of the raft?"),
  _p("P87-1", "L", "Piles: the boring and the concrete from a note or a pile schedule", "J: how are bored piles measured from the drawing?",
    "A note such as '24 nos 600 mm dia bored cast in situ piles 18 m deep', or a pile schedule (a header naming the pile mark, dia, length or depth, and nos or qty, then one row for each pile) gives two items for a pile type: the boring (total metres of pile, a new PIL-BORE work item) and the concrete (the shaft as a square of the same area, times the total length, billed as RCC with the grade written beside it). A diameter without a unit is taken as inches below 100 and as millimetres from 100 up; a length without a unit is taken as metres; both are marked assumed. If the diameter, the length or the number cannot be read, no item is made and the sheet carries a note. Lines about pile caps, details or the legend are not read. Drawn piles (circles on a plan) are not counted in this pack.",
    PRACTICE, SUGGESTION,
    "Made-up sheet with one note and one schedule of three rows: the note and the schedule rows each give the boring and the concrete; a line 'PILE CAP DETAIL' is skipped. No supplied drawing has piles.",
    params=[], confirm="How are your pile drawings written (a note, a schedule, or piles drawn on a plan)? Please send one, so the reader can be made to your layout."),
  _p("P86-3", "L", "Plaster, screeds and the work whose thickness is not printed are listed, not guessed", "J: the materials of plaster, floor beds and screeds. The bill gives them by area and the drawing prints no thickness. What is done?",
    "The plaster mortar line (FIN-PLASTER-MORTAR, made when the plaster thickness is set in the site assumptions) is broken up like brickwork mortar, at 1:4 where no mix is printed and a dry factor of 1.33 for thin coats. A plaster, floor bed or roof screed billed by area alone is listed in the break-up as not worked out, with the reason, because a thickness taken from nowhere would be a silent value. The line's own waste factor is shown beside the net materials (the net quantity is what the drawing supports), and the totals are given net and with waste. Labour and typed (manual) lines are not broken up. A design-mix concrete (M30, C25/30, 5000 psi) is listed as not worked out: its cement content is a figure from the mix design, not a ratio.",
    PRACTICE, SUGGESTION,
    "Made-up bill: a 100 m2 plaster line and an M30 concrete line are listed as not worked out, each with its reason. Plot_1's bill was not run here. Also fixes pack 85: the value-at-risk response now carries the left-out list (the response model dropped it).",
    params=[], confirm="What thickness do you take for plaster (12 mm, 15 mm, 20 mm external), for the cement-sand bed under tile and for the roof screed? With those, the area lines can be broken up too."),
  _p("P86-2", "L", "Brickwork: the bricks from the size of the brick, the mortar from what is left", "J: how many bricks and how much mortar go into a cubic metre of brickwork?",
    "The bricks are worked out, not taken from a table: a brick of 9 x 4.5 x 3 in (228.6 x 114.3 x 76.2 mm) with a 10 mm joint on each face gives 391 bricks in a cubic metre of brickwork, and the rest of the volume (0.221 m3) is mortar, at 1:5 where the drawing prints none (the QS, 26 Oct; the printed mortar of the wall is used when it is read). The mortar is turned into cement and sand by the dry-volume method with a factor of 1.27. Brick wastage is not added here; the line's waste factor is shown beside it.",
    PRACTICE, SUGGESTION,
    "Made-up 10 m3 of brickwork at 1:4: 3,912 bricks, 16.2 bags of cement, 2.25 m3 of sand. Plot_1's brick size is not printed, so the usual size is assumed.",
    params=[], confirm="What brick size and joint do your walls use, and how many bricks per cubic foot do you take (some QS tables give about 13 to 13.5)? Is 1:6 the usual mortar for 9 in walls?"),
  _p("P86-1", "L", "Concrete: cement, sand and aggregate by the dry-volume method", "J (R4): what are the materials of a cubic metre of concrete, and which mix is used where the drawing prints none?",
    "Cement, sand and coarse aggregate of every concrete line (RCC and PCC) by the dry-volume method: dry volume is 1.54 times the wet volume; cement is the dry volume over the sum of the mix parts, a bag is 50 kg and cement weighs 1,440 kg per cubic metre, sand and aggregate are the parts of the cement volume. A printed ratio (1:2:4) is used as printed; the grades take the nominal mixes of IS 456 (M10 1:3:6, M15 1:2:4, M20 1:1.5:3, M25 1:1:2); 3000 psi is taken as 1:2:4 and 4000 psi as 1:1.5:3 (site practice). Where no mix is printed the line is marked ASSUMED and takes 1:2:4 for structural concrete and 1:4:8 for plain concrete (the workbook's PCC). The result is a new report and a second sheet in the procurement workbook; no bill line, quantity or price changes.",
    PRACTICE, SUGGESTION,
    "10 m3 of 1:2:4 gives 63.4 bags (6.34 per m3, 317 kg), 4.4 m3 of sand and 8.8 m3 of aggregate; 2 m3 of 4000 psi gives 16.1 bags. The QS coefficient table was not available, so these come from the method, not from his norms.",
    params=[], confirm="Is a dry factor of 1.54 your norm (some use 1.52 or 1.57), and do you take the cement content from a table (bags per 100 cft) instead? Please send the coefficient table so the coefficients can be replaced by yours."),
  _p("P85-4", "L", "Electrical: the seven groups, fittings only, priced through the rate book", "P68-1 and P67-1 asked at what level electrical points are priced, which rate book prices them, whether wiring and conduit are by the point or by length, and what one text tag stands for. Until the QS answers, what is measured?",
    "The seven groups stay (lights, fans, sockets and plugs, switches, low-voltage points, boards and earthing, other): they are the level at which a Pakistani rate book prices electrical fittings, and a wattage or type is a different rate of the same line, not a different work item. The price is the rate book's rate for the work item by its wording (ELE-LIGHT and the rest), and a group the book has no rate for stays unpriced and is stopped by the unpriced-items check. Wiring, conduit, boxes, cable and circuits are not measured from the legend, because the legend gives points and not runs: they are billed separately, by the point of wiring or by the metre of conduit and cable, from the electrical schedule or the single-line diagram. The value at risk now says so on the bill, beside the amount of the electrical lines. Each text tag (SD., C-6) is one fitting.",
    PRACTICE, SUGGESTION,
    "Electrical_Drawings_10_Marla_House: 14 legend items on two plan sheets, as before. The only change is the line 'Wiring, conduit, boxes, cable and circuits are not in the bill' with the number and amount of the electrical lines, shown in the value at risk when a bill holds any ELE- line.",
    params=[], confirm="Does your rate book price wiring by the point of wiring (a light point, a socket point) or by the metre of conduit and cable? If by the point, tell me which points of the legend carry a wiring point, and the wiring can be counted from the same symbols."),
  _p("P85-3", "L", "A rain pipe or sewer line read again on a later sheet is set aside", "P70-1 and P66-1: when a rain water pipe is labelled on the roof plan and again on a later sheet, is it one pipe? How is a drainage line measured?",
    "A rain water pipe or the sewer line that a sheet with a lower page number already reads is taken to be the same pipe drawn again, and the later reading is set aside when it is first stored (rejected, with the page named); a person can restore it if it is another pipe. Chambers, manholes and gully traps are only flagged, because two sheets can show different chambers. The conventions of P66-1 are kept as assumed: a label is one pipe; a rain pipe runs from the roof level to the ground floor level printed on the sections, not to the drain; the sewer line is billed by the metre of pipe typed, with the manholes and chambers counted separately; the excavation, the bed and surround and the pipes between chambers are not taken in these lines (the value at risk says so). The sheet that is read first does not see a later one, so a repeat on a lower page read afterwards stays flagged, as before.",
    PRACTICE, VALUE,
    "Islamabad_Plot_1: the rain pipe label is on page 3 (roof plan) and page 5 (site sheet). Page 5 read after page 3 sets its rain pipe aside as a repeat of page 3; its sewer line, which no other sheet reads, stays. Read in the other order, page 3 is only flagged. Checked on the real readings of the two pages and on a made-up order.",
    params=[], confirm="Is a rain pipe drawn on the roof plan and again on the site sheet one pipe? Is the sewer line paid by the metre of pipe alone, or with excavation and bed in the same rate?"),
  _p("P85-2", "L", "Escalation: the median stays, the middle half is shown beside it", "P65-1: is the escalation of a trade the median of new rate over old rate, the ratio of the sums, or a published index?",
    "The median of new over old stays as the factor. The ratio of the sums is not used, because the rates of a trade are in different units (per cubic foot, per kilogram, per number) and a sum of them is dominated by the largest numbers. A published index is not on file; a figure you type replaces the factor. To show how much a factor can be trusted, each trade now carries the middle half of its revised rates (first and third quartile of new over old) and the number of rates that were not revised, in the comparison and in the preview; the note on an added escalation names them. Only revised rates enter the median, as before.",
    PRACTICE, SUGGESTION,
    "Made-up trade of 8 matched rates, 6 revised (ratios 1.10, 1.20, 1.30, 1.10, 1.50, 1.05): median 1.1500, middle half 1.1000 to 1.2750, 2 not revised. No real rate books were compared. The preview has no screen yet, so this is on the server only.",
    params=[], confirm="When some rates of a trade are not revised in the new edition, should they count as a ratio of 1 in the median (a lower factor) or be left out (as now)?"),
  _p("P85-1", "L", "Value at risk: both bands shown, which rate checks stop the bill, and the work left out", "P64-1: is the bill's band the square-root sum or the plain sum, and which rate checks stop a bill from being issued?",
    "Both bands stay on the bill: the square-root sum as the likely spread (the lines are taken to err independently) and the plain sum as the worst case. Of the eight rate checks, three stop the bill: no rate and a zero rate stop it being issued, and a rate the assistant suggested stops approval (already so). A zero rate is a new review issue (RATE_ZERO_ITEM, stops issue, can be waived with a reason, labour lines left out). The other five only warn. Each check in the value at risk now says what it stops, the count of lines that stop the bill is given, and a list names the work the bill leaves out by convention (electrical wiring and conduit; drainage excavation, bed and the pipes between chambers) with the number and amount of the lines it applies to.",
    PRACTICE, SUGGESTION,
    "Made-up bill of four lines: a zero-rate light line, an AI-priced rain pipe, an unpriced sewer line and a priced concrete line: 3 lines stop the bill, the electrical and drainage notes show 1 and 2 lines (18,900 on the drainage ones). A real bill was not run (the Plot_1 reading has no bill version in this session).",
    params=[], confirm="Is a zero rate ever right (a free-issue item)? If so, waive the issue with a reason. Should any of the five warning checks also stop issue, for instance a rate taken at the base when the book publishes several by specification?"),
  _p("P84-3", "L", "The centring of arched openings, from the schedule", "N13: arches are counted and shuttered. How is an arch over an opening measured when the plan shows only a rectangle?",
    "An opening whose schedule row says arch is taken as a semicircular arch (rise half the width) in the thickness of the wall it stands in (9 in where that is not shown). Its centring is the soffit girth times the thickness, in m2, as a new line (work item FRM-ARCH, added to the seed). The opening is deducted as the full rectangle to the crown, as IS 1200 does; the plaster to the soffit is not added.",
    PRACTICE, VALUE,
    "IS 1200 measures an arched opening by the rectangle that encloses it; a semicircular head is the arch that needs the width only. Islamabad_Plot_1 prints no ARCH in its schedules, so no line is made there.",
    params=[], confirm="Are the arches of your buildings semicircular or segmental (and how much rise), and is the centring paid by the girth times the wall thickness?"),
  _p("P84-2", "L", "Upstand beams read from the caption of the section", "v4-N1: an inverted beam, above the slab, is included and concrete is never counted twice. P24-7 proposed 'full depth is concrete'. Which?",
    "The QS's answer: the depth is overall, so an upstand beam's concrete is the depth less the slab, and its formwork is the two sides above the slab with no soffit (the slab soffit runs under it). A beam section captioned upstand, inverted or up-turned on the structural sheet is flagged, is not offered for a beam the plan does not mark, and a beam the plan marks with it is shuttered that way. P24-7's 'full depth' is not used because it would count the part inside the slab twice.",
    PRINTED, VALUE,
    "Islamabad_Plot_1 sheet 6: '(UPSTAND BEAM)' is printed under 'Beam Section RB-3 ROOF BAND', so RB-3 (4 #6 bottom, 6 #4 top; its depth is not read) is the upstand one; B-2 stays a plain beam section. No beam on the plans carries the mark RB-3, so no beam is shuttered as upstand on this drawing yet.",
    params=["beam_depth_includes_slab"], confirm="Is the roof band RB-3 the band round the roof edge (the parapet band), and what is its depth? The sheet's picture gives no readable depth."),
  _p("P84-1", "L", "The contract bill runs stage first, then trade", "Q30: the QS wants the bill by stage with the trades inside each stage, as he did before. The bill ran by kind of item (materials, labour, additional works). In what order?",
    "Stages in the order of the stage report (below plinth, plinth to lintel, lintel to slab, upper floors, roof parts, then lines not split by stage). Inside a stage the trades go alphabetically with 'Other' last, each with a sub-total, and the stage has a total. The totals by kind of item are kept as a small table after the stages, so the old reading is not lost.",
    WORKBOOK, VALUE,
    "The QS's Breakdown of Summary runs by stage (substructure, frame, walls, lintels, finishes, roof, steel). His chapter order inside a stage was not given; the trade names are the ones the stage report already groups by.",
    params=[], confirm="Inside a stage, which order do you want the trades in (his sheet's order rather than alphabetical)?"),
  _p("P83-1", "L", "Props by the metre of extra height, and the whole storey of scaffolding beside the part above 3.6 m", "P63-1 asked whether scaffolding is billed only for the wall above 3.6 m or for the whole facade, and from what clear height props are billed. Until the QS answers, how is each item measured?",
    "Props: the covered area of the slab times the number of metres, or part of a metre, by which the clear height printed on the sections is above 3.6 m (4.2 m clear is one step, 4.7 m two), the way a rate for extra height of staging is usually applied; the step of 1 m is usual practice and marked assumed. Scaffolding: unchanged, the outside face times the wall above 3.6 m, but each line now carries the area it would be if the whole storey were billed (face x floor-to-floor height), so the two readings can be compared and summed storey by storey.",
    PRACTICE, VALUE,
    "Islamabad_Plot_1: the first floor outside face is 50.58 m and its 3.2 m storey stands wholly above 3.6 m; the ground floor stands 0.67 m above it. No storey is clearer than 10 ft, so no props line is made. IS 1200 includes scaffolding and staging in the rate of the work and sets no height; the extra-height step is the common way a schedule prices staging above its base height.",
    params=[], confirm="Are props billed per square metre of soffit for each extra metre of height above 3.6 m, and is scaffolding billed for the whole storey once the building is higher than 3.6 m, or only for the part above it?"),
  _p("P82-1", "L", "Depth and working space of the foundation items when the drawing prints none", "The footing section gives the trench and the concrete bed their depth and width, but a wall with no section, the dig over the basement and the earth filling under the floor have no printed depth. The QS answered 1 ft of working space on each side of the trench (Q22) and his workbook shows 3 in. What is used?",
    "When the drawing prints no depth, the item carries a depth marked assumed instead of waiting to be typed: 3 ft for a wall trench and 8 ft for the basement dig (both the QS's workbook), the 3 in of the confirmed concrete bed for a bed with no section, and 1.5 ft (three 6 in layers) for the earth filling under the floor, which is usual practice because the workbook has no filling line. The strip width of a wall with no section is still typed, because nothing on the drawing or in the workbook settles it. The trench keeps the workbook's 3 in of working space a side; the width and the extra digging with the QS's 1 ft a side are worked out and shown beside it.",
    WORKBOOK, VALUE,
    "Workbook: the 'Complete Area' line digs 30 x 54 x 8 ft; the trenches are 3 ft deep; PCC 1:4:8 lines are 0.25 ft thick; a 3.5 ft bed sits in a 4 ft trench (3 in a side). Q22 answer: 1 ft extra on each side. Q24 answer: backfill comes from the same excavation with no swell or compaction. Islamabad_Plot_1 page 6: 'Filling shall be done in 6\" thick compacted layers' and no depth of filling.",
    params=[], confirm="Is the working space 3 in a side (the workbook) or 1 ft a side (your answer), and how deep is the earth filling under the ground floor?"),
  _p("P81-1", "L", "Footing sections, the bed under the columns and the frame width of the doors", "The drawing captions the footing section of its 4.5 in walls as one for a 9 in wall, prints the bed under the column footings only as a dimension line, and prints no door frame section. What is used?",
    "A footing section whose step widths fit a wall of another thickness than its caption is read for the wall the picture shows; a section with no concrete footing (the steps run straight on the bed) is masonry only, so no reinforced strip is listed for it. The bed under a column footing takes the bed thickness of the wall footing section when the sections agree. A door frame is as wide as the wall its doors stand in when every door of the mark on the floor stands in walls of one usual thickness (4.5 or 9 in); a mark found in walls of both thicknesses is still typed. All three are marked assumed or from the section, and a typed value replaces them.",
    PRINTED, VALUE,
    "Sheet 6: the left footing section is captioned for a 9 in wall but its wall is 4.5 in, with 9 in and 13.5 in steps on an 18 in x 3 in bed, 1'-9\" deep; the other two are 3'-6\" footings with 4.5 in step offsets; the column footing sections show a 3 in bed (1:4:8). The QS's Door Frames sheet takes 0.75 ft (9 in) for the doors in 9 in walls and 0.375 ft (4.5 in) for those in 4.5 in walls.",
    params=[], confirm="Are the frames of your doors as wide as the wall, as the QS has it, or do they stand proud of the plaster?"),
  _p("P80-1", "L", "Tank sizes and slab thicknesses read from the tank drawings", "Sheet 6 draws the over head tank in a plan and a section and the underground tank in a section, with every length written but none named. Which length is the wall, the slab, the width and the height, and which slab thickness is used: the section's 6 in or the QS's 8 in bottom slab?",
    "The thickness is the 4 to 12 in length read most often on the drawings of the tank; the top and bottom slab are that thickness when the section prints it (the QS's 8 in bottom slab is then not used). The width is the one length of 2 ft or more that the plan and the section both print, plus a wall each side. The length is the one longer length of the plan, plus a wall each side. The height is the one length of 3 to 6 ft in the section besides the width (the clear height) plus the two slabs, or else the one length of 6 to 10 ft (the whole height). Every size is marked assumed with its reason; a size the lengths do not settle stays to be typed.",
    PRINTED, VALUE,
    "The over head tank plan prints 3'-6\" inside width and 7'-0\" inside length with 6 in walls; its section prints 6 in top and bottom slabs and 4'-0\" clear height, so 4'-6\" x 8'-0\" x 5'-0\" outside. The QS's workbook has the same 8 x 4.5 ft and 5 ft walls with 6 in slabs for both tanks (Concrete Work, OHWT and UGWT). The underground tank's section prints 6 in slabs, 6'-0\" clear and 7'-0\" overall, with no plan; the QS used the over head tank's size and 5 ft walls for it.",
    params=[], confirm="Is the underground tank the same 8 x 4.5 ft as the over head tank, as the QS has it, or is it larger? The drawing prints no plan for it."),
  _p("P79-1", "L", "A value taken from the QS's workbook is not a value read from the drawing", "Fifty-eight rows of Plot_17 rest on a footing depth, a neck column height, a basement wall height, a tank slab or a boundary wall thickness that came from the QS's workbook. Do they count as read from the drawing?",
    "No. A height printed on the building section or in a note is used first. When the drawing prints none, the QS's height is used, graded assumed (it was graded as given by the QS and counted as printed), and the row says 'from QS' with the input named, in the register, its summary and the candidate list. A row you accept is confirmed by you and drops the tag.",
    WORKBOOK, SUGGESTION,
    "Form Work, FOOTING: every footing 0.75 ft deep; the QS's sheet keeps 6 in and 8 in tank slabs and a 4.5 in boundary wall of 66 ft that he called an estimate. None of these is printed as a figure on Plot_17.",
    params=[], confirm="Do you want rows that use your workbook's height or depth kept out of the accuracy figure, or counted with the printed rows once you confirm them?"),
  _p("P78-1", "L", "Steel weight of each member in the register", "The register stops at concrete. The bars are read (footings, columns, lintels, beam sections, slab panels, tanks) and the steel roll-up weighs them, but no row says what its bars weigh. What does a row show?",
    "Each member with bars read shows the cut length of each bar group and the weight of one member, worked out from its present size at the default cover, hook, lap and anchorage (the roll-up's conventions), without wastage; a member whose bars are read but whose size is missing says so, and the summary gives the total. The weight of the whole job, with the project's own steel parameters and wastage, stays in the steel review.",
    WORKBOOK, SUGGESTION,
    "Steel Summary: 22.62 t plus 'Steel Waistage 5%' of 1.13 t = 23.75 t over 9 lines, from bar bending schedules that give each bar group a cut length (for example the plinth beam: 3 #4 bottom at 126.91 ft, 3 #4 top, rings #3 at 6 in; the roof beam: 2 #6 bottom, 2 #5 top, rings #3 at 6 in). Plot_17 printed none of it.",
    params=["steel_wastage_pct", "steel_cover_mm", "ring_hook_dia", "bar_lap_dia", "bar_anchor_dia"],
    confirm="Does your bar bending schedule take the cut length as the clear run plus 40 diameters at each end for a beam bar, and 2 x (width + depth) of the stirrup plus the hooks for a ring?"),
  _p("P77-1", "L", "A roof projection with no length printed", "The plan prints the width of a roof projection (6 ft in front) but no length beside it. Is it slab, and how long is it?",
    "A projection wider than a chajja (18 in) with no printed length is added to the slab along the whole side of the plan it stands beside, marked assumed; a projection of 18 in or less with no length is a chajja and stays out of the slab concrete. A projection bound to a length that is not the length of its side is still left out (P45-1) and listed with what it would add.",
    PRACTICE, VALUE,
    "The QS's slab areas (1554.5, 1616.7, 1617.7 and 679.5 sft) are the covered area plus the projections, net of the stair well; the register of Plot_17 took the covered area only (1440, 1440, 1440 and 480 sft), which is 88 % of his slab area. The 6 ft front projection listed 'not bound' would add 16.72 m2 (2.55 m3) along a 30 ft front.",
    params=["slab_projection_chajja_max_mm"], confirm="Does the 6 ft front projection run the whole 30 ft of the front, or only part of it? Is the 3 ft strip a slab or a chajja on your jobs?"),
  _p("P76-1", "L", "A floor read on two sheets: the chosen sheet carries no warning", "The sheet that holds every plan of the house and the floor's own sheet both give the same walls, rooms, doors and lintels. Once one of them is chosen and the other is set aside, what warning stays on the chosen one?",
    "None. The warning 'this floor was also read from another sheet' is taken off the rows of the chosen sheet (their status is worked out again from the notes that remain), and the copy on the other sheet stays set aside and can be brought back by choosing it. A floor still open on both sheets keeps the warning on both.",
    SOFTWARE, SUGGESTION,
    "Islamabad_Plot_17: the warning is on 268 of 363 rows, valid rows fell from 209 to 8 and the decisions to confirm rose from 92 to 242, though the floors were read from the floor sheets. Islamabad_Plot_1 run here: once the choice is made, every floor item of sheet 5 (35 rooms, 94 walls, 27 lintel rows, 9 doors, 19 windows, 3 stairs, 18 beams) is set aside and pages 1 to 4 are kept.",
    confirm="After the extraction, does the register still list walls or rooms of sheet 5 for the roof or any floor? If so, which floor, and does the floor list show it as 'to decide'?"),
  _p("P75-1", "L", "The beam section under walls the plan does not mark", "The structural sheet prints several beam sections (PB-1, PB-2, RB-1 to RB-4, B-2, GB-4) and the plans do not say which lies under which wall. Which section does a wall-derived beam take?",
    "A roof beam takes the general beam section B-2 when exactly one is printed; any other beam takes the section of its own kind with the lowest number (the plinth beam PB-1). A grade beam strip marked GB-1 or GB-2 takes the only grade section printed (GB-4). All of it is marked assumed, the other sections stay listed in the decisions, and a beam the plan does mark keeps its own section. Nothing is chosen when the sheet prints no usable depth.",
    WORKBOOK, VALUE,
    "The QS's plinth beam is 9 x 18 in with 3 #4 top and bottom and rings #3 at 6 in, which is exactly section PB-1 (the walls 4.5 in wide get none); his roof beams carry 2 #6 bottom, 2 #5 top and rings #3 at 6 in, which is exactly section B-2 (15 in deep). His roof beam concrete is 9 x 9 in. Islamabad_Plot_1: before, all 15 live beams and the 6 strips had no depth.",
    confirm="Is the plinth beam under every 9 in wall PB-1 (18 in deep), and the roof beam under 9 in walls B-2 (15 in deep)? Are RB-1 to RB-4 beams of the roof framing only where the plan marks them?"),
  _p("P74-1", "L", "A page read by an older reader is read again", "A sheet's text is read once and stored. When the reader improves, the stored reading stays as it was. What brings it up to date?",
    "The reading version is raised from 18 to 19, so every stored sheet counts as out of date and is read again the next time the drawing is prepared. A drawing extracted from an older reading is also marked as read by an older reader, in the same place as the other reasons a result is out of date. A stair whose four printed values are not all read now says which were read and which were not.",
    SOFTWARE, KEPT,
    "Islamabad_Plot_1: the stair detail on sheet 5 prints 18 steps, riser 7 in, tread 10 in and width 3 ft 6 in, and the present reader takes all four. The register of Plot_17 still lists four stairs as 'details incomplete', which fits a sheet stored by an earlier reader: the version stayed at 18 through packs 44 to 73, although the readers changed.",
    confirm="After re-preparing the drawing, does the register still say the stair details are incomplete? If it does, send the 'Read from the drawing' line on the stair row."),
  _p("P73-1", "L", "Finishes conventions, checked against published practice", "Do the defaults for bath waterproofing, wall tile, bath windows, the roof turn-up and coba, the boundary wall faces and the coping hold up against published practice?",
    "Checked, one by one; no default had to change. Kept: the waterproofing of a bath or toilet is the floor plus 300 mm up the walls (P60-1; published guidance is 150 to 300 mm as a skirting, and a shower zone carried full height, 1800 mm or more; the plan does not mark the shower, so that extra is a person's to add). Kept: the roof membrane and screed turn up 300 mm at the parapet, the usual minimum (P58-1), and the coba is the average of the thin and the thick end, else 100 mm (published build-ups are 75 to 100 mm of coba under a screed). Kept: a bath ventilator with no printed sill is taken at 5 ft, a kitchen window at 3 ft 6 in (P60-3; no source found, so still an assumption). Kept: a free-standing boundary wall has two finished faces, and the sides are as high as the front (P62-1, P28-1). Kept: no standard coping size, it is plot specific (P24-9). Not settled by research: the height of kitchen wall tile (P60-2), which no published rule fixes, so it stays typed when the item is accepted; and whether a side of the boundary is a neighbour's wall, which only the job can say.",
    PRACTICE, SUGGESTION,
    "The sources are published guides without clause numbers (a waterproofing guide, a bathroom waterproofing calculator and a terrace waterproofing rule sheet, which cites IS 14215 and IS 7193 for the 1:100 to 1:80 fall and the 75 to 100 mm coba); I could not read those standards themselves, so these figures confirm the usual practice and are not a clause. Quantities: no change from this pack.",
    confirm="Is a kitchen tiled to a fixed height in your bills (2 ft above the counter, 4 ft, full height)? Is any side of the boundary a wall built by a neighbour?"),
  _p("P72-1", "L", "Concrete and brick conventions, checked against IS 1200 and usual practice", "Do the defaults for brick height, lintels, bands, projections, slab thickness, steel, opening deductions and formwork joints hold up against the standard?",
    "Checked, one by one. Changed: the formwork joints (P59-1) are now ON by default, because formwork is the surface of concrete that touches the form and the soffit of a lintel over its bearing rests on masonry. Kept: brick is net of the lintels over its openings (IS 1200 Part 3, clause 4.1.4 Note: a separate lintel is counted with the opening it spans); the wall height stays floor to floor because the QS answered S5 that way, and BETWEEN_BEAMS (brick net of the beam web, which is what IS 1200 Part 3 clause 2.3, 'net, as fixed in place', points to) stays one choice away in the Decisions panel; one band member counted once (P44-1); a strip of 18 in or less is a chajja (P45-1); the thickness labelled on the sections governs over a general slab note (P45-2, specific over general); the opening rule stays the QS sheet's, IS 1200 per work item stays a choice (P57-1). Not changed because nothing could settle it: the steel bearing (P45-3).",
    PRACTICE, SUGGESTION,
    "IS 1200 Part 3 (1976), read at law.resource.org: clause 2.3 net measurement as fixed in place; 4.1.4 note, lintels and sills are counted with the opening; 4.1.4 (a) and (c), ends of beams, lintels and bearings up to 0.1 m2 or 10 cm are not deducted from the brick. The opening-size threshold of clause 4.1.4 was illegible in that copy; 0.1 m2 is taken from published summaries. Islamabad_Plot_1: with the joints on, the lintel formwork falls by the soffit over the bearings, 7.07 m2 of 99.52 m2 (7.1 %); the chajja and balcony joints are proved only on made-up members, as before.",
    confirm="Is the QS's lintel formwork measured with or without the soffit over the bearing on the wall? If with, turn `formwork_joints` off in the model range."),
  _p("P71-1", "L", "A fact counts as checked only when a person has put their name on it", "How does the benchmark tell a fact a person checked from one that is only a draft?",
    "A benchmark fact has an optional checked_by. A fact with a name there is checked; every other fact is a draft, however it was made, and the report says how many of the facts the score rests on are checked, and how those score on their own. For kinds of item that have checked facts, the report sets the pass rate against the mean confidence the reading gave those items, so a confidence that does not mean what it says shows. A facts file can be made from what was read (--draft-facts) to save typing; its facts are all drafts, because a draft made from the reading agrees with it by construction.",
    PRACTICE, SUGGESTION,
    "Today none of the 60 plot facts, 18 architectural facts or 11 electrical facts has a name on it (the files say DRAFT), so the report says 0 checked. With 19 of the plot's facts marked checked in a scratch copy, the report gave 19 pass and a pass rate against confidence for doors, windows, rooms and footings: that is the behaviour, not a result.",
    confirm="Will you check the draft facts files against the plans and put your name in checked_by? Start with the Islamabad plot (91 draft facts) or tell me which set matters most. Tell me too if a fact checked by someone else (the QS) should carry that person's name."),
  _p("P70-1", "L", "A drainage item read on two sheets is flagged, not merged", "What happens when the same kind of drainage item (rain water pipe, sewer pipe line, chambers) is read on two sheets of one drawing?",
    "Each of the items gets a warning naming the other sheet's page: accept one of the two, or they are counted twice. Nothing in a quantity is changed and nothing is set aside, because a rain pipe on the roof plan and one on the ground plan may be two pipes or one pipe drawn twice, and the drawing does not say which. The sheet that is read first does not know of the later one until it is read again.",
    PRACTICE, SUGGESTION,
    "On the Islamabad plot the rain pipe is read on page 3 (the roof plan) and on page 5 (the site plan), so both would be flagged; whether that is one pipe or two the drawing does not say. The Public Health set (the one with many chambers and gullies) was not available to me, so chambers were not seen across sheets.",
    confirm="When a rain pipe is labelled on the roof plan and again on the floor plans, is it one pipe (count it once) or one for each label? If it is always one pipe per label position, say so and a repeat can be set aside by itself instead of flagged."),
  _p("P69-1", "L", "The QS's figures as checks in the benchmark", "How are the reading's quantities held against the QS's figures?",
    "A new benchmark fact, QS_VOLUME, adds up the concrete (pieces x length x width x depth, or height for a column) of one category of member (footing, column or beam), on all floors or one, and compares it with a range the QS gave: inside the range passes, outside fails, and while any item of the category still lacks a size it stays missing (naming the size), unless what is measured already passes the top of the range. Items set aside by a floor choice are not added. The range is the QS's own figure, never a tolerance of mine. The first one held is the Islamabad plot's footing concrete at a 9 in depth: 142 to 159 cft.",
    PRACTICE, SUGGESTION,
    "The reading gives 3 footing items (F1 x 10 at 3 ft x 3 ft, F2 x 4 at 5 ft x 5 ft, the stair footing at 3 ft x 3 ft, all 9 in deep): 149.25 cft, inside the range. The range comes from the hand-over notes; the QS worksheet itself was not available to me, and the brief says the worksheet has known errors.",
    confirm="Is 142 to 159 cft the right range for the footing concrete? Please send the QS's other figures (columns, beams, slabs, walls) as ranges, or as a figure and the tolerance you accept, so they can be held the same way."),
  _p("P68-1", "L", "Electrical points counted from the plan legend", "Which electrical symbols become items of the bill, in which groups, and how are they priced?",
    "Every legend symbol the reader can count (by its picture, or by its text tag) and finds on an electrical plan sheet becomes one item with the number of symbols, in one of seven groups taken from the wording of its legend description (lights; fans; sockets and plugs; switches; telephone, TV, data, alarm and bell points; boards, earthing and supply; other), each with its own work item, ELE-LIGHT, ELE-FAN, ELE-SOCKET, ELE-SWITCH, ELE-LOWV, ELE-BOARD, ELE-OTHER, by number. The price comes from your rate book through the work item, by its wording; where the book has no electrical rate, the line stays unpriced and the rate checks say so. Only the number of fittings is taken: wiring, conduit, boxes, cable and circuits are not. A legend symbol the reader cannot count is listed on the sheet so it can be counted by hand. The legend is read when the sheet is prepared, so a drawing prepared before this change must be prepared again for its electrical sheets.",
    PRACTICE, SUGGESTION,
    "Electrical_Drawings_10_Marla_House: the ground floor plan gives 8 items (18 light plugs, 3 cat six tags, 6 fans, 8 external wall bracket lights, 4 lawn lights, 3 smoke detectors, 37 ceiling lights) and the first floor plan 6, all counts the pack 67 reader already gave. The groups and the work items are my choice from the legend wording, not from a rate book or a specification.",
    confirm="Are these seven groups the right level to price at, or should each legend row (or each wattage and type of fitting) have its own work item and rate? Which rate book holds the electrical rates, and are wiring and conduit billed by the point or by length?"),
  _p("P67-1", "L", "Electrical symbols drawn as a text tag", "How is an electrical symbol counted when its legend picture is only a text tag (SD., C-6)?",
    "A legend row whose plan picture is too simple to match by shape but contains a text tag of two or more letters or digits is counted by that tag: one for each piece of text on the plan page that reads exactly the same (case and spaces ignored). A one-letter tag (C) is not used. A symbol that has both a picture and a tag is still counted by its picture. A symbol the plan draws differently from its legend picture (the CCTV camera) is not counted and is reported as such.",
    PRACTICE, SUGGESTION,
    "On Electrical_Drawings_10_Marla_House the SD. tag is on the ground floor plan 3 times and on the next plan once, and C-6 three times on each; the 3 smoke detectors on the ground floor are what the benchmark expects. This reader is used by the benchmark only: no screen shows its counts and nothing is priced from them yet.",
    confirm="Is each SD. tag one detector and each C-6 tag one cable outlet, or does one tag stand for a run of several?"),
  _p("P66-1", "L", "Drainage read from labels", "How are the rain water pipes, the sewer line, the manholes and the inspection chambers measured when the sheets only label them?",
    "Rain water pipes: one pipe for each label on a sheet, each as long as the fall from the roof level to the ground floor level printed on the building sections (a length you type replaces it; where the sections print no level, it must be typed). Sewer pipe line: the sheet draws it as a diagram that is not to scale, so the whole length is typed when the item is accepted. Manholes, inspection chambers and gully traps: counted once for each label (M.H, I.C, G.T) or numbered mark (MH1) on a sheet that is about drainage; depth, size, cover, excavation and the pipes between them are not taken. Every line is marked assumed or needing a typed size, and all five are priced by the metre or by number from the new DRN- work items.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1 prints a 4 in rain water pipe label on the roof plan and again on the site sheet, and a 4 in sewer pipe line label on the site sheet; the sections print the roof at 24.5 ft and the ground floor at 3.5 ft, so a pipe is 21 ft (6.40 m). Neither of the other two sets prints a rain water pipe or a sewer line. The Public Health set's benchmark facts count 5 M.H and 4 G.T labels on its sewerage plan (page 4); that PDF was not available to read, so the chamber and gully counts are not proved on it.",
    confirm="Is a rain water pipe measured from the roof down to the ground floor level, or to the drain? Is a label one pipe? Is the sewer line billed by the metre of pipe with the manholes and chambers counted separately, and are the excavation and the bed taken in the same line?"),
  _p("P65-1", "L", "Escalation taken from the change between two editions", "How is the escalation of an older rate book worked out, and which factors are refused?",
    "Compare an older book with a newer published edition: for each trade with 5 or more matched rates, the escalation factor is the median of new rate over old rate. It is added to the older book as a dated escalation (dated from the newer edition's effective date, or a date you give), only when you approve the preview, and it multiplies that trade's rates when a bill is priced on or after the date. A factor below 0.5 or above 3, a trade the rates do not name, a trade with fewer than 5 matches, a factor of exactly 1 and a trade that already has an escalation on the date are shown and not added; type those by hand if they are right. The whole-book factor (the median over every matched rate) is added as an ALL escalation only if you ask for it. The factors are worked out on the server from the two books, never taken from the screen.",
    PRACTICE, SUGGESTION,
    "The comparison already suggested these factors (5 or more matches per trade) and the pricing already applies a dated escalation at the date of the bill; this closes the step between them. The 0.5 to 3 limits are a sanity check for a mismatched unit or code, not a rule of the rate books.",
    confirm="Is the median of the matched rates the factor you want for a trade, or should it be the ratio of the sums, or a figure you type from the published escalation index?"),
  _p("P64-1", "L", "Value at risk and the rate checks", "How should the money at risk in a bill be shown, and which rates are in doubt?",
    "Each priced line's amount (quantity times rate) moves down and up by the share its quantity range allows; the bill's band adds the lines the way the quantity ranges are added (square root of the sum of squares, as if the lines err independently) and also shows the plain sum, for the case where every line is wrong the same way. The share of the bill resting on assumed, missing or unread quantities is shown, with the amount on lines that have no bound or that leave something out (a floor, not a total). Lines typed by a person are not at risk of reading, and labour lines are left out because they repeat the quantity of the material they follow. Eight rate checks are made from what each line carries: no rate, a zero rate, a rate the assistant suggested, a rate taken at the base when the book publishes several by specification, a converted unit, a library price matched by wording, a library default, and a published rate with no escalation in force. Nothing is changed in any rate.",
    PRACTICE, SUGGESTION,
    "The ranges come from the grades already carried on every ledger row; no new tolerance is chosen. The independence of the lines is an assumption: the plain sum is shown beside it.",
    confirm="Is the band of the bill wanted as the square-root sum (a likely spread) or as the plain sum (the worst case)? Which of the rate checks must stop a bill from being issued, and which only warn?"),
  _p("P63-1", "L", "Scaffolding and props above 3.6 m", "From what height is scaffolding billed on the outside walls, and from what clear height are props billed under a slab?",
    "Scaffolding: for each floor, the length of the outside faces times the part of the wall that stands higher than 3.6 m (about 12 ft) above the datum of the building sections, with nothing taken off for openings. The level and the floor-to-floor height of the floor are the ones printed on the sections; where the sections print none, nothing is made and the sheet says so. Props: the covered area of the slab, for a storey whose clear height printed on the sections is more than 3.6 m. IS 1200 includes scaffolding in the rate of the work and sets no height, so the 3.6 m is usual practice, not a rule of the code; both lines are marked assumed.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1: the sections print the first floor at 14 ft with a floor height of 10.5 ft, so its outside walls (50.58 m of face) stand wholly above 3.6 m; the ground floor stands from 3.5 ft to 14 ft, so 0.67 m of it is above 3.6 m. No storey is clearer than 10 ft (3048 mm) there, so no props line is made. Architectural_Drawings_10_Marla_House prints no storey levels, so no scaffolding line is made and the sheet says so.",
    confirm="Is scaffolding billed only for the wall above 3.6 m, or for the whole facade from the ground once the building is higher than that? From what clear height are props billed, and per square metre of soffit?"),
  _p("P62-1", "D", "Plaster, paint and the side and rear walls of the boundary", "The elevation shows the front of the boundary wall. Which faces are finished, and how long are the side and rear walls?",
    "Three lines are made from the front wall: the brick of the side and rear walls, the plaster on both faces and the paint on both faces. Both faces are taken as finished, for the front wall (the gate taken out) and for the side and rear walls, which are at the height of the front wall and, for the brick, at its thickness. The length of one side and of the rear are typed when the lines are accepted (0 where there is no wall of your own); the two sides are taken as equal. Nothing is taken off for piers and nothing is added for the coping, the top or the ends. The gate is its own item and its faces are not counted.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1, page 5: the elevation prints the boundary wall 15.25 ft long and 6 ft high with the 14.75 ft gate taken out of the overall length, so the front wall has 17.00 m2 of face (both sides). The side and rear lengths are not printed as text the reader takes, and the thickness is not printed (4.5 in from the QS, S7).",
    confirm="Are both faces of the boundary plastered and painted, are the sides as high as the front, and are the side walls of the same length? Is any side a wall built by a neighbour?"),
  _p("P61-1", "L", "Which roof heading of the specification block belongs to which roof", "When the specification prints a terrace, a roof and a porch roof, which roof of the drawing does each one belong to?",
    "The roof of a roof plan takes the ROOF heading. The main roof under a roof plan takes the TERRACE heading. A sheet that shows no roof plan takes the TERRACE heading for its top floor. When the heading of a roof is not printed but only one roof heading is, that one is used. When several are printed and none is the heading of the roof, no layer is made into an item and the sheet says so. A porch roof or mumty heading is not used until a porch roof or mumty is found.",
    PRACTICE, SUGGESTION,
    "Architectural_Drawings_10_Marla_House, page 20: the TERRACE heading prints brick ballast 3 in, a cement-sand bed 1 in (1:3) and a plain concrete bed 1.5 in (1:2:4) with two coats of waterproofing; the ROOF heading prints brick tiles 1.5 in, mud plaster 1 in, one layer of polythene and two coats; the PORCH ROOF heading prints a cement-sand bed 1 in. This set has no roof slab on its sheets, so the roof layers were checked on a roof of 104 m2 put in by hand, not on a real roof.",
    confirm="Is the roof over the stair room the one the ROOF heading describes, and the main terrace the one the TERRACE heading describes? Is a porch roof laid with its own bed?"),
  _p("P61-2", "L", "Roof layers and the roof deck assembly", "When the drawing prints the layers of a roof, should the roof deck assembly (coba, screed, membrane) still add its own?",
    "A layer printed on the drawing is measured as its own item, and it takes the code of the assembly layer it stands for: brick ballast is the coba (FIN-ROOF-COBA), the cement-sand bed is the screed (FIN-ROOF-SCREED) and the coats are the membrane (FIN-ROOF-MEMBRANE). The assembly, when it is switched on, then leaves out each layer already measured and adds only the ones the drawing does not print.",
    PRACTICE, SUGGESTION,
    "The assembly already skips a layer whose code is measured from the drawing (roof_deck.py); the printed layers use those codes so that skip applies. The assembly is off by default.",
    confirm="Is the brick ballast on a terrace the same work as the coba in your bills?"),
  _p("P61-3", "L", "How the layers of a floor or roof are measured", "Is a layer of the floor or roof build-up measured by volume or by area?",
    "Brick ballast, plain concrete, sand filling and compacted mud are measured by volume (the area times the printed thickness). The cement-sand bed, brick tiles and mud plaster are measured by area, with the thickness printed in the label of the item.",
    PRACTICE, SUGGESTION,
    "Architectural_Drawings_10_Marla_House: the cement-sand bed under the floor finish (1 in, 1:3) is 126.37 m2 on the ground floor (page 6) and 114.74 m2 on the ground working plan (page 9); on the first floor 92.56 m2 (page 7) and 89.00 m2 (page 10). They are the room areas, the same as the other layers under the floor.",
    confirm="Does your bill price the cement-sand bed per square metre, or per cubic metre at the thickness?"),
  _p("P61-4", "L", "Mix on mortar and plain concrete lines", "Does the mortar behind plaster take the mix of the plaster, and does a bed take the mix printed for it?",
    "A line takes the mix the drawing prints for its work when it prints exactly one (plaster mortar, the plain concrete bed, the cement-sand bed). The mortar behind the plaster takes the mix of the plaster line it sits behind. The grades panel can give the printed mix to lines already accepted and take it back. The bill then shows one line for each mix.",
    PRACTICE, SUGGESTION,
    "Architectural_Drawings_10_Marla_House: the plain concrete bed prints 1:2:4 and the cement-sand bed 1:3 under every floor heading. Islamabad_Plot_1 prints a plain concrete bed 1:4:8 and no plaster mix.",
    confirm="Should the bill keep one line for each mortar mix, or one line for all the mortar?"),
  _p("P60-1", "L", "How high the waterproofing of a bath or toilet goes up the wall", "Is the waterproofing of a wet room the floor plus a turn-up, and how high is the turn-up?",
    "The floor of every bath and toilet plus 300 mm (1 ft) up the walls round it, less the doors. It is a line of its own (wet-area waterproofing). The walls above the turn-up, a shower area for one, are not in it.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1, ground floor: two baths, floor 5.85 m2, 12.4 m of wall less one door, 300 mm up: 9.57 m2. Architectural_Drawings_10_Marla_House, ground floor: floor 8.36 m2, waterproofing 12.57 m2. Neither drawing prints a turn-up height or a waterproofing line for the wet rooms.",
    confirm="Does the QS's sheet waterproof the floor of the baths only, or the floor and the walls up to a height? How high, and is the shower area carried higher?"),
  _p("P60-2", "L", "Which rooms have wall tile besides the baths, and how high", "A bath or toilet has a tile dado of 7 ft. Does a kitchen have wall tile, and how high?",
    "The kitchens (a kitchen on its own, not one shared with a dining or living space) get a wall tile line: the length round the kitchen less the doors, times a tile height that is typed when the item is accepted, less the part of each window inside that height. Nothing is assumed for the height, because the plan does not print it. The tile is not taken off the paint of the kitchen walls.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1, ground floor plan (page 1): kitchen 12.12 m of wall; on the sheet that shows all four plans, the ground-floor kitchen is 10.67 m with its 1524 x 914 mm window (sill assumed at 3 ft 6 in) to come off once the height is typed. Architectural_Drawings_10_Marla_House, ground floor (page 6): 11.73 m of wall. Neither drawing prints a kitchen tile height.",
    confirm="Is a kitchen tiled to a fixed height in your bills (2 ft above the counter, 4 ft, full height)? Is the tile taken off the kitchen paint?"),
  _p("P60-3", "L", "Windows inside the dado zone of a bath", "Does a window in a bath come off the tile dado, and where does its sill stand when the plan does not print it?",
    "The part of each window that is below the top of the dado (7 ft) comes off the dado. A window with no printed sill is taken with its sill at 5 ft in a bath or toilet (a ventilator) and at 3 ft 6 in in a kitchen. A window with no size on the plan or in a schedule is not taken off and the item says how many.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1, ground floor on the sheet that shows all four plans: one 914 x 610 mm ventilator with its sill assumed at 5 ft: 0.557 m2 off a dado of 25.66 m2, which is 25.11 m2. Architectural_Drawings_10_Marla_House, ground floor: 0.83 m2 off 33.49 m2. The inside paint of the same wall is no longer short by the window twice.",
    confirm="Does the QS take the window off the dado of a bath? What sill does he assume for a bath ventilator?"),
  _p("N17", "E", "Footing and basement levels", "How far below natural ground is the underside of the footing, and how deep is the basement floor?",
    "Footing underside 3.5 ft below natural ground, as the QS said (X4). The basement is dug 8 ft.", WORKBOOK, SUGGESTION,
    "X4: 3.5 ft is right. Excavation sheet: the whole basement area is 30 x 54 x 8 ft. The printed 3'-3\" is a section detail; the QS value is used.",
    confirm="Is 8 ft the depth dug to the basement floor, below the natural ground? The QS's later answer (22 Oct) gives the footing as 4 ft overall, against 3.5 ft in X4."),
  _p("Q22", "E", "Working space per side of the trench", "Working space per side of the trench.",
    "3 in on each side of the concrete bed.", WORKBOOK, KEPT,
    "Excavation and PCC sheets: a 3.5 ft bed has a 4 ft trench. The software already adds 3 in a side.",
    confirm="The QS answered 1 ft extra on each side (22 Oct); the workbook has 3 in. Which is right?"),
  _p("Q26", "E", "DPC", "Thickness, door deduction, vertical DPC.",
    "DPC as thick as the wall at the datum, door widths deducted, no vertical DPC.", PRACTICE, KEPT,
    "The workbook measures a membrane (S1) and has no DPC line."),
  
  _p("Q32", "G", "Datum defaults", "Datum defaults: floor, DPC, lintel and slab levels.",
    "Floor-to-floor heights from the sections; basement 10.75 ft (11 ft for walls); parapet top 3 ft 1 in; the levels the QS gave stay.", WORKBOOK, KEPT,
    "S5, X9 and X10 gave the heights; the other levels are read from the sections."),
  _p("Q34", "G", "Calibration tolerance", "How close counts as a match?",
    "5 percent.", SOFTWARE, KEPT, "Not in the workbook; the comparison already uses 5 percent."),
  _p("Q-A", "G", "First version scope and order", "Which items does the first version have to cover, and in what order?",
    "The items of his Breakdown of Summary, in its order: excavation, termite, membrane, brick foundation, PCC, foundation concrete, plinth beam, columns, walls, lintels, plaster, roof, steel.", WORKBOOK, KEPT,
    "Breakdown of Summary."),
  
  _p("S2", "A", "Width of the roof projections", "Which projection width applies on which floor?",
    "Basement 3 ft; ground and first floor 3 ft and 2 ft; roof floor 2 ft. The printed width is still read as before; these widths are only recorded here.", WORKBOOK, KEPT,
    "Roof Treatment sheet: projection strips of 3 ft and 2 ft on each floor, 2 ft on the roof floor.",
    confirm="Which floor has which width?"),
  
  _p("Q28", "A", "Smallest opening to deduct", "What is the smallest opening deducted?",
    "0.5 m2 for plaster, as the placeholder is. An opening at a junction is deducted (his answer).", PRACTICE, KEPT,
    "The usual measurement rule for plaster; the clause number is not checked."),
  _p("S13", "B", "Beam and lintel formwork (open point)", "Are the sides below the slab shuttered?",
    "Keep the switch off. The measured faces stay in use and his 0.75 ft and 0.5 ft figure is shown beside them.", WORKBOOK, KEPT,
    "Form Work sheet: roof beams x 0.75, lintels x 0.5 a running foot."),
  _p("S9", "C", "Roof treatment (open point)", "Does it turn up the parapet?",
    "No. It is the roof slab area plus the projection strips of each floor.", WORKBOOK, KEPT,
    "Roof Treatment sheet: roof 1,125.87 sft plus the strips of every floor = 1,982.75 sft; no parapet line."),
  _p("S11", "D", "Tank slab thickness (open point)", "Is the bottom slab 8 in?",
    "Keep 6 in top and 8 in bottom as the QS said; the sheet's own tanks differ and are compared, not copied.", WORKBOOK, KEPT,
    "UGWT and OHWT sheets use 6 in for both slabs; the septic bottom is 9 in."),
  _p("X11", "D", "Thickness of boundary, gate and ramp walls (open point)", "Read the thickness from the elevation?",
    "No. The thickness is typed at accept; 4.5 in is offered.", SOFTWARE, KEPT, "He said the thickness has to be typed."),

  _p("Q33", "G", "Rate breakdown", "Wastage and overhead in the rates?", "No proposal.", SOFTWARE, HOLD, "Rates wait for the full rate list."),

  _p("P24-1", "G", "Plaster thickness", "How thick is the plaster when the drawing does not print it?",
    "Inside faces 1/2 in (12.7 mm), outside faces 3/4 in (19.05 mm), ceilings 3/8 in (9.525 mm). A thickness printed on a detail is read as the inside face's and replaces only that figure; the outside and the ceiling keep the practice figure.",
    PRACTICE, VALUE,
    "Usual cement-sand plaster practice for brick walls: 12 mm inside, 20 mm outside, 6 to 10 mm on concrete ceilings. Both 10 Marla sheets print 1/2 in on their wall details; none prints an outside thickness.",
    params=("plaster_inside_mm", "plaster_outside_mm", "plaster_ceiling_mm"),
    confirm="Is 3/4 in right for the outside faces on your sites?"),
  _p("P24-2", "E", "Soil stabilisation under foundations", "Is the stabilised layer measured?",
    "Only when the drawing prints it with no condition, or the estimator switches it on. A note that says 'in case of loose soil only' is recorded as printed and not measured; the volume it would add is shown beside the excavation. One 6 in layer under the whole concrete bed, mixed with 10 percent cement, compacted to 95 percent of modified AASHTO.",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1 page 6: 'Filling shall be done in 6\" thick compacted layers', 'not less than 95% of Modified AASHTO', 'Arrangement of Soil Stabilisation ... in case of loose soil only ... using 10% Cement'. The stabilised thickness is not printed. Whether the soil is loose is known only from the soil test.",
    params=("soil_stabilisation", "soil_stab_thickness_mm", "soil_stab_cement_pct"),
    confirm="Does the soil report call the soil loose? What thickness is stabilised?"),
  _p("P24-3", "E", "Which PCC thickness is the foundation's", "Plain concrete appears under footings and in floor, terrace and roof build-ups.",
    "A bed whose mix is lean (1:4:8, 1:3:6) is the foundation bed; a rich mix (1:2:4, 1:1.5:3) is a floor, terrace or roof layer and never sets the foundation thickness. A bed with no mix printed is read as the foundation's, as before.",
    PRACTICE, KEPT,
    "10 Marla architectural page AD-12: '2\" THICK P.C.C. (1:2:4)' and '1 1/2\" THICK P.C.C. (1:2:4)' in the floor and terrace lists, against 3 in of 1:4:8 under the foundations in the QS's workbook."),
  _p("P24-4", "E", "A figure on both sides of the PCC note", "'12\" PCC (1:4:8) 12\"' on a footing section.",
    "The same figure on both sides of the bed is the width it projects past the footing on each side, not its thickness. It sets the PCC projection. Two different figures around the bed are not read.",
    SOFTWARE, VALUE,
    "Islamabad_Plot_1 page 6, raft section: 12 in is drawn on each side of the bed and the 3 in thickness is a separate label; the old reader took 12 in as the thickness.",
    params=("pcc_projection_mm",)),
  _p("P24-5", "A", "Opening deduction in plaster and paint", "Which openings come off the plaster and paint?",
    "Standard: an opening under 0.5 m2 is not deducted (his answer, Q28). From 0.5 to 3 m2 it comes off one face only and the reveals are not measured; over 3 m2 it comes off every face and the reveals are measured (IS 1200). The software takes every opening of 0.5 m2 or more off every face, as his sheet does, and the IS 1200 steps are one switch away (finish_opening_rule = 1, with the 3 m2 size adjustable).",
    PRACTICE, SUGGESTION,
    "IS 1200 (finishing): deductions of openings by area. Built in pack 28; the switch is off by default so the result still matches his sheet.",
    params=("finish_opening_min_m2", "finish_opening_rule", "finish_opening_one_face_max_m2"),
    confirm="Does your sheet deduct every opening of 0.5 m2 or more from both faces, or one face for the middle sizes?"),
  _p("P28-1", "D", "Faces of a boundary wall", "Which faces of the boundary wall are plastered and painted?",
     
    "A free-standing wall has two faces. The area of both (length x height x 2, the gate taken out) is shown with the wall. Pack 62 makes the plaster and the paint of both faces lines of their own (P62-1), taking the side and rear walls with the front. Coping is not assumed.",
    PRACTICE, SUGGESTION, "Site items are read from the elevation: length, height and gate; the finish of the faces is not drawn.",
    confirm="Are both faces of the boundary wall plastered and painted, or only the street face?"),
  
  _p("P29-1", "D", "Floor finish, skirting and dado of the drawn rooms", "How are the floor finish, skirting and dado measured from the plan?",
    "Floor finish: the total of the room areas of each floor, leaving out lift shafts, lawns and courtyards. Skirting: the perimeter of every dry room less the width of its doors. A bath and a toilet have no skirting but a tile dado 7 ft (2134 mm) high, the perimeter less its doors; windows are not taken out of the dado.",
    PRACTICE, SUGGESTION,
    "Usual practice and the default finish rules (bath and toilet dado 2134 mm, kitchen and pantry dado 600 mm held back). The material (tile, marble, mosaic) and the dado height are not drawn on the plan; the dado height cannot be typed yet.",
    confirm="Is the dado 7 ft in baths and toilets, and is there a kitchen dado (600 mm) on this job?"),
  _p("P29-2", "D", "Paint on walls and ceilings", "What is painted, and what is taken off?",
    "Wall paint is on the same faces as the plaster, openings of 0.5 m2 and over taken off. The tile dado is taken off the inside paint, because tile is not painted. Ceiling paint has the same area as the ceiling plaster.",
    PRACTICE, SUGGESTION,
    "Usual practice. The one-face rule for middle-sized openings (IS 1200, built for the model route in pack 28) is not on the drawing route; only the 0.5 m2 minimum is.",
    confirm="Does your sheet paint the whole of the inside walls of a bath above the dado, and are ceilings painted in every room?"),
  _p("P24-6", "G", "Order of the bill (Q30)", "Stage first, or item first?",
    "Stage first, in the order of his Breakdown of Summary: substructure (excavation, termite, membrane, foundation), then frame, walls, lintels, finishes, roof, steel. Inside a stage the items follow his order and each floor is shown by itself.",
    WORKBOOK, KEPT, "Breakdown of Summary order (Q-A); the usual stage-wise summary above trade-wise sheets."),
  _p("P24-7", "A", "Inverted (upstand) beams (v4-N1)", "A beam above the slab top.",
    "A beam whose top is above the slab top is an upstand beam: its full depth is concrete and shuttered on both sides, and nothing is taken off the slab below it. Found by comparing the beam top with the slab top. Not built; the estimator confirms each one.",
    PRACTICE, SUGGESTION, "Usual measurement of an upstand beam; no sheet of his workbook shows one."),
  _p("P24-8", "A", "Arches over openings (N13)", "How is an arch measured?",
    "The opening is deducted as the full rectangle to the top of the arch; the plaster to the arch soffit is measured separately by its girth. Not built.",
    PRACTICE, SUGGESTION, "IS 1200 treats an arched opening by the rectangle that encloses it; the soffit is extra."),
  _p("P24-9", "D", "Coping size (N12)", "Size of the parapet and boundary-wall coping.",
    "Read from the detail when the drawing prints one; otherwise the estimator types it. No standard size is assumed because it is plot specific.",
    SOFTWARE, KEPT, "N12 was answered as plot specific."),
  _p("P24-10", "G", "Working space and depth conflicts (Q22, N17)", "The QS's later answers (1 ft each side; 4 ft overall) differ from his workbook (3 in; 3.5 ft).",
    "Keep the workbook's figures, because the software is checked against his sheet; show the other figures as an alternative. The extra volume from 1 ft each side is worked out beside the excavation when asked.",
    WORKBOOK, KEPT, "X4 and the Excavation sheet give 3.5 ft and a 4 ft trench for a 3.5 ft bed; the 22 Oct answers give 1 ft and 4 ft.",
    confirm="Which of the two do you want as the standard?"),
  _p("P43-1", "A", "Wall height basis for brick, and brick net of lintels", "Which height is a brick wall measured to when a plinth beam and a roof beam stand in it, and are the lintels taken off the brick?",
    "Floor to floor stays the standard (S5). The brick is net of the lintels over its openings (IS 1200 and usual practice; assumed). The QS worksheet's 9.25 ft in the basement is the choice ABOVE_PLINTH_BEAM; BETWEEN_BEAMS also takes off the roof-beam web.",
    PRACTICE, VALUE, "S5: basement 10.75 ft floor to floor. Plinth Beam sheet: 1.5 ft deep. Concrete Work: roof beam 0.75 ft deep, which includes the 6 in slab (N1). The QS worksheet's basement brick is 769 cft.",
    params=["brick_net_of_lintels"], confirm="Is the basement brick measured from the top of the plinth beam to the underside of the roof beam, and are the lintels taken off it?"),
  _p("P44-1", "A", "Roof band, tie band and lintels: one member each", "The drawing prints a roof band and a tie band at lintel level over the same walls. Is the concrete counted once?",
    "One band member, chosen by what the drawing prints: the roof band at slab level when its detail is printed, else the tie band. The lintels over the openings stay (Q27), and a tie band listed separately runs over the solid wall only, on 9 in walls. The decision shows the concrete with and without the tie band and the difference.",
    PRACTICE, VALUE, "Q27: the lintel is added separately; the QS worksheet has roof beams and lintels and no tie band. The sample drawing prints a roof band detail and a 9 x 12 in tie beam / lintel level band detail.",
    params=["tie_band_single_count"], confirm="Is there a continuous tie band at lintel level on the job, separate from the roof beam and the lintels?"),
  _p("P45-1", "A", "Roof projections: which strips are slab", "A roof projection label gives a width but not a length. Which strips are slab, and is a narrow one a chajja?",
    "A strip is added to the slab only when its label is bound to an overall length printed beside it and that length is the length of the side of the plan it stands beside. A strip of 18 in (457.2 mm) or less is a chajja and is not in the slab concrete (assumed). A strip that cannot be bound or checked is listed with its width and what it would add, and is not added.",
    PRACTICE, VALUE, "Islamabad_Plot_1: the 1'-6\" left projection is bound to 60'-0\" on the ground plan (the overall length of the site, not the 48'-0\" side) and to 48'-0\" on the first-floor plan; the QS's slab concrete (808.3 and 808.8 cft) is the slab without it. S2 left the widths open.",
    params=["slab_projection_chajja_max_mm"], confirm="Is the 1'-6\" strip along the left side a chajja measured separately, or part of the slab?"),
  _p("P45-2", "A", "Slab thickness: three witnesses", "The structural note says 5 in, the sections are labelled 6 in and the building sections imply 6 in. Which governs?",
    "The thickness labelled on the sections, printed more than once and agreeing with the building sections, governs over a general slab note (6 in on Islamabad). The concrete at every thickness the drawing prints is shown with the slab, and the report adds it up: the choice is worth about 13 m3 (460 cft) over the four slabs.",
    PRACTICE, VALUE, "Islamabad_Plot_1: sheet 6 prints a general slab note of 5 in (all slabs, 3 times); the section labels of sheet 5 print 6 in (12 times); floor-to-floor less clear height gives 6 in on the ground, first and roof floors.",
    confirm="Are the slabs 5 in or 6 in thick?"),
  _p("P45-3", "B", "Slab steel from the framing plan", "The framing plan draws each bar set as an arrowed line with a bar string. How is the steel of a panel taken from it?",
    "One set per distinct bar string in a panel and direction (the string is repeated on every line of the set), the bar as long as the drawn line, the number of bars the other span over the spacing plus one. Top steel over the supports, bearing, anchorage and laps are not in it. Only a panel with one panel mark inside gets steel.",
    PRACTICE, SUGGESTION, "Islamabad_Plot_1 sheet 6: 6 marked panels on each of the basement, ground and first framing plans; bars about 11 kg per m2 of panel against the QS rule of 16.1 kg per m2 of slab.",
    confirm="Are the top bars over the supports separate from the lines drawn, and how much bearing does a bar take into its beam?"),
  _p("P46-1", "B", "Neck column height", "The neck column runs from the top of the footing to the lowest floor, and that height is not printed on the sheet. What height does it take?",
    "The QS's 3.5 ft, as the registry holds it (neck_height_mm), on every neck column and marked assumed. Type a height to override it.",
    WORKBOOK, VALUE, "Concrete Work, NECK COLUMNS: C-1, C-2 and C-3 are 3.5 ft high.",
    confirm="Is 3.5 ft the height from the top of the footing to the basement floor, for every neck column?"),
  _p("P46-2", "B", "Footing pad sizes follow the column", "The footing details print sizes without a footing mark. Which footing has which size?",
    "Each footing mark is paired with the column mark written beside it on the foundation plan. The larger column takes the larger pad, and a single size left over once the marks have theirs goes to the stair footing. All of it marked assumed.",
    SOFTWARE, KEPT, "Islamabad_Plot_1 sheet 6: F1 is written beside C1 ten times and F2 beside C2 four times; C1 is 9 x 9 in and C2 9 x 15 in. The details print 3 ft, 3 ft and 5 ft pads: F1 takes 3 ft, F2 5 ft, and the stair footing the other 3 ft.",
    confirm="Does F2 (under C2) have the 5 ft pad, and is the stair footing the second 3 ft pad?"),
  _p("P46-3", "B", "Column marks against column details", "The details are captioned by mark and the plans mark the columns, and the two lists differ. Which detail is which mark?",
    "By size, never silently: a plan mark with no detail takes the detail of its size whose mark no plan uses (a mark captioned twice first); squares with no mark take the one unused detail of their size. Sizes already read are not changed; each match is a note to check.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1 sheet 6: no detail is captioned C1; C3 is captioned twice (9 x 9 and 9 x 18 in); the roof shows three unmarked 9 x 9 in squares; C4 and C5 have details and no plan mark.",
    confirm="Is the 9 x 9 in detail captioned C3 the detail of C1, and are the three roof squares C5?"),
  _p("P47-1", "B", "Beam length between column faces", "A beam drawn as a hatched strip runs from column centre to column centre. What length goes into the concrete?",
    "The length between column faces: the width of each column a strip runs into is taken off, because the column concrete is counted in the column (IS 1200). The centre to centre length is kept on the row.",
    PRACTICE, VALUE, "Islamabad_Plot_1 sheet 6, ground framing plan: GB-1 and GB-2 run 23.35 m centre to centre between 223 to 235 mm columns; the strips begin and end at column centres.",
    confirm="Does your workbook measure beams between column faces, or from centre to centre?"),
  _p("P47-2", "B", "Beam sections for a mark with no section", "The plan marks the strips GB-1 and GB-2; the sheet captions sections B2, GB-4, PB-1, PB-2, RB-1 to RB-4 and the tie band. Which section is GB-1?",
    "Nothing is chosen. The sections of the kind the mark names (GB a grade beam, RB a roof beam, PB a plinth beam) are listed on the beam to pick from, or a depth is typed.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1 sheet 6: the only grade beam section is GB-4, 18 in deep; RB-3 prints its bars but no depth that could be read.",
    confirm="Are GB-1 and GB-2 on the plans the beam of section GB-4 (18 in deep)?"),
  _p("P48-1", "B", "Rooms closed across their doors", "The wall lines stop at every door and window, so most rooms are not closed polygons and were placed at their label as a box of the printed size. How is a room taken from the walls?",
    "The gaps of door and window width (up to 2.5 m) are bridged with a piece of the wall's thickness. A closed space is a room only when exactly one room label is inside it and its area is within 8% of the printed size; otherwise the label box is kept.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1 plans 1 and 2: 5 and 6 of 10 rooms close and agree with their labels within 5%; the architectural plans: 3 of 9 and 3 of 8. The rest stay as label boxes.",
    confirm="Is the room area in your workbook taken inside the wall faces, or from the room size printed on the plan?"),
  _p("P48-2", "B", "Lintels in 4.5 inch walls and in RCC walls", "The lintel table prints one 9 inch wide section per span. What is the lintel over an opening in a 4.5 inch wall, and over an opening in an RCC wall?",
    "Over a 4.5 inch wall the lintel is as wide as the wall (4.5 in), with the table's depth and bars. An opening in an RCC wall gets no lintel: the wall is concrete.",
    PRACTICE, VALUE, "No lintel table is printed on the two drawings in hand, so this is checked on the walls and openings they do have (Islamabad_Plot_1, 4.5 and 9 inch brick walls and RCC walls) with a table fed in, not on a printed table.",
    confirm="Does your workbook make a lintel as wide as the wall in 4.5 inch walls, and leave openings in RCC walls without one?"),
  _p("P55-1", "B", "Sheets that are not floor plans", "A drawing set holds sections, elevations, details and specification sheets next to the plans. Walls, rooms and openings can be read from them too (hatching, drawn detail). What is done with them?",
    "They are read and shown, but their walls, rooms, doors, windows, lintels, stairs and wall-derived beams are held back from the bulk accept, and such a sheet takes no part in choosing the sheet of a floor. Each item can still be accepted by hand.",
    SOFTWARE, SUGGESTION, "Architectural_Drawings_10_Marla_House: the 14 sheets that are not plans (dividers, elevations, sections, details, specification) give 804 candidate items, 801 of them walls, rooms and wall-derived beams, a window and a lintel.",
    confirm="Should anything read from a section or an elevation ever go into the quantities, for example the heights, or only the plans?"),
  _p("P55-2", "B", "Furniture layout or working plan", "A floor is drawn twice: once as a furniture layout and once as the working plan. Which one is read for the quantities?",
    "The title block says which is which (FURNITURE LAYOUT against WORKING LAYOUT PLAN). The working plan is suggested for the floor and chosen when the person does not choose; the furniture layout is set aside, nothing is deleted and the choice can be turned round.",
    SOFTWARE, SUGGESTION, "Architectural_Drawings_10_Marla_House: sheets 6 to 8 are the furniture layouts and 9 to 11 the working plans of the ground, first and roof floors; before, each floor was offered as read from both, with nothing to choose.",
    confirm="Is the working plan always the one to measure from when a set also has a furniture layout?"),
  _p("P49-1", "B", "A stair drawn but its size not printed", "A plan draws a flight of steps with UP or DN beside it, but no sheet prints the riser, tread and number of steps of the stair. What is listed?",
    "The flight is listed as a stair with what is drawn (the width and the tread of the flight, the treads drawn) and left to be measured by hand. No riser, number of steps or waist is guessed, and nothing is quantified. It is not taken by the bulk accept.",
    SOFTWARE, SUGGESTION, "Architectural_Drawings_10_Marla_House: the set prints no stair detail at all (no riser, tread or number of steps on any of its 23 sheets), yet sheets 9 and 10 draw the stair of the stair hall, 3 ft 6 in wide; before, no stair was listed for the house.",
    confirm="When a set prints no stair detail, is a stair listed to be measured by hand enough, or should the riser and the number of steps be worked out from the storey height?"),
  _p("P49-2", "B", "A flight with only three treads drawn", "A stair that turns, or goes on as a dotted flight below the cut, shows only three or four clean treads. Four are needed to take a row of lines as a flight. When is three enough?",
    "Three treads are taken as a flight only where an UP or DN word that no other flight has stands within 2 m of them. Three parallel lines alone are never a stair.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1 sheet 1: the stair beside the lounge (DN) shows three treads at 250 mm before it turns; it is the stair the basement draws going UP, which had no partner on the ground floor.",
    confirm="Is a stair that turns after three drawn treads normal in your drawings, and is UP or DN always written beside it?"),
  _p("P49-3", "B", "Plan run of a stair", "The detail prints the number of risers (steps) of the stair. The concrete is the plan run x the width x an equivalent thickness. What is the plan run?",
    "One tread fewer than the risers: the top riser meets the floor or the landing, so a stair of 18 risers has 17 treads (17 x 10 in), not 18. Landings are not included.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1: the stair prints 'NO-Of RISER Steps:18', tread 10 in, riser 7 in; each flight draws 8 treads (two flights of 9 risers); the run was 18 x 254 = 4 572 mm and is now 17 x 254 = 4 318 mm, 5.6 percent less concrete per stair.",
    confirm="Does your workbook take the run of a stair as the risers less one, times the tread?"),
  _p("P49-4", "B", "Rise of the stair against the storey", "The stair prints the riser and the number of risers. The storey height is printed on the sections. Do they agree?",
    "The rise (risers x riser) is set beside the floor-to-floor height of the storey the stair serves; a gap of more than 3 percent is a warning on the stair. Nothing is changed by it.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1: 18 x 177.8 mm = 3 200.4 mm, the floor-to-floor height of the ground and first floors read from the sections (3 200.4 mm): the stair agrees with its storey.",
    confirm="Is 3 percent the gap you would still accept between the rise of the stair and the storey?"),
  _p("P50-1", "B", "Anchorage and starter bars", "The drawing prints the cover and the lap table but no anchorage. How long is the anchorage of a beam bar into its support, and the starter bar of a column bar into its footing?",
    "40 bar diameters at each end of a beam bar and as the starter bar at the foot of a column bar. It is the usual development length of deformed bars in 3000 psi concrete (IS 456 cl. 26.2.1 gives 40 to 55 diameters by grade and concrete); the lap of a column bar stays what the lap table prints, else 40 diameters. The value is still marked assumed; type another to replace it.",
    PRACTICE, VALUE, "Islamabad_Plot_1 page 6 prints the cover (1.5 in), the lap table and the footing sections with a 'Dowel Length' label but no length. Before, the anchorage was 0, so a beam bar was as long as its clear run and a column bar had no starter; the steel review already priced 40 diameters as a what-if.",
    params=("bar_anchor_dia",),
    confirm="Does your workbook add 40 diameters of anchorage to a beam bar at each end and to a column bar at its foot, or another figure?"),
  _p("P50-2", "B", "Column bars read from the column detail", "The column detail draws the section with its bars and writes the bar note beside it. Are those bars the column's steel?",
    "The bars and rings written round a column detail (read from the text, else from the picture, each note read twice in the same place) are the steel of the column that carries its mark. A note on the sheet is kept; the detail fills what the note did not give. A detail that prints two different bar counts, or that differs from the note, applies nothing and lists the numbers.",
    SOFTWARE, SUGGESTION, "Islamabad_Plot_1 page 6: C-2 6-#6 with #3@6 in; C-4 8-#6 with #3@6 in; C-5 4-#5; the second C-3 detail 4-#6 and the first prints 8-#6 and 6-#6 at once (eight bars drawn), so C-3 is listed, not applied. Before, no column had its main bars: only the ring of C1 was read.",
    confirm="When one column detail prints two different bar counts, should the drawn bars be counted, or should the person always be asked?"),
  _p("P51-1", "B", "A printed note against the size drawn", "A note prints a thickness (a slab, a concrete wall) and the plan draws something a little different. Which one is measured?",
    "The drawn size is measured and the note is never applied over it. A drawn thickness within 10 mm (3/8 in) of the note agrees with it; a thicker or thinner one is listed under the note as a contradiction, with both numbers and the pages, for the person to settle. It is the usual rule of IS 1200: measure what is drawn, check it against what is written.",
    PRACTICE, KEPT, "Islamabad_Plot_1: the note '9\" Thick R.c.c Wall' (pages 4, 5, 6) agrees with the walls drawn 223 to 232 mm thick; the section label '6\" Thick R.c.c Slab' (page 5) does not agree with the slab items measured at 5 in from the plan note, and is listed.",
    confirm="Is 10 mm (3/8 in) the gap you would still call the same thickness, and do you want a larger gap to stop the item being accepted?"),
  _p("P51-2", "B", "A stair width printed beside a stair against the general note", "The sheet prints 'Stair Width = 3'-6\"' and a stair has 3'-0\" printed beside it. Which width is measured?",
    "The width printed beside the stair is measured for that stair, and the general note is listed as a contradiction. A figure written on the stair itself is the closer evidence; a general note is the fallback.",
    PRACTICE, KEPT, "Islamabad_Plot_1: the note on page 5 gives 3'-6\" (1 066.8 mm); the stairs on pages 1 and 4 are measured at 3'-0\" (914.4 mm) from the width printed beside them.",
    confirm="For a stair with its own width printed beside it, is the width beside it the one to bill, or the general note?"),
  _p("P51-3", "B", "A layer the specification prints but no item exists for", "The specification block prints a layer under a floor (a cement sand bed under the tiles). Is it billed?",
    "It is listed as 'no item is made' and is not in the bill. Only the layers that have a work item (the plain concrete bed, the brick ballast and the sand filling) are made, and a layer with no item is never guessed into the bill. This is a gap to close by giving the layer an item (the finishes pack), not by estimating.",
    SOFTWARE, HOLD, "Architectural_Drawings_10_Marla_House pages 6 and 9: the plain concrete bed, brick ballast and sand filling are made under the ground floor; the cement sand bed is printed and left out.",
    confirm="Is the cement sand bed under the floor finish billed as its own item, and in what unit (area or volume)?"),
  _p("P52-1", "B", "When a read should not be relied on", "A sheet was read with an older version of the reader, has no usable scale, or an accepted item has lost its measurement. Should the quantities still be used?",
    "They are shown, and the integrity panel says what to look at. Nothing is blocked and no quantity is changed: a sheet read by an older reader is flagged so it is read again before the bill is trusted, and a sheet with no scale gives no length or area at all.",
    SOFTWARE, KEPT, "The panel flags: a sheet read with a reader older than the code (the panel names the version), a scale taken from the title block and not confirmed by a measured dimension, an accepted item whose measurement was deleted, a sheet read from a scan, and a printed note the drawing contradicts.",
    confirm="Should the bulk accept be held back while the panel has something to look at, or is a warning enough?"),
  _p("P53-1", "A", "Where the wall height, the tie band and the lintel net are decided", "P43-1 and P44-1 wait for a person. Where is the choice made, and what happens to what was already read?",
    "On the drawing, on screen, in the Decisions panel; the choice is saved with the drawing. Until a person chooses, the default stays (floor to floor; the tie band and the roof band as one member; brick net of its lintels). A choice applies to the sheets read after it. A sheet read before it is listed, and read again on request. An item already accepted keeps the value it was accepted with, and the panel says how many those are.",
    SOFTWARE, KEPT, "Islamabad_Plot_1, four floors read with the defaults: brick 180.93 m3. Floor to floor against the plinth beam off the basement 176.38 m3 (-4.56), between the beams 171.42 m3 (-9.51), clear height 170.27 m3 (-10.67). Tie band and roof band as one member: 306.5 cft of band and lintel concrete; the tie band listed as well: 618.4 cft (+311.9). The brick net of 52 lintels: 2.97 m3 off.",
    confirm="Should a choice made for one drawing be offered as the default for the next drawing of the same project?"),
  _p("P57-1", "L", "Which openings come off each work item", "Does one rule decide which openings come off, whatever the work item, or has each work item its own?",
    "The default stays the QS sheet's single rule (an opening of 0.5 m2 or more comes off, a smaller one does not). A person can choose IS 1200 per work item for a drawing, in the Decisions panel. Under it: brickwork takes off every opening of 0.1 m2 or more (Part 3); an RCC wall every opening of 0.4 m2 or more (Part 5, clause 6.4, each opening, for the formwork; the concrete uses the same size so concrete and formwork agree, assumed); plaster and paint nothing under 0.5 m2, one face only from 0.5 to 3 m2, every face above 3 m2 with the reveals added to the inside (Part 12). The reveals of an opening that does not come off are not added to the wall formwork. Damp proof course is unchanged: the door widths come off, as before (no size rule found in IS 1200 for it).",
    PRACTICE, SUGGESTION,
    "Islamabad_Plot_1, four floors: no wall opening is under 0.5 m2 (the smallest is the 0.557 m2 ventilator), so brick and RCC wall do not change; plaster 4 252.8 m2 on the sheet's rule, 4 455.8 m2 under IS 1200 (+203.1), paint the same +203.1. Architectural_Drawings_10_Marla_House: one 914 x 508 mm window (0.465 m2) comes off the brick under IS 1200, +0.106 m3 less brick (a 9 in wall). Sources: IS 1200 Part 3 (brickwork), Part 5 clause 6.4 (formwork, 'each of opening', amendment 1) and Part 12 (plastering). The 0.1 m2 brick figure is taken from published summaries of Part 3, because the printed clause could not be read clearly; the concrete size of an RCC wall (Part 2) was not found, so the formwork size is used.",
    confirm="Does the QS's sheet take off an opening of 0.1 m2 or more from the brick, or only from 0.5 m2? Does it take plaster off one face for openings between 0.5 and 3 m2?"),
  _p("P58-1", "R", "Roof deck: turn-up at the parapet and the fall", "How high is the waterproofing membrane (and the screed over it) turned up the parapet, and how thick is the coba that gives the fall?",
    "The membrane and the screed are turned up 300 mm along the roof edge (the roof edge is the perimeter of the roof as printed), added to the roof area; the setting is roof_turnup_mm and 0 leaves it out. The coba is the average of the thin and the thick end when the drawing prints both (4 in to 7 in is 5.5 in, 139.7 mm), else the standard 100 mm. A thickness set in the run settings is used before either.",
    PRACTICE, SUGGESTION,
    "A membrane is carried up the parapet to at least 150 mm above the finished roof and chased into the wall, 300 mm being the usual height; the height is assumed here because the parapet detail of Architectural_Drawings_10_Marla_House prints 1'-6\", 1'-3\", 9\" and 3\" without tying one of them to the turn-up. Islamabad_Plot_1 roof (the mumty, 15 x 32 ft, 44.59 m2): 28.65 m of edge, 8.60 m2 of turn-up on the membrane and on the screed. The Islamabad set prints no fall, so its coba stays at 100 mm; the architectural set prints 4 in to 7 in (139.7 mm average, +39.7 mm on the standard).",
    confirm="Does the QS's sheet turn the membrane up the parapet, and to what height? Is the coba measured at the average of the thin and the thick end?"),
  _p("P59-1", "F", "Formwork joints: lintel on the wall, chajja, balcony", "Where the form of one member stops because another member is there, does the QS take that face off?",
    "On by default (pack 72; a run can turn it off with `formwork_joints` = 0). When on: (1) the soffit of a lintel over its bearing on the wall takes no form (2 x the bearing, 152.4 mm each end, times the lintel width; a bearing is never more than half the lintel); (2) a chajja is cast with the lintel it springs from, so the outer side of that lintel is covered over the chajja's length by the chajja's thickness; (3) a balcony slab is cast with the floor slab, so that slab's edge is covered over the balcony's joined (longer) side by the thinner of the two thicknesses. The chajja and the balcony already leave their own joined side unshuttered. The plan does not say which lintel a chajja springs from or which slab a balcony joins, so they are matched by floor and flagged.",
    PRACTICE, SUGGESTION,
    "Formwork is the surface of concrete that touches the form: concrete resting on masonry, or cast together with the next member, has no form on that face. The bearing length is the 152.4 mm the lintel length already includes (span + 2 x bearing). Islamabad_Plot_1: 111 lintel marks read, 99.52 m2 of lintel formwork, of which 7.07 m2 (7.1 %) is soffit over the bearings. Neither set yet gives a chajja or a balcony slab as a measured item, so those two joints are tested on hand-made members only. I could not read the IS 1200 formwork clause itself, so this rests on the contact principle and not on a clause.",
    confirm="Does the QS's formwork for a lintel include the soffit over its bearing on the wall? Is the side of a lintel under a chajja measured whole or less the chajja's thickness? Is the edge of the floor slab at a balcony measured whole?"),
]

ANSWERED = {"P43-1": "R1", "P44-1": "R2", "P45-1": "R7", "P45-2": "R3", "P45-3": "R4", "P69-1": "R5", "P24-5": "R6", "P28-1": "R13", "P60-1": "R9", "P60-3": "R11",
  "P63-1": "R15", "P83-1": "R15", "P70-1": "R19", "P24-10": "R17"}

SIZE_VALUES = {
  "beam_depth_mm":{"mm": 228.6, "text": "0.75 ft", "evidence": "Concrete Work, ROOF BEAMS on every floor: 0.75 ft wide (0.375 ft on a 4.5 in wall) and 0.75 ft deep."},
  "plinth_beam_depth_mm": {"mm": 457.2, "text": "1.5 ft", "evidence": "Plinth Beam sheet: 0.75 ft wide and 1.5 ft deep under a 9 in wall; none under a 4.5 in wall."},
  "neck_height_mm": {"mm": 1066.8, "text": "3.5 ft", "evidence": "Concrete Work, NECK COLUMNS: C-1, C-2 and C-3 are 3.5 ft high."},
  "tank_wall_height_mm": {"mm": 1524.0, "text": "5 ft", "evidence": "Concrete Work, UGWT and OHWT: the long and short walls are 5 ft high."},
}

def _ft(mm: float) -> str:
  return f"{mm / 304.8:g} ft"

def sizes() -> dict:
  out = {}
  for k, v in SIZE_VALUES.items():
    row = dict(v)
    held = CO.value(k)
    if held is not None and not (CO.origin_of(k) == CO.QS_WORKBOOK and abs(float(held) - v["mm"]) < 1e-9):
      row = {"mm": float(held), "text": _ft(float(held)), "evidence": "Set by your company as its own convention."}
    row["origin"] = CO.origin_of(k)
    out[k] = row
  return out

def param(name: str):
  return PARAM_VALUES.get(name)

def is_proposed(name: str) -> bool:
  return name in PARAM_VALUES

def by_effect() -> dict:
  out = {e: 0 for e in EFFECTS}
  for p in PROPOSALS:
    out[p["effect"]] += 1
  return out

def public() -> dict:
  return {"note": PROPOSED_BY, "bases": dict(BASIS_TEXT), "effects": dict(EFFECT_TEXT), "params": dict(PARAM_VALUES), "evidence": dict(PARAM_EVIDENCE), "sizes": sizes(),
    "items": [{**p, "confirm": None if p["id"] in ANSWERED else p["confirm"], "answered_by": ANSWERED.get(p["id"])} for p in PROPOSALS], "counts": by_effect()}

def _inch(mm: float) -> str:
  return f"{mm / 25.4:g}"

def depth_assumed(item: str):
  """The depth used for a foundation item when the drawing prints none: {"mm", "basis", "text"}, or None for an item with no such depth."""
  if item == "EXCAVATION_AREA":
    mm = float(CO.pick("basement_dig_mm", BASEMENT_DIG_MM))
    own = CO.origin_of("basement_dig_mm") == CO.COMPANY and abs(mm - BASEMENT_DIG_MM) > 1e-9
    return {"mm": mm, "basis": WORKBOOK, "origin": CO.origin_of("basement_dig_mm"),
      "text": f"your company's convention digs the basement {_ft(mm)} deep" if own else f"the QS's workbook digs the basement {mm / 304.8:g} ft deep (the 'Complete Area' line, 30 x 54 x 8 ft)"}
  if item == "TRENCH":
    mm = float(CO.pick("trench_depth_mm", TRENCH_DEPTH_MM))
    own = CO.origin_of("trench_depth_mm") == CO.COMPANY and abs(mm - TRENCH_DEPTH_MM) > 1e-9
    return {"mm": mm, "basis": WORKBOOK, "origin": CO.origin_of("trench_depth_mm"),
      "text": f"your company's convention digs the wall trenches {_ft(mm)} deep" if own else f"the QS's workbook digs the wall trenches {mm / 304.8:g} ft deep"}
  if item == "EARTH_FILL":
    mm = float(CO.pick("fill_depth_mm", FILL_DEPTH_MM))
    own = CO.origin_of("fill_depth_mm") == CO.COMPANY and abs(mm - FILL_DEPTH_MM) > 1e-9
    return {"mm": mm, "basis": PRACTICE, "origin": CO.origin_of("fill_depth_mm"),
      "text": f"your company's convention fills {_ft(mm)}, in {round(mm / 152.4)} layers of 6 in" if own else f"{mm / 304.8:g} ft, the usual filling up to the plinth, in {round(mm / 152.4)} layers of 6 in; the workbook has no filling line"}
  return None

def brick_step(strip_class: str, step_no: int):
  heights = BRICK_STEP_HEIGHTS_MM.get(str(strip_class).upper())
  if not heights or not (1 <= int(step_no) <= len(heights)):
    return None
  return {"step_height_mm": heights[int(step_no) - 1], "step_offset_mm": BRICK_STEP_OFFSET_MM}

def brick_step_extra(strip_class: str, step_no: int) -> dict:
  s = brick_step(strip_class, step_no)
  if s is None:
    return {"message": "His workbook has no such step.", "suggest": {}}
  return {"message": f"Suggestion, not an answer from the QS: his workbook gives step {int(step_no)} of a {str(strip_class).lower()} wall a height of {_inch(s['step_height_mm'])} in "
    f"({s['step_height_mm']:g} mm), each step {_inch(s['step_offset_mm'])} in narrower than the one below ({s['step_offset_mm']:g} mm). Type them if they are right.", "suggest": s}
