from __future__ import annotations
from decimal import Decimal
from app.engine.measure.member_steel import FAMILY_OF, STEEL_FAMILIES, clean_steel, member_lines
from app.engine.measure.derived import PARAMS as ENGINE_PARAMS
from app.engine.measure.member_steel_more import MORE_FAMILIES
from app.engine.measure import steel_estimate as SE
from app.modules.drawings_boq.takeoff import repository as TR

CONVENTIONS = {"cover_mm": ENGINE_PARAMS["steel_cover_mm"][0], "hook_dia": ENGINE_PARAMS["ring_hook_dia"][0], "lap_dia": ENGINE_PARAMS["bar_lap_dia"][0],
  "anchor_dia": ENGINE_PARAMS["bar_anchor_dia"][0], "wastage_pct": ENGINE_PARAMS["steel_wastage_pct"][0],
  "steel_estimate_from_volume": ENGINE_PARAMS["steel_estimate_from_volume"][0], "slab_steel_kg_per_m2": ENGINE_PARAMS["slab_steel_kg_per_m2"][0]}
COVER_OF = {"LINTEL": "steel_cover_beam_mm", "BEAM": "steel_cover_beam_mm", "COLUMN": "steel_cover_column_mm", "FOOTING": "steel_cover_footing_mm", "SLAB": "steel_cover_slab_mm", "RCC_WALL": "steel_cover_wall_mm"}
ESTIMATE_NOTE = "This is an estimate from the bars as they stand, before a calculation run; the run adds the project's own steel parameters and can differ by what those add."
CONVENTION_NOTE = ("Cover, hook, lap and anchorage are site conventions. Where the drawing prints a cover or a lap table this roll-up uses it; "
  "otherwise it uses the same defaults as the calculation run, and they are flagged as defaults.")
MM3_PER_M3 = Decimal("1000000000")
MM2_PER_M2 = Decimal("1000000")
RULE_CHECK_NOTE = ("Slabs with printed bars are weighed from their bars. The same slabs are also weighed by the quantity surveyor's rule of thumb (kg per m2 of slab, wastage included) "
  "so the two can be compared; a large difference means the printed bars or the rule deserve a second look. Nothing here changes the weight above.")

def _d(v) -> Decimal | None:
  try:
    x = Decimal(str(v))
  except Exception:
    return None
  return x if x > 0 else None

def _floor(f: dict) -> str | None:
  return f.get("floor") or f.get("level_hint") or (f.get("view") or {}).get("level_hint") or (f.get("floor_union") or {}).get("floor")

def _plate(category: str, length: Decimal, width: Decimal, depth: Decimal) -> tuple:
  if category in ("RCC_WALL", "PARAPET"):
    return length, depth, width
  return length, width, depth

def kind_of(row) -> str:
  """The reinforced kind of a register row: its category, or for a site item the cast item it is (a tank, a parapet)."""
  if row.category == "SITE":
    return TR.FORMWORK_SITE.get((row.facts or {}).get("site_kind"), "SITE")
  return row.category

def _extra(row, cat: str, depth) -> dict | None:
  if cat == "STAIR" and depth:
    return {"stair": TR.stair_detail(row, depth)}
  if cat == "TANK":
    return {"site": TR._tank_detail(row.params or {})}
  return None

def member(row, conv: dict, cat: str | None = None) -> dict:
  p = row.params or {}
  
  steel = clean_steel(p.get("steel"))
  if not steel:
    return {"reason": "NO_BARS", "kg_each": Decimal("0"), "lines": []}
  L, W, D = _d(p.get("length_mm")), _d(p.get("width_mm")), _d(p.get("depth_mm"))
  cat = cat or row.category
  need = (L, W) if cat in ("FOOTING", "SLAB") else (L, W, D)
  if cat == "COLUMN":
    need = (L, W, D)
  if any(v is None for v in need):
    return {"reason": "NO_SIZE", "kg_each": Decimal("0"), "lines": [], "steel": steel}

  length, width, depth = _plate(cat, L, W, D or Decimal("0"))
  cover = (conv.get("cover_by_category") or {}).get(cat, conv["cover_mm"])
  lines, bare = member_lines(cat, length, width, depth, steel, Decimal(str(cover)), Decimal(str(conv["hook_dia"])), Decimal(str(conv["lap_dia"])), Decimal(str(conv["anchor_dia"])),
    conv.get("lap_table_mm") or None, _extra(row, cat, D))
  if bare <= 0:
    return {"reason": "NO_SIZE", "kg_each": Decimal("0"), "lines": [], "steel": steel}
  return {"reason": None, "kg_each": bare, "lines": lines, "steel": steel}

def summary_of(row) -> dict | None:
  cat = kind_of(row)

  if cat not in STEEL_FAMILIES and cat not in MORE_FAMILIES:
    return None
  try:
    got = member(row, resolve(None, None)[0], cat)
  except Exception:
    return None
  if got["reason"]:
    return {"state": got["reason"]}
    
  lines = []
  for ln in got["lines"]:
    try:
      cut = float(ln["cut_length_m"]) if ln.get("cut_length_m") is not None else None
      kg = float(ln["kg"]) if ln.get("kg") is not None else None
    except (TypeError, ValueError):
      cut = kg = None
    lines.append({"role": ln.get("role") or ln.get("kind"), "bar": ln.get("bar"), "count": ln.get("count"), "cut_m": cut, "kg": kg})
  source = (((row.facts or {}).get("steel_source")) or {}).get("grade") or "PRINTED"
  return {"state": "WEIGHED", "kg": round(float(got["kg_each"]), 3), "lines": lines, "source": source}

def resolve(conventions: dict | None, printed: dict | None) -> tuple:
  """The values a roll-up uses and where each came from: what was typed, else what the drawing prints, else the engine default."""
  given = {k: v for k, v in (conventions or {}).items() if k in CONVENTIONS and v is not None}
  conv: dict = {**CONVENTIONS, **given}
  sources = {k: ("user" if k in given else "default") for k in CONVENTIONS}
  params = (printed or {}).get("params") or {}
  by_cat = {c: float(params[n]) for c, n in COVER_OF.items() if params.get(n) is not None}
  
  if "cover_mm" not in given and by_cat:
    conv["cover_by_category"] = by_cat
    sources["cover_mm"] = "drawing"
  table = (printed or {}).get("lap_table_mm") or {}
  if "lap_dia" not in given and table:
    conv["lap_table_mm"] = {k: float(v) for k, v in table.items()}
    sources["lap_dia"] = "drawing"
  return conv, sources

def rollup(rows: list, conventions: dict | None = None, ranges: dict | None = None, printed: dict | None = None) -> dict:

  conv, sources = resolve(conventions, printed)
  wastage = Decimal(str(conv["wastage_pct"]))
  marks: list = []
  without: dict = {}
  no_size = 0
  est_on = float(conv["steel_estimate_from_volume"]) >= 0.5
  est_rule = Decimal(str(conv["slab_steel_kg_per_m2"]))
  est: dict = {"members": 0, "kg": Decimal("0"), "kg_low": Decimal("0"), "kg_high": Decimal("0"), "by_family": {}, "not_estimated": {}}
  rule_check = {"slabs": 0, "bar_kg": Decimal("0"), "rule_kg": Decimal("0")}
  by_family: dict = {}
  by_dia: dict = {}
  total = Decimal("0")
  for r in rows:
    cat = kind_of(r)
    if r.decision == "REJECTED" or (cat not in STEEL_FAMILIES and cat not in MORE_FAMILIES):
      continue
  
    n = int(r.count or 1)
    got = member(r, conv, cat)
    fam = FAMILY_OF.get(cat, cat)
    if got["reason"] == "NO_BARS":
      slot = without.setdefault(fam, {"members": 0, "marks": []})
      slot["members"] += n
      if r.tag and r.tag not in slot["marks"]:
        slot["marks"].append(r.tag)
      if est_on:
        p_ = r.params or {}
        fg = SE.figure(cat, p_.get("length_mm"), p_.get("width_mm"), p_.get("depth_mm"), est_rule, wastage)
        if fg is None:
          est["not_estimated"][fam] = est["not_estimated"].get(fam, 0) + n
        else:
          est["members"] += n
          slot_e = est["by_family"].setdefault(fam, {"members": 0, "kg": Decimal("0"), "kg_low": Decimal("0"), "kg_high": Decimal("0")})
          for key in ("kg", "kg_low", "kg_high"):
            est[key] += fg[key] * n
            slot_e[key] += fg[key] * n
          slot_e["members"] += n
      continue
    if got["reason"] == "NO_SIZE":
      no_size += n
      continue
  
    kg = (got["kg_each"] * n * (1 + wastage / 100)).quantize(Decimal("0.000001"))
    total += kg
    f = r.facts or {}
    src = ((f.get("steel_source") or {}).get("grade")) or "PRINTED"
    p = r.params or {}
    conc = None
    
    if all(_d(p.get(k)) is not None for k in ("length_mm", "width_mm", "depth_mm")):
      conc = Decimal(str(p["length_mm"])) * Decimal(str(p["width_mm"])) * Decimal(str(p["depth_mm"])) * n / MM3_PER_M3
    if cat in SE.SLAB_CATEGORIES and est_rule > 0 and all(_d(p.get(k)) is not None for k in ("length_mm", "width_mm")):
      area_m2 = Decimal(str(p["length_mm"])) * Decimal(str(p["width_mm"])) * n / MM2_PER_M2
      rule_check["slabs"] += n
      rule_check["bar_kg"] += kg
      rule_check["rule_kg"] += area_m2 * est_rule * (1 + wastage / 100)
    marks.append({"item_ids": [str(r.id)], "tag": r.tag, "category": r.category, "family": fam, "floor": _floor(f), "count": n, "decision": r.decision,
      "steel_text": f.get("steel_text"), "source": src, "kg_each": float(got["kg_each"]), "kg": float(kg), "concrete_m3": float(conc) if conc is not None else None,
      "lines": [{"role": ln.get("role") or ln.get("kind"), "bar": ln.get("bar"), "dia_mm": float(ln["dia_mm"]) if ln.get("dia_mm") is not None else None, "count": ln.get("count"),
        "cut_m": float(ln["cut_length_m"]) if ln.get("cut_length_m") is not None else None, "kg": float(ln["kg"]) if ln.get("kg") is not None else None} for ln in got["lines"]]})
    slot = by_family.setdefault(fam, {"marks": 0, "members": 0, "kg": Decimal("0"), "bare_kg": Decimal("0"), "kg_sized": Decimal("0"), "concrete_m3": Decimal("0")})
    slot["marks"] += 1
    slot["members"] += n
    slot["kg"] += kg
    slot["bare_kg"] += got["kg_each"] * n
    if conc is not None:
      slot["kg_sized"] += got["kg_each"] * n
      slot["concrete_m3"] += conc
    for ln in got["lines"]:
      d = by_dia.setdefault(str(Decimal(ln["dia_mm"]).quantize(Decimal("0.1"))), {"kg": Decimal("0"), "length_m": Decimal("0")})
      d["kg"] += Decimal(ln["kg"]) * n
      d["length_m"] += Decimal(ln["length_m"]) * n
      
  fam_out = {}
  for fam, s in sorted(by_family.items()):
    band = (ranges or {}).get(fam)
    value = float(s["kg_sized"] / s["concrete_m3"]) if s["concrete_m3"] > 0 else None
    status = None
    
    if value is not None and band:
      status = "BELOW_RANGE" if value < band[0] else "ABOVE_RANGE" if value > band[1] else "IN_RANGE"
    fam_out[fam] = {"marks": s["marks"], "members": s["members"], "kg": float(s["kg"]), "concrete_m3": float(s["concrete_m3"]) if s["concrete_m3"] > 0 else None,
      "kg_per_m3": round(value, 1) if value is not None else None, "range": list(band) if band else None, "status": status}
  scalars = {k: float(conv[k]) for k in CONVENTIONS}
  return {"ran": bool(marks), "kg": float(total), "conventions": scalars, "sources": sources, "printed": {"cover_mm_by_category": conv.get("cover_by_category") or {}, "lap_table_mm": conv.get("lap_table_mm") or {}},
    "estimate": True, "estimate_note": ESTIMATE_NOTE, "conventions_assumed": conventions is None, "convention_note": CONVENTION_NOTE,
    "by_family": fam_out, "by_diameter": {k: {"kg": float(v["kg"]), "length_m": float(v["length_m"])} for k, v in sorted(by_dia.items(), key=lambda kv: float(kv[0]))},
    "marks": sorted(marks, key=lambda m: (m["family"], str(m["floor"] or ""), str(m["tag"] or ""))),
    "without_steel": {"members": sum(v["members"] for v in without.values()), "by_family": without},
    "unprinted": {"enabled": est_on, "members": est["members"], "kg": float(est["kg"]), "kg_low": float(est["kg_low"]), "kg_high": float(est["kg_high"]),
      "kg_with_printed": float(total + est["kg"]), "kg_low_with_printed": float(total + est["kg_low"]), "kg_high_with_printed": float(total + est["kg_high"]),
      "slab_rule_kg_per_m2": float(est_rule) if est_rule > 0 else None,
      "by_family": {k: {"members": v["members"], "kg": float(v["kg"]), "kg_low": float(v["kg_low"]), "kg_high": float(v["kg_high"])} for k, v in sorted(est["by_family"].items())},
      "not_estimated": dict(sorted(est["not_estimated"].items()))},
    "slab_rule_check": {"rule_kg_per_m2": float(est_rule) if est_rule > 0 else None, "slabs": rule_check["slabs"], "bar_kg": float(rule_check["bar_kg"]), "rule_kg": float(rule_check["rule_kg"]),
      "difference_pct": round(float((rule_check["bar_kg"] / rule_check["rule_kg"] - 1) * 100), 1) if rule_check["rule_kg"] > 0 else None, "note": RULE_CHECK_NOTE},
    "without_size": no_size}
