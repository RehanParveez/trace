from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
import re
import math
import time
import ifcopenshell
import numpy as np
import ifcopenshell.util.element
import ifcopenshell.util.placement
import ifcopenshell.util.unit
from functools import lru_cache
from app.engine.measure.steel import is_steel_role
from app.engine.measure.spatial import PRISM_VOLUME_TOLERANCE
from app.modules.drawings_boq.ifc_types import (COUNT_ROLES, DEFAULT_DISCIPLINE, DEFAULT_MESH_FALLBACK_LIMIT, IFC_MESH_BUDGET_S, DEFAULT_QUANTITY_KIND_ORDER, DISCIPLINE_BY_ROLE, EXCLUDED_IFC_TYPES, LINEAR_ROLES,
  LOW_CLASSIFICATION_CONFIDENCE, MESH_FALLBACK_ROLES, NAME_KEYWORD_ROLES, NO_LEGACY_BOQ_ROLES, PREDEFINED_TYPE_ROLE_OVERRIDES, QUANTITY_KIND_ORDER_BY_ROLE, QUANTITY_PROPS_BY_KIND,
  REQUIRED_DIMENSIONS_BY_ROLE, ROLE_BY_IFC_TYPE, SLAB_ROLES, SUPERTYPE_FALLBACK_TYPES, WALL_ROLES,
)

MATERIAL_TEXT_MAX = 300
_KEYWORD_PATTERNS = [
  (re.compile(rf"(?<![a-z]){re.escape(keyword)}(?:s|es)?(?![a-z])"), role)
  for keyword, role in NAME_KEYWORD_ROLES
]
_MM3_PER_M3 = 1_000_000_000.0
QTO_MESH_TOLERANCE = 0.02
CONCRETE_ONLY_ROLES = frozenset({"COLUMN", "BEAM", "SLAB", "SLAB_FOUNDATION", "SLAB_ROOF", "WALL", "WALL_EXTERNAL", "WALL_INTERNAL", "FOOTING", "PILE", "PILE_CAP", "STAIR"})
LEVEL_TOLERANCE_MM = 500.0
STOREY_FREE_ROLES = frozenset({"FOOTING", "PILE", "CAISSON", "SLAB_FOUNDATION", "EARTHWORKS", "EARTHWORKS_CUT", "EARTHWORKS_FILL", "PAVEMENT", "COURSE", "KERB", "WALL_FOUNDATION"})
NOT_FLOOR_SLAB_ROLES = frozenset({"SLAB_FOUNDATION", "SLAB_LANDING"})
_CONCRETE_TEXT = re.compile(r"concrete|cement|\brcc\b|grout", re.I)
_PILE_CAP_NAME = re.compile(r"(?<![a-z])pile[\s_\-]*caps?(?![a-z])", re.I)
_PILE_NAME = re.compile(r"(?<![a-z])piles?(?![a-z])", re.I)
_PILE_REFINABLE_ROLES = frozenset({"SLAB", "SLAB_FOUNDATION", "FOOTING", "COLUMN", "MEMBER", "UNKNOWN"})
_FOUNDATION_WALL_ROLES = frozenset({"WALL", "WALL_EXTERNAL", "WALL_INTERNAL", "WALL_LOAD_BEARING"})
_FOUNDATION_WALL_NAME = re.compile(r"(?<![a-z])(foundation|footing|plinth)[\s_\-]*walls?(?![a-z])|(?<![a-z])walls?[\s_\-]*(foundation|plinth)(?![a-z])", re.I)
_STEEL_NAME = re.compile(r"\bsteel\b|\b(UB|UC|PFC|RHS|SHS|CHS|IPE|HEA|HEB)\s?\d{2,4}", re.I)
_NON_CONCRETE_PATTERNS = (
  ("ALUMINIUM", re.compile(r"\b(aluminium|aluminum)\b", re.I)),
  ("STEEL", re.compile(r"\b(steel|metal|iron)\b|\b(UB|UC|PFC|RHS|SHS|CHS|IPE|HEA|HEB)\s?\d{2,4}", re.I)),
  ("TIMBER", re.compile(r"\b(timber|wood|plywood|lvl)\b", re.I)),
)
_MM2_PER_M2 = 1_000_000.0
 
@dataclass
class ReadLevel:
  global_id: str
  name: str
  elevation_mm: Decimal | None
  sequence: int
 
@dataclass
class ReadElement:
  step_id: int
  global_id: str | None
  ifc_type: str
  name: str | None
  raw_material_text: str
  is_generic_fallback: bool
  discipline: str
  structural_role: str
  classification_source: str
  classification_confidence: Decimal
  level_global_id: str | None = None
  unit: str | None = None
  quantity: Decimal = Decimal("0")
  quantity_source: str = "NONE"
  length_mm: Decimal | None = None
  width_mm: Decimal | None = None
  height_mm: Decimal | None = None
  thickness_mm: Decimal | None = None
  area_mm2: Decimal | None = None
  volume_mm3: Decimal | None = None
  elevation_base_mm: Decimal | None = None
  elevation_top_mm: Decimal | None = None
  bbox_min_mm: tuple[Decimal, Decimal, Decimal] | None = None
  bbox_max_mm: tuple[Decimal, Decimal, Decimal] | None = None
  geometry_kind: str = "UNSUPPORTED"
  profile: dict | None = None
  placement: dict | None = None
  properties: dict = field(default_factory=dict)
  status: str = "VALID"
  issues: list[dict] = field(default_factory=list)
  type_mark: str | None = None
  type_name: str | None = None
 
@dataclass
class IfcReadResult:
  schema: str
  length_unit_scale: float  
  levels: list[ReadLevel]
  elements: list[ReadElement]
  model_issues: list[dict]
  stats: dict
  spaces: list = field(default_factory=list)
  boundaries: list = field(default_factory=list)
  relations: list = field(default_factory=list)
  header: dict = field(default_factory=dict)
 
@dataclass
class _Scales:
  length_m: float
  area_m2: float
  volume_m3: float
  ambiguous: bool
 
  @property
  def mm_per_unit(self) -> float:
    return self.length_m * 1000.0
 
@dataclass
class _Geometry:
  kind: str = "UNSUPPORTED"
  profile: dict | None = None
  placement: dict | None = None
  bbox_min: np.ndarray | None = None 
  bbox_max: np.ndarray | None = None  
  dims: dict = field(default_factory=dict)  
  profile_area_mm2: float | None = None
  depth_mm: float | None = None
  mesh_volume_mm3: float | None = None
  body: str | None = None               
  net_mm3: float | None = None          
  openings: int = 0
  openings_mm3: float | None = None     
  openings_cutter_mm3: float | None = None   
  issues: list[dict] = field(default_factory=list)
 
def humanize_ifc_type(ifc_type: str) -> str:
  """'IfcWallStandardCase' -> 'Wall Standard Case'."""
  stripped = ifc_type[3:] if ifc_type.startswith("Ifc") else ifc_type
  return re.sub(r"(?<!^)(?=[A-Z])", " ", stripped).strip()
 
def _issue(code: str, severity: str, message: str) -> dict:
  return {"code": code, "severity": severity, "message": message}
 
def _num(value) -> float | None:
  if value is None or isinstance(value, bool):
    return None
  try:
    number = float(value)
  except (TypeError, ValueError):
    return None
  return number if math.isfinite(number) else None
 
def _dec(value: float | None, places: int = 3) -> Decimal | None:
  if value is None or not math.isfinite(value):
    return None
  return Decimal(str(round(value, places)))
 
def _json_safe(value):
  if isinstance(value, dict):
    return {str(k): _json_safe(v) for k, v in value.items()}
  if isinstance(value, (list, tuple)):
    return [_json_safe(v) for v in value]
  if isinstance(value, str):
    return value.replace("\x00", "")
  if isinstance(value, (bool, int)) or value is None:
    return value
  if isinstance(value, float):
    return value if math.isfinite(value) else None
  if isinstance(value, ifcopenshell.entity_instance):
    return {"ifc_entity": value.is_a(), "step_id": value.id()}
  return str(value)
 
def _clean(text) -> str | None:
  if text is None:
    return None
  cleaned = str(text).strip()
  return cleaned or None
 
def _resolve_scales(model) -> _Scales:
  projects = model.by_type("IfcProject")
  units_ctx = projects[0].UnitsInContext if projects else None
  assigned = {
    u.UnitType for u in (units_ctx.Units if units_ctx else []) if hasattr(u, "UnitType")
  }
 
  def _scale(unit_type: str) -> float | None:
    if unit_type not in assigned:
      return None
    try:
      value = float(ifcopenshell.util.unit.calculate_unit_scale(model, unit_type))
    except Exception:
      return None
    return value if value > 0 else None
 
  length = _scale("LENGTHUNIT")
  ambiguous = length is None
  length = length or 1.0
  area = _scale("AREAUNIT") or length**2
  volume = _scale("VOLUMEUNIT") or length**3
  return _Scales(length_m=length, area_m2=area, volume_m3=volume, ambiguous=ambiguous)
 
def _read_levels(model, scales: _Scales) -> list[ReadLevel]:
  raw: list[tuple[float | None, str, str]] = []
  for storey in model.by_type("IfcBuildingStorey"):
    elevation = _num(getattr(storey, "Elevation", None))
    if elevation is None and storey.ObjectPlacement is not None:
      try:
        matrix = ifcopenshell.util.placement.get_local_placement(storey.ObjectPlacement)
        elevation = float(matrix[2][3])
      except Exception:
        elevation = None
    elevation_mm = elevation * scales.mm_per_unit if elevation is not None else None
    raw.append((elevation_mm, _clean(storey.Name) or "Level", storey.GlobalId))
  raw.sort(key=lambda r: (r[0] if r[0] is not None else math.inf, r[1], r[2]))
  return [
    ReadLevel(global_id=gid, name=name, elevation_mm=_dec(elev), sequence=idx)
    for idx, (elev, name, gid) in enumerate(raw)
  ]
 
def _material_family(material_text, name, role) -> str:
  if material_text and _CONCRETE_TEXT.search(material_text):
    return "CONCRETE_OR_UNKNOWN"
  haystack = f"{material_text or ''} {name or ''}"
  for family, pattern in _NON_CONCRETE_PATTERNS:
    if pattern.search(haystack):
      return family
  return "CONCRETE_OR_UNKNOWN"

def _storey_of(element) -> str | None:
  try:
    container = ifcopenshell.util.element.get_container(element)
    hops = 0
    while container is not None and not container.is_a("IfcBuildingStorey") and hops < 5:
      parent = ifcopenshell.util.element.get_aggregate(container)
      container = parent or ifcopenshell.util.element.get_container(container)
      hops += 1
  except Exception:
    return None
  if container is not None and container.is_a("IfcBuildingStorey"):
    return container.GlobalId
  return None
 
def _level_by_elevation(levels: list[ReadLevel], base_mm: float | None) -> str | None:
  if base_mm is None:
    return None
  chosen = None
  for level in levels:
    if level.elevation_mm is None:
      continue
    if float(level.elevation_mm) <= base_mm + 500.0:
      chosen = level.global_id
  return chosen
 
def _material_names(material) -> list[str]:
  names: list[str] = []
  if material is None:
    return names
  if material.is_a("IfcMaterial"):
    name = _clean(material.Name)
    return [name] if name else []
  if material.is_a("IfcMaterialLayerSetUsage"):
    return _material_names(material.ForLayerSet)
  if material.is_a("IfcMaterialProfileSetUsage"):
    return _material_names(material.ForProfileSet)
  if material.is_a("IfcMaterialLayerSet"):
    for layer in material.MaterialLayers or []:
      names += _material_names(layer.Material)
    return names
  if material.is_a("IfcMaterialProfileSet"):
    for profile in material.MaterialProfiles or []:
      names += _material_names(profile.Material)
    return names
  if material.is_a("IfcMaterialConstituentSet"):
    for constituent in material.MaterialConstituents or []:
      names += _material_names(constituent.Material)
    return names
  if material.is_a("IfcMaterialList"):
    for item in material.Materials or []:
      names += _material_names(item)
    return names
  name = _clean(getattr(material, "Name", None))
  return [name] if name else []
 
def _material_text(element) -> str | None:
  try:
    material = ifcopenshell.util.element.get_material(element)
    names = _material_names(material)
    set_name = None
    if material is not None and material.is_a("IfcMaterialLayerSetUsage"):
      set_name = _clean(getattr(material.ForLayerSet, "LayerSetName", None))
    elif material is not None and material.is_a("IfcMaterialLayerSet"):
      set_name = _clean(material.LayerSetName)
  except Exception:
    return None
  if set_name:
    return set_name[:MATERIAL_TEXT_MAX]
  if not names:
    return None
  unique = list(dict.fromkeys(names))
  return " / ".join(unique)[:MATERIAL_TEXT_MAX]

MAX_LAYERS = 30

def _constituent_layers(material) -> list[dict]:
  out: list[dict] = []
  for item in list(material.MaterialConstituents or [])[:MAX_LAYERS]:
    out.append({
      "name": _clean(getattr(item, "Name", None)),
      "material": _clean(getattr(item.Material, "Name", None)) if getattr(item, "Material", None) is not None else None,
      "thickness_mm": None,
      "category": _clean(getattr(item, "Category", None)),
      "kind": "constituent",
    })
  return out

def _material_layers(element, scales) -> list[dict]:
  """The layers of a layered element (wall, slab, roof), outside first, as the model gives them."""
  try:
    material = ifcopenshell.util.element.get_material(element)
    if material is None:
      return []
    if material.is_a("IfcMaterialLayerSetUsage"):
      layer_set = material.ForLayerSet
    elif material.is_a("IfcMaterialLayerSet"):
      layer_set = material
    elif material.is_a("IfcMaterialConstituentSet"):
      return _constituent_layers(material)
    else:
      return []
    
    out: list[dict] = []
    for layer in list(layer_set.MaterialLayers or [])[:MAX_LAYERS]:
      thickness = getattr(layer, "LayerThickness", None)
      mm = round(float(thickness) * scales.mm_per_unit, 3) if thickness else None
      out.append({
        "name": _clean(getattr(layer, "Name", None)),
        "material": _clean(getattr(layer.Material, "Name", None)) if getattr(layer, "Material", None) is not None else None,
        "thickness_mm": mm if mm and mm > 0 else None,
      })
    return out
  except Exception:
    return []
 
@lru_cache(maxsize=None)
def _type_chain(schema_id: str, ifc_type: str) -> tuple[str, ...]:
  """('IfcWallStandardCase', 'IfcWall', 'IfcBuildingElement', 'IfcElement', ...)."""
  try:
    entity = ifcopenshell.ifcopenshell_wrapper.schema_by_name(schema_id).declaration_by_name(ifc_type).as_entity()
  except Exception:
    return (ifc_type,)
  chain: list[str] = []
  while entity is not None:
    chain.append(entity.name())
    entity = entity.supertype()
  return tuple(chain)
 
def _classify(element, psets: dict, schema_id: str) -> tuple[str, str, float]:
  role, source, confidence = _classify_base(element, psets, schema_id)
  if role in _PILE_REFINABLE_ROLES and element.is_a() != "IfcPile":
    text = " ".join(str(v) for v in (getattr(element, "Name", None), getattr(element, "ObjectType", None)) if v)
    if _PILE_CAP_NAME.search(text):
      return "PILE_CAP", "NAME_REFINED", 0.8
    if _PILE_NAME.search(text):
      return "PILE", "NAME_REFINED", 0.8
  if role in _FOUNDATION_WALL_ROLES:
    wall_text = " ".join(str(v) for v in (getattr(element, "Name", None), getattr(element, "ObjectType", None)) if v)
    if _FOUNDATION_WALL_NAME.search(wall_text):
      return "WALL_FOUNDATION", "NAME_REFINED", 0.8
  return role, source, confidence

def _classify_base(element, psets: dict, schema_id: str) -> tuple[str, str, float]:
  chain = _type_chain(schema_id, element.is_a())
  matched = next((name for name in chain if name in ROLE_BY_IFC_TYPE), None)
  role = ROLE_BY_IFC_TYPE[matched] if matched else "UNKNOWN"
 
  if role != "UNKNOWN":
    predefined = _clean(getattr(element, "PredefinedType", None))
    if predefined:
      for name in chain:
        override = PREDEFINED_TYPE_ROLE_OVERRIDES.get((name, predefined))
        if override:
          return override, "PREDEFINED_TYPE", 0.98
    if role == "WALL":
      common = psets.get("Pset_WallCommon") or {}
      if common.get("LoadBearing") is True:
        return "WALL_LOAD_BEARING", "PSET", 0.95
      is_external = common.get("IsExternal")
      
      if is_external is True:
        return "WALL_EXTERNAL", "PSET", 0.95
      if is_external is False:
        return "WALL_INTERNAL", "PSET", 0.95
    if matched in SUPERTYPE_FALLBACK_TYPES:
      return role, "IFC_SUPERTYPE", 0.7
    return role, "IFC_TYPE", 0.95
 
  raw = " ".join(
    str(v) for v in (getattr(element, "Name", None), getattr(element, "ObjectType", None)) if v
  ).lower()
  haystack = " " + re.sub(r"[\s_\-:.,/]+", " ", raw) + " "
  for pattern, keyword_role in _KEYWORD_PATTERNS:
    if pattern.search(haystack):
      return keyword_role, "NAME_HEURISTIC", 0.4
  return "UNKNOWN", "NONE", 0.0
 
def _axis2d(placement) -> tuple[float, float, float, float]:
  if placement is None:
    return 0.0, 0.0, 1.0, 0.0
  loc = placement.Location.Coordinates if placement.Location else (0.0, 0.0)
  x0, y0 = float(loc[0]), float(loc[1])
  ref = placement.RefDirection.DirectionRatios if getattr(placement, "RefDirection", None) else (1.0, 0.0)
  rx, ry = float(ref[0]), float(ref[1])
  norm = math.hypot(rx, ry) or 1.0
  return x0, y0, rx / norm, ry / norm
 
def _apply2d(points, x0, y0, rx, ry):
  return [(x0 + x * rx - y * ry, y0 + x * ry + y * rx) for x, y in points]
 
def _shoelace(points) -> float:
  area = 0.0
  for i in range(len(points)):
    x1, y1 = points[i]
    x2, y2 = points[(i + 1) % len(points)]
    area += x1 * y2 - x2 * y1
  return abs(area) / 2.0
 
def _curve_points(curve) -> list[tuple[float, float]] | None:
  if curve is None:
    return None
  if curve.is_a("IfcPolyline"):
    pts = [(float(p.Coordinates[0]), float(p.Coordinates[1])) for p in curve.Points]
  elif curve.is_a("IfcIndexedPolyCurve"):
    coords = curve.Points.CoordList
    segments = curve.Segments
    if segments:
      if any(seg.is_a("IfcArcIndex") for seg in segments):
        return None
      order: list[int] = []
      for seg in segments:
        for idx in seg.wrappedValue:
          if not order or order[-1] != idx:
            order.append(idx)
      pts = [(float(coords[i - 1][0]), float(coords[i - 1][1])) for i in order]
    else:
      pts = [(float(c[0]), float(c[1])) for c in coords]
  else:
    return None
  if len(pts) > 1 and pts[0] == pts[-1]:
    pts = pts[:-1]
  return pts if len(pts) >= 3 else None
 
def _profile_points(profile):
  """Returns (points_in_file_units, meta_in_file_units, area_file_units2) or None."""
  kind = profile.is_a()
  if kind == "IfcRectangleProfileDef":
    dx, dy = float(profile.XDim), float(profile.YDim)
    pts = [(-dx / 2, -dy / 2), (dx / 2, -dy / 2), (dx / 2, dy / 2), (-dx / 2, dy / 2)]
    pts = _apply2d(pts, *_axis2d(profile.Position))
    return pts, {"kind": "RECT", "x_dim": dx, "y_dim": dy}, dx * dy
  if kind == "IfcCircleProfileDef":
    r = float(profile.Radius)
    pts = [(r * math.cos(a * math.pi / 8), r * math.sin(a * math.pi / 8)) for a in range(16)]
    pts = _apply2d(pts, *_axis2d(profile.Position))
    return pts, {"kind": "CIRCLE", "radius": r}, math.pi * r * r
  if kind == "IfcArbitraryClosedProfileDef":
    pts = _curve_points(profile.OuterCurve)
    if pts is None:
      return None
    return pts, {"kind": "POLYGON", "points": [[round(x, 6), round(y, 6)] for x, y in pts[:500]]}, _shoelace(pts)
  return None
 
def _body_items(element):
  representation = getattr(element, "Representation", None)
  if representation is None:
    return None
  for rep in representation.Representations or []:
    if rep.RepresentationIdentifier == "Body":
      return list(rep.Items or [])
  return None
 
def _unwrap_boolean(item):
  clipped = False
  while item is not None and item.is_a("IfcBooleanResult"):
    item = item.FirstOperand
    clipped = True
  return item, clipped
 
def _unwrap_mapped(item):
  matrix = np.eye(4)
  clipped = False
  for _ in range(6):
    if item is None:
      break
    if item.is_a("IfcBooleanResult"):
      item = item.FirstOperand
      clipped = True
      continue
    
    if item.is_a("IfcMappedItem"):
      rep = getattr(item.MappingSource, "MappedRepresentation", None)
      if rep is None or len(rep.Items or []) != 1:
        return None, matrix, clipped
      step = ifcopenshell.util.placement.get_mappeditem_transformation(item)
      scale = np.linalg.norm(step[:3, :3], axis=0)
      
      if not np.allclose(scale, 1.0, atol=1e-6):
        return None, matrix, clipped   
      matrix = matrix @ step
      item = rep.Items[0]
      continue
    break
  return item, matrix, clipped

def _closest_dim(px: float, py: float, target: float) -> tuple[float, float]:
  if abs(px - target) <= abs(py - target):
    return px, py
  return py, px
 
def _dims_from_extrusion(role: str, px: float, py: float, depth: float, vertical: bool, zext: float) -> dict:
  long_, short = max(px, py), min(px, py)
  if role in WALL_ROLES:
    if vertical:
      return {"length": long_, "thickness": short, "height": depth}
    height, length = _closest_dim(px, py, zext)
    return {"length": length, "thickness": depth, "height": height}
  if role in SLAB_ROLES:
    return {"length": long_, "width": short, "thickness": depth}
  if role in LINEAR_ROLES:
    if vertical:
      return {"length": depth, "width": short, "height": long_}
    height, width = _closest_dim(px, py, zext)
    return {"length": depth, "width": width, "height": height}
  if vertical:
    return {"length": long_, "width": short, "height": depth}
  height, width = _closest_dim(px, py, zext)
  return {"length": depth, "width": width, "height": height}

def _convex_hull_2d(points) -> list[tuple[float, float]]:
  pts = sorted({(round(float(x), 3), round(float(y), 3)) for x, y in points})
  if len(pts) <= 2:
    return pts

  def cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

  lower: list[tuple[float, float]] = []
  for p in pts:
    while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
      lower.pop()
    lower.append(p)
  upper: list[tuple[float, float]] = []
  for p in reversed(pts):
    while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
      upper.pop()
    upper.append(p)
  return lower[:-1] + upper[:-1]
 
def _extruded_geometry(element, role: str, scales: _Scales) -> _Geometry | None:
  items = _body_items(element)
  if not items or len(items) != 1:
    return None
  solid, mapping_matrix, clipped = _unwrap_mapped(items[0])
  if solid is None or solid.is_a() != "IfcExtrudedAreaSolid":
    return None
  parsed = _profile_points(solid.SweptArea)
  if parsed is None:
    return None
  points, meta, area_file = parsed
 
  mm = scales.mm_per_unit
  if element.ObjectPlacement is not None:
    placement_matrix = ifcopenshell.util.placement.get_local_placement(element.ObjectPlacement)
  else:
    placement_matrix = np.eye(4)
  solid_matrix = (
    ifcopenshell.util.placement.get_axis2placement(solid.Position) if solid.Position is not None else np.eye(4)
  )
  matrix = placement_matrix @ mapping_matrix @ solid_matrix
 
  ratios = np.array(solid.ExtrudedDirection.DirectionRatios[:3] + (0.0,) * (3 - len(solid.ExtrudedDirection.DirectionRatios)), dtype=float)
  norm = np.linalg.norm(ratios)
  if norm == 0:
    return None
  direction_local = ratios / norm
  depth_file = float(solid.Depth)
 
  base_local = np.array([[x, y, 0.0, 1.0] for x, y in points]).T
  top_local = base_local.copy()
  top_local[:3, :] += (direction_local * depth_file).reshape(3, 1)
  base_world = (matrix @ base_local)[:3, :].T * mm
  top_world = (matrix @ top_local)[:3, :].T * mm
  all_world = np.vstack([base_world, top_world])
 
  direction_world = matrix[:3, :3] @ direction_local
  direction_world = direction_world / (np.linalg.norm(direction_world) or 1.0)
  vertical = abs(float(direction_world[2])) > 0.9
 
  xs = [p[0] for p in points]
  ys = [p[1] for p in points]
  px, py = (max(xs) - min(xs)) * mm, (max(ys) - min(ys)) * mm
  depth_mm = depth_file * mm
  zext = float(base_world[:, 2].max() - base_world[:, 2].min())
 
  geometry = _Geometry()
  linear_horizontal = role in LINEAR_ROLES and not vertical
  geometry.kind = "AXIS_SWEPT" if linear_horizontal else "EXTRUDED_PROFILE"
  geometry.bbox_min = all_world.min(axis=0)
  geometry.bbox_max = all_world.max(axis=0)
  geometry.dims = _dims_from_extrusion(role, px, py, depth_mm, vertical, zext)
  geometry.profile_area_mm2 = area_file * mm * mm
  geometry.depth_mm = depth_mm
  geometry.profile = {
    **{k: (round(v * mm, 3) if isinstance(v, float) else v) for k, v in meta.items() if k != "points"},
    **(
      {"points_mm": [[round(x * mm, 3), round(y * mm, 3)] for x, y in points[:500]]}
      if meta["kind"] == "POLYGON"
      else {}
    ),
  }
  origin = (matrix @ np.array([0.0, 0.0, 0.0, 1.0]))[:3] * mm
  plan_pts = (
    [(float(x), float(y)) for x, y in base_world[:, :2]]
    if vertical
    else _convex_hull_2d(all_world[:, :2])
  )
  geometry.placement = {
    "origin_mm": [round(float(v), 3) for v in origin],
    "extrusion_dir": [round(float(v), 6) for v in direction_world],
    "depth_mm": round(depth_mm, 3),
    "vertical": vertical,
    "plan_mm": [[round(x, 3), round(y, 3)] for x, y in plan_pts[:500]],
    "z_min_mm": round(float(all_world[:, 2].min()), 3),
    "z_max_mm": round(float(all_world[:, 2].max()), 3),
  }
  if clipped:
    geometry.issues.append(_issue("GEOMETRY_CLIPPED", "info", "Solid has a boolean clipping; dimensions are those of the unclipped solid."))
  return geometry
 
class _MeshBudget:
  def __init__(self, limit: int, seconds: float):
    self.limit, self.seconds = limit, seconds
    self.left = limit
    self.deadline = time.monotonic() + seconds
    self.used = self.refused_count = self.refused_time = 0

  def take(self) -> bool:
    if self.left <= 0:
      self.refused_count += 1
      return False
    if time.monotonic() > self.deadline:
      self.refused_time += 1
      return False
    self.left -= 1
    self.used += 1
    return True

_MESH_SETTINGS = None
_VOLUME_SETTINGS: dict = {}
 
def _mesh_settings():
  global _MESH_SETTINGS
  if _MESH_SETTINGS is None:
    import ifcopenshell.geom
 
    settings = ifcopenshell.geom.settings()
    settings.set("use-world-coords", True)
    _MESH_SETTINGS = settings
  return _MESH_SETTINGS
 
def _volume_settings(voids: bool = True):
  """Settings for a volume only: the body in its own coordinates (the volume does not need the world), with its openings cut (the net body) or not (the gross body)."""
  if voids not in _VOLUME_SETTINGS:
    import ifcopenshell.geom

    settings = ifcopenshell.geom.settings()
    settings.set("use-world-coords", False)
    settings.set("disable-opening-subtractions", not voids)
    _VOLUME_SETTINGS[voids] = settings
  return _VOLUME_SETTINGS[voids]

def _welded(verts_mm: np.ndarray, faces: np.ndarray) -> tuple:
  """The mesh with the points that coincide (to 0.01 mm) made one. A body cut by openings comes out of the mesher with a point for each face that meets there, and the closed-surface test below counts edges between points."""
  _, first, inverse = np.unique(np.round(verts_mm, 2), axis=0, return_index=True, return_inverse=True)
  return verts_mm[first], np.asarray(inverse).reshape(-1)[faces]

def _closed_mesh_volume_mm3(verts_mm: np.ndarray, faces: np.ndarray) -> float | None:
  if faces.size == 0:
    return None
  verts_mm, faces = _welded(verts_mm, faces)
  edges = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), axis=1)
  _, counts = np.unique(edges, axis=0, return_counts=True)
  if not np.all(counts % 2 == 0):
    return None
  a, b, c = verts_mm[faces[:, 0]], verts_mm[faces[:, 1]], verts_mm[faces[:, 2]]
  return abs(float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum()) / 6.0)

_UP_COSINE = 0.99
_OUTLINE_MAX_POINTS = 1000

def _shape_mm(element, settings=None):
  try:
    import ifcopenshell.geom
    shape = ifcopenshell.geom.create_shape(settings or _mesh_settings(), element)
    verts = np.asarray(shape.geometry.verts, dtype=float).reshape(-1, 3) * 1000.0
    faces = np.asarray(shape.geometry.faces, dtype=int).reshape(-1, 3)
  except Exception:
    return None
  return (verts, faces) if verts.size else None

def _mesh_volume_mm3(element, voids: bool = True) -> float | None:
  shape = _shape_mm(element, _volume_settings(voids))
  return _closed_mesh_volume_mm3(*shape) if shape else None

def _prism_qto_disagree(geometry: _Geometry, flat_qto: dict, scales: _Scales) -> bool:
  """True when the profile x depth volume and the model's Qto volume differ by more than the reader's tolerance."""
  qto = _qto_quantity("volume", flat_qto, scales)
  if not qto or not geometry.profile_area_mm2 or not geometry.depth_mm:
    return False
  qto_mm3 = float(qto[0]) * _MM3_PER_M3
  prism_mm3 = geometry.profile_area_mm2 * geometry.depth_mm
  return abs(prism_mm3 - qto_mm3) > QTO_MESH_TOLERANCE * qto_mm3

def _measure_swept(element, geometry: _Geometry, flat_qto: dict, scales: _Scales, budget: _MeshBudget) -> None:
  """A body swept from a profile is measured as profile x depth only when nothing cuts it. A boolean body (a wall cut by a roof slope) is measured from its mesh, and so is a body with openings whose
  model quantity is missing or disagrees with the profile; the mesh is the body with its openings cut, which is the volume that is there. What the openings take out is recorded: the host's mesh with
  the openings against without them (`openings_mm3`), and the volume of the openings' own meshes for reference (`openings_cutter_mm3`, larger, because a cutter is bigger than the wall it cuts)."""
  clipped = any(i["code"] == "GEOMETRY_CLIPPED" for i in geometry.issues)
  openings = [r.RelatedOpeningElement for r in (getattr(element, "HasOpenings", None) or []) if getattr(r, "RelatedOpeningElement", None) is not None]
  has_volume = _qto_quantity("volume", flat_qto, scales) is not None
  if not (clipped or _prism_qto_disagree(geometry, flat_qto, scales) or (openings and not has_volume)):
    return
  if geometry.mesh_volume_mm3 is not None or not budget.take():
    return
  net = _mesh_volume_mm3(element)
  if net is None:
    return
  geometry.mesh_volume_mm3 = geometry.net_mm3 = net
  if clipped:
    geometry.body = "BOOLEAN_MESH"
    geometry.issues = [i for i in geometry.issues if i["code"] != "GEOMETRY_CLIPPED"]
    geometry.issues.append(_issue("BOOLEAN_MESH", "info", "The body is a boolean (clipped) solid; its volume is measured from its mesh, not from the unclipped profile."))
  if openings:
    gross = _mesh_volume_mm3(element, voids=False)
    geometry.openings = len(openings)
    if gross is not None:
      geometry.openings_mm3 = max(gross - net, 0.0)
    geometry.openings_cutter_mm3 = sum(v for v in (_mesh_volume_mm3(o, voids=False) for o in openings) if v) or None

def _storey_world_z(model, scales: _Scales) -> dict:
  """{storey GlobalId: the z of its placement in the model's world coordinates, in mm}. The elevation a storey names is relative to its building; the elements' boxes are in the world, which can sit hundreds of
  metres up (a survey height), so a storey is compared with an element at its placement."""
  out: dict = {}
  for storey in model.by_type("IfcBuildingStorey"):
    try:
      if storey.ObjectPlacement is not None:
        out[storey.GlobalId] = float(ifcopenshell.util.placement.get_local_placement(storey.ObjectPlacement)[2, 3]) * scales.mm_per_unit
    except Exception:
      continue
  return out

def _storey_issue(levels: list, storey_z: dict, level_gid: str | None, base_mm: float | None, top_mm: float | None) -> dict | None:
  if level_gid is None or base_mm is None or top_mm is None:
    return None
  height = {l.global_id: (storey_z[l.global_id] if l.global_id in storey_z else (float(l.elevation_mm) if l.elevation_mm is not None else None)) for l in levels}
  ordered = sorted((l for l in levels if height.get(l.global_id) is not None), key=lambda l: height[l.global_id])
  mine = next((i for i, l in enumerate(ordered) if l.global_id == level_gid), None)
  if mine is None:
    return None
  mid = base_mm
  low = height[ordered[mine].global_id] - LEVEL_TOLERANCE_MM
  high = height[ordered[mine + 1].global_id] + LEVEL_TOLERANCE_MM if mine + 1 < len(ordered) else float("inf")
  if low <= mid <= high:
    return None
  inside = next((l.name for l in reversed(ordered) if height[l.global_id] - LEVEL_TOLERANCE_MM <= mid), None)
  base = height[ordered[mine].global_id]
  return _issue("IFC_STOREY_DISAGREES", "warning",
    f"The element is filed on storey '{ordered[mine].name}' but its foot is {mid - base:+.0f} mm from that storey's level, "
    + (f"on '{inside}'." if inside else "below the lowest level."))

def _plan_union(vertices: np.ndarray,faces: np.ndarray, normals: np.ndarray, length: np.ndarray, sign: float):
  """The union, in plan, of the triangles that face up (sign +1) or down (sign -1)."""
  from shapely.geometry import Polygon
  from shapely.ops import unary_union
  keep = (length > 0) & (sign * normals[:, 2] > _UP_COSINE * np.where(length > 0, length, 1.0))
  a, b, c = vertices[faces[keep, 0]], vertices[faces[keep, 1]], vertices[faces[keep, 2]]
  triangles = [Polygon(t[:, :2]) for t in np.stack([a, b, c], axis=1)]
  triangles = [t for t in triangles if t.area > 0]
  return unary_union(triangles) if triangles else None

def _top_face_outline(verts_mm: np.ndarray, faces: np.ndarray, mesh_volume_mm3: float, dz_mm: float) -> dict | None:
  if faces.size == 0 or not mesh_volume_mm3 or dz_mm <= 0:
    return None
  try:
    from shapely.geometry import Polygon
    a, b, c = verts_mm[faces[:, 0]], verts_mm[faces[:, 1]], verts_mm[faces[:, 2]]
    normal = np.cross(b - a, c - a)
    if float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum()) < 0:
      normal = -normal
    length = np.linalg.norm(normal, axis=1)
    top = _plan_union(verts_mm, faces, normal, length, 1.0)
    bottom = _plan_union(verts_mm, faces, normal, length, -1.0)
    if top is None or bottom is None or top.geom_type != "Polygon":
      return None
    if abs(top.area - bottom.area) > PRISM_VOLUME_TOLERANCE * top.area:
      return None

    def rounded(coords):
      out: list = []
      for x, y in coords[:-1]:
        point = [round(float(x), 1), round(float(y), 1)]
        if not out or out[-1] != point:
          out.append(point)
      if len(out) > 1 and out[0] == out[-1]:
        out.pop()
      return out if len(out) >= 3 and Polygon(out).area > 0 else None

    ring = rounded(top.exterior.coords)
    holes = [h for h in (rounded(r.coords) for r in top.interiors) if h]
    if ring is None or len(ring) + sum(len(h) for h in holes) > _OUTLINE_MAX_POINTS:
      return None
    checked = Polygon(ring, holes)
    if not checked.is_valid or mesh_volume_mm3 > (1 + PRISM_VOLUME_TOLERANCE) * checked.area * dz_mm:
      return None
    return {"outline_mm": ring, "outline_holes_mm": holes}
  except Exception:
    return None

def _mesh_bbox_geometry(element, role: str) -> _Geometry | None:
  try:
    import ifcopenshell.geom
    shape = ifcopenshell.geom.create_shape(_mesh_settings(), element)
    verts = np.asarray(shape.geometry.verts, dtype=float).reshape(-1, 3)
    faces = np.asarray(shape.geometry.faces, dtype=int).reshape(-1, 3)
  except Exception:
    return None
  if verts.size == 0:
    return None
  verts_mm = verts * 1000.0 
  geometry = _Geometry(kind="BOX_ONLY")
  geometry.bbox_min = verts_mm.min(axis=0)
  geometry.bbox_max = verts_mm.max(axis=0)
  dx, dy, dz = (geometry.bbox_max - geometry.bbox_min).tolist()
  long_, short = max(dx, dy), min(dx, dy)
  geometry.mesh_volume_mm3 = _closed_mesh_volume_mm3(verts_mm, faces)
  if role in WALL_ROLES:
    geometry.net_mm3 = geometry.mesh_volume_mm3
  if role in SLAB_ROLES and geometry.mesh_volume_mm3:
    geometry.placement = _top_face_outline(verts_mm, faces, geometry.mesh_volume_mm3, dz)
  if role in LINEAR_ROLES and role not in WALL_ROLES and len(verts_mm) >= 4:
    centred = verts_mm - verts_mm.mean(axis=0)
    try:
      main_axis = np.linalg.svd(centred, full_matrices=False)[2][0]
      along = centred @ main_axis
      long_ = float(along.max() - along.min())
    except Exception:
      pass
  if role in WALL_ROLES:
    geometry.dims = {"length": long_, "thickness": short, "height": dz}
  elif role in SLAB_ROLES:
    geometry.dims = {"length": long_, "width": short, "thickness": dz}
  else:
    geometry.dims = {"length": long_, "width": short, "height": dz}
  geometry.issues.append(_issue("BOX_ONLY_GEOMETRY", "info", "Dimensions come from the axis-aligned bounding box of the mesh; treat as approximate."))
  return geometry
 
def _flatten_qtos(qtos: dict) -> dict:
  flat: dict = {}
  for values in qtos.values():
    for key, value in values.items():
      if key != "id" and value is not None:
        flat.setdefault(key, value)
  return flat
 
def _qto_source_name(kind: str, qtos: dict) -> str | None:
  for prop in QUANTITY_PROPS_BY_KIND[kind]:
    for set_name, props in qtos.items():
      if isinstance(props, dict):
        value = _num(props.get(prop))
        if value is not None and value > 0:
          return f"{set_name}.{prop}"
  return None

def _qto_quantity(kind: str, flat: dict, scales: _Scales) -> tuple[Decimal, str] | None:
  scale, unit = {
    "volume": (scales.volume_m3, "m3"),
    "area": (scales.area_m2, "m2"),
    "length": (scales.length_m, "m"),
  }[kind]
  for prop in QUANTITY_PROPS_BY_KIND[kind]:
    value = _num(flat.get(prop))
    if value is not None and value > 0:
      return Decimal(repr(value * scale)), unit
  return None
 
def _dims_from_qto(role: str, element, flat: dict, scales: _Scales) -> dict:
  mm = scales.mm_per_unit
  dims: dict = {}
 
  def _length(name: str) -> float | None:
    value = _num(flat.get(name))
    return value * mm if value is not None and value > 0 else None
 
  if role in WALL_ROLES:
    dims = {"length": _length("Length"), "height": _length("Height"), "thickness": _length("Width")}
  elif role in SLAB_ROLES:
    thickness = _length("Depth")
    if thickness is None:
      volume = _num(flat.get("NetVolume")) or _num(flat.get("GrossVolume"))
      area = _num(flat.get("GrossArea")) or _num(flat.get("NetArea")) or _num(flat.get("GrossFootprintArea"))
      if volume and area:
        thickness = (volume * scales.volume_m3) / (area * scales.area_m2) * 1000.0
    dims = {"length": _length("Length"), "width": _length("Width"), "thickness": thickness}
  elif role == "COLUMN":
    dims = {"height": _length("Length")}
  elif role in LINEAR_ROLES:
    dims = {"length": _length("Length")}
  elif role in ("DOOR", "WINDOW"):
    width = _num(getattr(element, "OverallWidth", None))
    height = _num(getattr(element, "OverallHeight", None))
    dims = {"width": width * mm if width else None, "height": height * mm if height else None}
  return {k: v for k, v in dims.items() if v is not None}

def _short(value, limit: int = 200) -> str | None:
  text = _clean(value)
  return text[:limit] if text else None

def _read_header(model) -> dict:
  """Who wrote the file: the header's originating system and the IfcApplication record. Read, never guessed from the file's style."""
  out: dict = {}
  try:
    header = model.header
    name = header.file_name
    out["originating_system"] = _short(name.originating_system)
    out["preprocessor_version"] = _short(name.preprocessor_version)
    out["organization"] = _short(", ".join(str(o) for o in (name.organization or ()) if str(o).strip()))
    out["author"] = _short(", ".join(str(o) for o in (name.author or ()) if str(o).strip()))
    out["file_time_stamp"] = _short(name.time_stamp)
  except Exception:
    pass
  try:
    app = next(iter(model.by_type("IfcApplication")), None)
  except Exception:
    app = None
  if app is not None:
    developer = getattr(app, "ApplicationDeveloper", None)
    out["application"] = _short(getattr(app, "ApplicationFullName", None))
    out["application_version"] = _short(getattr(app, "Version", None))
    out["application_identifier"] = _short(getattr(app, "ApplicationIdentifier", None))
    out["developer"] = _short(getattr(developer, "Name", None) if developer is not None else None)
  tool = out.get("application") or out.get("originating_system")
  version = out.get("application_version")
  if tool and version and version not in tool:
    tool = f"{tool} {version}"
  out["authoring_tool"] = tool
  return {k: v for k, v in out.items() if v}

_REBAR_DIAMETER_KEYS = ("NominalDiameter", "BarDiameter", "Bar Diameter", "Diameter")
_REBAR_LENGTH_KEYS = ("BarLength", "Bar Length", "TotalBarLength", "CutLength", "Cut Length")
_REBAR_WEIGHT_KEYS = ("Weight", "NetWeight", "GrossWeight", "TotalWeight")

def _pset_number(psets: dict, keys: tuple, positive: bool = True) -> tuple[float, str] | None:
  for set_name, props in psets.items():
    if not isinstance(props, dict):
      continue
    for key in keys:
      value = _num(props.get(key))
      if value is not None and (value > 0 or not positive):
        return value, f"{set_name}.{key}"
  return None

def _line_points(points, mm: float) -> float:
  total = 0.0
  for a, b in zip(points, points[1:]):
    total += math.dist(a, b)
  return total * mm

def _arc_length(a, b, c) -> float:
  """Length of the arc that runs from a through b to c, in the units of the points."""
  ab, cb, ac = math.dist(a, b), math.dist(c, b), math.dist(a, c)
  if ab == 0 or cb == 0 or ac == 0:
    return ab + cb
  dot = sum((a[i] - b[i]) * (c[i] - b[i]) for i in range(3))
  cos_b = max(-1.0, min(1.0, dot / (ab * cb)))
  angle_b = math.acos(cos_b)
  sin_b = math.sin(angle_b)
  if sin_b < 1e-9:
    return ab + cb
  radius = ac / (2.0 * sin_b)
  return radius * (2.0 * math.pi - 2.0 * angle_b)

def _pad3(p):
  p = tuple(float(v) for v in p)
  return p + (0.0,) * (3 - len(p))

def _trim_value(trim) -> tuple[str, object] | None:
  for item in (trim or ()):
    if hasattr(item, "is_a") and item.is_a("IfcCartesianPoint"):
      return "point", _pad3(item.Coordinates)
    value = getattr(item, "wrappedValue", item)
    number = _num(value)
    if number is not None:
      return "param", number
  return None

def _circle_param_span(first: float, second: float, agrees: bool, angle_scale: float) -> float:
  """How far a trimmed circle runs, in the file's angle units, counted in the direction the curve is traced."""
  full = (2.0 * math.pi / angle_scale) if angle_scale else 360.0
  raw = (second - first) if agrees else (first - second)
  raw = raw % full
  return full if raw == 0 and first != second else raw

def _curve_length_mm(curve, mm: float, angle_scale: float, depth: int = 0) -> float | None:
  """Length of a bar's centre line when it is a polyline, an indexed poly curve of lines and three-point arcs, or a composite of those and trimmed lines and circles. Anything else gives None, never a guess."""
  if curve is None or depth > 4:
    return None
  if curve.is_a("IfcPolyline"):
    return _line_points([_pad3(p.Coordinates) for p in curve.Points], mm)
  if curve.is_a("IfcIndexedPolyCurve"):
    coords = [_pad3(p) for p in curve.Points.CoordList]
    if not curve.Segments:
      return _line_points(coords, mm)
    total = 0.0

    for seg in curve.Segments:
      idx = [int(i) - 1 for i in getattr(seg, "wrappedValue", seg)]
      if seg.is_a("IfcLineIndex"):
        total += _line_points([coords[i] for i in idx], mm)
      elif seg.is_a("IfcArcIndex") and len(idx) == 3:
        total += _arc_length(coords[idx[0]], coords[idx[1]], coords[idx[2]]) * mm
      else:
        return None
    return total

  if curve.is_a("IfcCompositeCurve"):
    total = 0.0
    for seg in curve.Segments:
      part = _curve_length_mm(seg.ParentCurve, mm, angle_scale, depth + 1)
      if part is None:
        return None
      total += part
    return total

  if curve.is_a("IfcTrimmedCurve"):
    basis = curve.BasisCurve
    t1, t2 = _trim_value(curve.Trim1), _trim_value(curve.Trim2)
    if t1 is None or t2 is None or t1[0] != t2[0]:
      return None
    if basis.is_a("IfcLine"):
      if t1[0] == "point":
        return math.dist(t1[1], t2[1]) * mm
      magnitude = _num(getattr(basis.Dir, "Magnitude", None))
      return abs(t2[1] - t1[1]) * magnitude * mm if magnitude else None
    if basis.is_a("IfcCircle") and t1[0] == "param":
      span = _circle_param_span(t1[1], t2[1], bool(curve.SenseAgreement), angle_scale) * angle_scale
      return float(basis.Radius) * span * mm
  return None

def _curve_param_span(curve, angle_scale: float, depth: int = 0) -> float | None:
  if curve is None or depth > 4:
    return None 
  if curve.is_a("IfcPolyline"):
    return float(len(curve.Points) - 1)
  if curve.is_a("IfcIndexedPolyCurve"):
    return float(len(curve.Segments)) if curve.Segments else float(len(curve.Points.CoordList) - 1)
  if curve.is_a("IfcCompositeCurve"):
    total = 0.0
    for seg in curve.Segments:
      part = _curve_param_span(seg.ParentCurve, angle_scale, depth + 1)
      if part is None:
        return None
      total += part
    return total

  if curve.is_a("IfcTrimmedCurve"):
    t1, t2 = _trim_value(curve.Trim1), _trim_value(curve.Trim2)
    if t1 is None or t2 is None or t1[0] != "param" or t2[0] != "param":
      return None

    if curve.BasisCurve.is_a("IfcCircle"):
      return _circle_param_span(t1[1], t2[1], bool(curve.SenseAgreement), angle_scale)
    if curve.BasisCurve.is_a("IfcLine"):
      return abs(t2[1] - t1[1])
  return None

def _disk_length_mm(disk, mm: float, angle_scale: float) -> float | None:
  """Centre-line length of one swept disk. A disk trimmed to part of its curve is not measured: the trim is not read as a length."""
  length = _curve_length_mm(disk.Directrix, mm, angle_scale)
  if length is None:
    return None
  start, end = getattr(disk, "StartParam", None), getattr(disk, "EndParam", None)
  if start is None and end is None:
    return length

  span = _curve_param_span(disk.Directrix, angle_scale)
  if span is None or start is None or end is None:
    return None
  tol = 1e-6 * max(1.0, span)
  if abs(float(start)) <= tol and abs(float(end) - span) <= tol:
    return length
  return None

def _bar_curve_points(curve, angle_scale: float, depth: int = 0) -> list | None:
  if curve is None or depth > 4:
    return None
  if curve.is_a("IfcPolyline"):
    return [_pad3(p.Coordinates) for p in curve.Points]
  if curve.is_a("IfcIndexedPolyCurve"):
    return [_pad3(p) for p in curve.Points.CoordList]
  if curve.is_a("IfcCompositeCurve"):
    out: list = []
    for seg in curve.Segments:
      part = _bar_curve_points(seg.ParentCurve, angle_scale, depth + 1)
      if part is None:
        return None
      out += part
    return out

  if curve.is_a("IfcTrimmedCurve"):
    basis = curve.BasisCurve
    t1, t2 = _trim_value(curve.Trim1), _trim_value(curve.Trim2)
    if t1 is None or t2 is None or t1[0] != t2[0]:
      return None
    if t1[0] == "point":
      return [t1[1], t2[1]]
    if basis.is_a("IfcLine"):
      origin = np.array(_pad3(basis.Pnt.Coordinates))
      direction = np.array(_pad3(basis.Dir.Orientation.DirectionRatios))
      norm = float(np.linalg.norm(direction))
      magnitude = _num(getattr(basis.Dir, "Magnitude", None))
      if norm == 0 or not magnitude:
        return None

      return [tuple(origin + direction / norm * magnitude * t) for t in (t1[1], t2[1])]
    if basis.is_a("IfcCircle"):
      matrix = ifcopenshell.util.placement.get_axis2placement(basis.Position)
      radius = float(basis.Radius)
      agrees = bool(curve.SenseAgreement)
      span = _circle_param_span(t1[1], t2[1], agrees, angle_scale)
      sign = 1.0 if agrees else -1.0
      out = []

      for k in range(9):
        angle = (t1[1] + sign * span * k / 8.0) * angle_scale
        out.append(tuple(float(v) for v in (matrix @ np.array([radius * math.cos(angle), radius * math.sin(angle), 0.0, 1.0]))[:3]))
      return out
  return None

def _bar_bbox(element, items, mm: float, angle_scale: float) -> dict | None:
  """The box, in world millimetres, that holds the centre lines of every bar the element draws. It is only used to say which member the bars sit in."""
  try:
    base = ifcopenshell.util.placement.get_local_placement(element.ObjectPlacement) if getattr(element, "ObjectPlacement", None) is not None else np.eye(4)
  except Exception:
    return None
  points: list = []

  for item in items:
    inner, matrix, _ = _unwrap_mapped(item)
    if inner is None or not inner.is_a("IfcSweptDiskSolid"):
      continue
    local = _bar_curve_points(inner.Directrix, angle_scale)
    if not local:
      return None
    for p in local:
      points.append((base @ matrix @ np.array([p[0], p[1], p[2], 1.0]))[:3] * mm)
  if not points:
    return None
  stack = np.array(points)
  return {"min": [round(float(v), 1) for v in stack.min(axis=0)], "max": [round(float(v), 1) for v in stack.max(axis=0)]}

def _bar_geometry(element, mm: float, angle_scale: float) -> dict:
  """The bars a bar element draws. Revit puts a whole set of identical bars in one element, one swept disk each, so the bars are counted by disk and grouped by diameter: {"groups": [{dia_mm, bars, length_mm}], "disks": n}. Groups are given only when every disk could be measured."""
  items = _body_items(element)
  if not items:
    return {}
  disks = []
  for item in items:
    inner, _, _ = _unwrap_mapped(item)
    if inner is not None and inner.is_a("IfcSweptDiskSolid"):
      disks.append(inner)
  if not disks:
    return {}
  out: dict = {"disks": len(disks)}
  box = _bar_bbox(element, items, mm, angle_scale)
  if box is not None:
    out["bbox_mm"] = box
  by: dict = {}

  for disk in disks:
    part = _disk_length_mm(disk, mm, angle_scale)
    if part is None:
      return out
    slot = by.setdefault(round(2.0 * float(disk.Radius) * mm, 6), [0, 0.0])
    slot[0] += 1
    slot[1] += part
  out["groups"] = [{"dia_mm": dia, "bars": v[0], "length_mm": v[1]} for dia, v in sorted(by.items())]
  return out

def _host_of(element):
  """The member a bar belongs to: its parent through an aggregation, else the product it is assigned to. A parent that is itself reinforcement is passed over."""
  node = element
  for _ in range(4):
    parent = None
    for rel in (getattr(node, "Decomposes", None) or ()):
      parent = getattr(rel, "RelatingObject", None)
      if parent is not None:
        break
    if parent is None:
      for rel in (getattr(node, "HasAssignments", None) or ()):
        if rel.is_a("IfcRelAssignsToProduct"):
          parent = getattr(rel, "RelatingProduct", None)
          if parent is not None:
            break
    if parent is None:
      return None if node is element else node
    if parent.is_a("IfcReinforcingElement") or parent.is_a("IfcElementAssembly"):
      node = parent
      continue
    return parent
  return None

def _group_name(element) -> str | None:
  """The group the bar is placed in, when the file puts bars in a named group (Revit does this for area reinforcement)."""
  for rel in (getattr(element, "HasAssignments", None) or ()):
    if rel.is_a("IfcRelAssignsToGroup"):
      name = _clean(getattr(getattr(rel, "RelatingGroup", None), "Name", None))
      if name:
        return name[:120]
  return None

_REBAR_COUNT_KEYS = ("Count", "NumberOfBars", "BarCount", "Quantity")

def _rebar_fields(element, psets: dict, qtos: dict, scales: _Scales) -> dict | None:
  """What the file says about one bar element: the drawn bars grouped by diameter, what it declares (diameter, length per bar, count), its own weight, steel grade, and the member or group it belongs to. Weight is worked out in the engine; the file's own weight is kept only to check it against."""
  if not element.is_a("IfcReinforcingBar"):
    return None
  mm = scales.mm_per_unit
  try:
    angle_scale = float(ifcopenshell.util.unit.calculate_unit_scale(element.file, "PLANEANGLEUNIT"))
  except Exception:
    angle_scale = 1.0
  geometry: dict = {}
  try:
    geometry = _bar_geometry(element, mm, angle_scale)
  except Exception:
    geometry = {}

  out: dict = {}
  if geometry.get("groups"):
    out["groups"] = [{"dia_mm": g["dia_mm"], "bars": g["bars"], "length_mm": g["length_mm"]} for g in geometry["groups"]]
  if geometry.get("disks"):
    out["disks"] = geometry["disks"]
  if geometry.get("bbox_mm"):
    out["bbox_mm"] = geometry["bbox_mm"]

  diameter = _num(getattr(element, "NominalDiameter", None))
  found = _pset_number(psets, _REBAR_DIAMETER_KEYS)
  area = _num(getattr(element, "CrossSectionArea", None))

  if diameter is not None and diameter > 0:
    out["dia_mm"], out["dia_source"] = diameter * mm, "NominalDiameter"
  elif found is not None:
    out["dia_mm"], out["dia_source"] = found[0] * mm, found[1]
  elif area is not None and area > 0:
    out["dia_mm"], out["dia_source"] = math.sqrt(4.0 * area * scales.area_m2 * 1e6 / math.pi), "CrossSectionArea"
  if area is not None and area > 0:
    out["area_mm2"] = area * scales.area_m2 * 1e6

  length = _num(getattr(element, "BarLength", None))
  found = _pset_number(psets, _REBAR_LENGTH_KEYS)
  qto_length = _pset_number(qtos, _REBAR_LENGTH_KEYS + ("Length",))
  if length is not None and length > 0:
    out["length_mm"], out["length_source"] = length * mm, "BarLength"
  elif found is not None:
    out["length_mm"], out["length_source"] = found[0] * mm, found[1]
  elif qto_length is not None:
    out["length_mm"], out["length_source"] = qto_length[0] * mm, qto_length[1]

  count = _pset_number(qtos, _REBAR_COUNT_KEYS)
  if count is not None and abs(count[0] - round(count[0])) < 1e-9 and count[0] >= 1:
    out["count"], out["count_source"] = int(round(count[0])), count[1]

  weight = _pset_number(qtos, _REBAR_WEIGHT_KEYS)
  if weight is not None:
    try:
      mass_scale = float(ifcopenshell.util.unit.calculate_unit_scale(element.file, "MASSUNIT"))
    except Exception:
      mass_scale = 1.0
    out["file_kg"], out["file_kg_source"] = weight[0] * mass_scale, weight[1]

  grade = _clean(getattr(element, "SteelGrade", None))
  if grade:
    out["grade"] = grade[:60]
  surface = _clean(getattr(element, "BarSurface", None))
  if surface:
    out["surface"] = surface[:20]
  try:
    host = _host_of(element)
  except Exception:
    host = None
  if host is not None:
    out["host_global_id"] = _clean(getattr(host, "GlobalId", None))
    out["host_type"] = host.is_a()
    out["host_name"] = _short(getattr(host, "Name", None), 120)
  try:
    group = _group_name(element)
  except Exception:
    group = None
  if group:
    out["group_name"] = group
  return out

def _type_fields(element, psets: dict, role: str) -> dict:
  if role not in ("DOOR", "WINDOW"):
    return {}
  common = "Pset_DoorCommon" if role == "DOOR" else "Pset_WindowCommon"
  mark = _clean((psets.get(common) or {}).get("Reference"))
  type_name = None
  try:
    etype = ifcopenshell.util.element.get_type(element)
  except Exception:
    etype = None
  if etype is not None:
    type_name = _clean(getattr(etype, "Name", None))
    if mark is None:
      try:
        type_psets = ifcopenshell.util.element.get_psets(etype, psets_only=True) or {}
      except Exception:
        type_psets = {}
      mark = _clean((type_psets.get(common) or {}).get("Reference")) or _clean(getattr(etype, "Tag", None))
  return {"type_mark": mark[:100] if mark else None, "type_name": type_name[:200] if type_name else None}
 
def _normalise_element(
  element,
  scales: _Scales,
  levels: list[ReadLevel],
  mesh_budget: _MeshBudget,
  schema_id: str,
  storey_z: dict | None = None,
) -> ReadElement:
  psets = ifcopenshell.util.element.get_psets(element, psets_only=True) or {}
  qtos = ifcopenshell.util.element.get_psets(element, qtos_only=True) or {}
  flat_qto = _flatten_qtos(qtos)
 
  role, class_source, class_conf = _classify(element, psets, schema_id)
  material = _material_text(element)
  layers = _material_layers(element, scales)
  ifc_type = element.is_a()
  issues: list[dict] = []
 
  geometry: _Geometry | None = None
  if role not in COUNT_ROLES and getattr(element, "Representation", None) is not None:
    try:
      geometry = _extruded_geometry(element, role, scales)
    except Exception:
      geometry = None
    if geometry is None and role in MESH_FALLBACK_ROLES and mesh_budget.take():
      geometry = _mesh_bbox_geometry(element, role)
  if geometry is None:
    geometry = _Geometry(kind="UNSUPPORTED")
  if geometry.kind in ("EXTRUDED_PROFILE", "AXIS_SWEPT"):
    _measure_swept(element, geometry, flat_qto, scales, mesh_budget)
 
  dims = {k: v for k, v in geometry.dims.items() if v is not None and v > 0}
  qto_dims = _dims_from_qto(role, element, flat_qto, scales)
  for key, value in qto_dims.items():
    dims.setdefault(key, value)
  if role in ("DOOR", "WINDOW"):
    for key in ("width", "height"):
      if key in qto_dims:
        dims[key] = qto_dims[key]
  if geometry.kind == "UNSUPPORTED" and dims:
    geometry.kind = "QTO_ONLY"
  issues += geometry.issues
 
  order = QUANTITY_KIND_ORDER_BY_ROLE.get(role, DEFAULT_QUANTITY_KIND_ORDER)
  quantity, unit, source = Decimal("0"), None, "NONE"
  quantity_basis = None
  for kind in order:
    if kind == "count":
      quantity, unit, source = Decimal("1"), "nos", "COUNT"
      quantity_basis = "Counted as 1 each"
      break
    found = _qto_quantity(kind, flat_qto, scales)
    
    if found:
      quantity, unit = found
      source = "QTO"
      quantity_basis = _qto_source_name(kind, qtos)
      break
    
  if source == "NONE":
    for kind in order:
      if kind == "volume" and geometry.profile_area_mm2 and geometry.depth_mm:
        cubic_mm = geometry.net_mm3 or geometry.profile_area_mm2 * geometry.depth_mm
        quantity, unit, source = Decimal(repr(cubic_mm / _MM3_PER_M3)), "m3", "GEOMETRY"
        quantity_basis = "Closed 3D mesh volume, openings cut" if geometry.net_mm3 else "Profile area x depth"
        break
      
      if kind == "length" and dims.get("length"):
        quantity, unit, source = Decimal(repr(dims["length"] / 1000.0)), "m", "GEOMETRY"
        quantity_basis = "Member length"
        break
    if source == "GEOMETRY":
      issues.append(_issue("QUANTITY_FROM_GEOMETRY", "info", "No usable Qto quantity; quantity derived from extruded geometry."))
 
  volume_m3 = _qto_quantity("volume", flat_qto, scales)
  area_m2 = _qto_quantity("area", flat_qto, scales)
  volume_mm3 = float(volume_m3[0]) * _MM3_PER_M3 if volume_m3 else (
    geometry.profile_area_mm2 * geometry.depth_mm if geometry.profile_area_mm2 and geometry.depth_mm else None
  )
  geometry_measures = False
  if geometry.net_mm3 and unit == "m3" and source == "GEOMETRY" and geometry.profile_area_mm2 and geometry.depth_mm:
  
    volume_mm3, geometry_measures = geometry.net_mm3, True
    issues.append(_issue("QUANTITY_FROM_MESH", "info", "Geometry is the measure: volume from the 3D mesh of the body, openings cut."))
  elif (source == "QTO" and unit == "m3" and volume_m3 and geometry.net_mm3 and (role in WALL_ROLES or geometry.body)
        and abs(volume_mm3 - geometry.net_mm3) > QTO_MESH_TOLERANCE * geometry.net_mm3):
  
    geometry_measures = True
    quantity, source = Decimal(repr(geometry.net_mm3 / _MM3_PER_M3)), "GEOMETRY"
    quantity_basis = "Closed 3D mesh volume, openings cut"
    issues.append(_issue("QUANTITY_FROM_MESH", "info", f"Geometry is the measure: {geometry.net_mm3 / _MM3_PER_M3:.4f} m3 from the 3D mesh."))
    issues.append(_issue("QTO_DISAGREES_GEOMETRY_USED", "warning", f"The model's own volume, {volume_mm3 / _MM3_PER_M3:.4f} m3, differs from the 3D geometry by more than {QTO_MESH_TOLERANCE:.0%}; the geometry is used."))
  reference_mm3 = geometry.mesh_volume_mm3
  if reference_mm3 is None and geometry.profile_area_mm2 and geometry.depth_mm and not any(i["code"] == "GEOMETRY_CLIPPED" for i in geometry.issues):
    reference_mm3 = geometry.profile_area_mm2 * geometry.depth_mm
    
  if reference_mm3:
    if volume_mm3 is None:
      volume_mm3 = reference_mm3
      if source == "NONE" and any(k == "volume" for k in order):
        quantity, unit, source = Decimal(repr(volume_mm3 / _MM3_PER_M3)), "m3", "GEOMETRY"
        quantity_basis = "Closed 3D mesh volume"
        issues.append(_issue("QUANTITY_FROM_MESH", "info", "No usable Qto volume; volume taken from the closed 3D mesh."))
        
    elif geometry_measures:
      pass
    elif abs(volume_mm3 - reference_mm3) > QTO_MESH_TOLERANCE * reference_mm3:
      issues.append(_issue(
        "QTO_MESH_MISMATCH", "warning",
        f"Model volume {volume_mm3 / _MM3_PER_M3:.4f} m3 differs from the 3D geometry volume "
        f"{reference_mm3 / _MM3_PER_M3:.4f} m3 by more than {QTO_MESH_TOLERANCE:.0%}.",
      ))
      
    else:
      issues.append(_issue("QTO_MESH_VERIFIED", "info", "Model volume agrees with the 3D geometry volume."))
  material_family = _material_family(material, getattr(element, "Name", None), role)
  if material_family == "STEEL" and is_steel_role(role) and role in CONCRETE_ONLY_ROLES:
    issues.append(_issue(
      "STEEL_MEASURED_AS_STEEL", "info",
      f"Material looks like steel on a {role}; it is measured as structural steel by weight, not as concrete.",
    ))
    
  elif (material_family == "CONCRETE_OR_UNKNOWN" and is_steel_role(role) and material and _CONCRETE_TEXT.search(material)
        and _STEEL_NAME.search(f"{getattr(element, 'Name', None) or ''} {getattr(element, 'ObjectType', None) or ''}")):
    issues.append(_issue(
      "STEEL_MATERIAL_CONFLICT", "warning",
      "The material says concrete but the element name says steel. It is measured as concrete; check the model.",
    ))
    
  elif material_family != "CONCRETE_OR_UNKNOWN" and role in CONCRETE_ONLY_ROLES:
    issues.append(_issue(
      "NON_CONCRETE_MATERIAL", "error",
      f"Material looks like {material_family.lower()}, but role {role} is measured as concrete. Excluded from the RCC quantities.",
    ))
    
  area_mm2 = float(area_m2[0]) * _MM2_PER_M2 if area_m2 else geometry.profile_area_mm2
 
  base_mm = float(geometry.bbox_min[2]) if geometry.bbox_min is not None else None
  top_mm = float(geometry.bbox_max[2]) if geometry.bbox_max is not None else None
  level_gid = _storey_of(element)
  if level_gid is None and levels:
    level_gid = _level_by_elevation(levels, base_mm)
    if level_gid:
      issues.append(_issue("LEVEL_INFERRED", "info", "No storey container; level inferred from element elevation."))
  if level_gid is None and levels:
    issues.append(_issue("NO_LEVEL", "info", "Element could not be assigned to a level."))
  elif role not in STOREY_FREE_ROLES:
    storey = _storey_issue(levels, storey_z or {}, level_gid, base_mm, top_mm)
    if storey:
      issues.append(storey)
 
  if source == "NONE" and role in NO_LEGACY_BOQ_ROLES:
    issues.append(_issue("STORED_ONLY", "info", f"Role {role} is stored for later phases; no BOQ quantity is taken from it here."))
  elif source == "NONE":
    issues.append(_issue("NO_QUANTITY", "error", "No usable quantity from Qto sets or geometry."))
  for required in REQUIRED_DIMENSIONS_BY_ROLE.get(role, ()):
    if required not in dims:
      issues.append(_issue("MISSING_DIMENSION", "error", f"Missing required dimension '{required}' for role {role}."))
  if geometry.kind == "UNSUPPORTED" and role in MESH_FALLBACK_ROLES:
    issues.append(_issue("UNSUPPORTED_GEOMETRY", "warning", "No extrudable or meshable body geometry found."))
  if class_source == "IFC_SUPERTYPE":
    issues.append(_issue("ROLE_FALLBACK", "info", f"Only the broad family is known ({role}); no specific class mapping."))
  if role == "UNKNOWN":
    issues.append(_issue("UNCLASSIFIED_ELEMENT", "warning", "Element role could not be determined."))
  elif class_conf < LOW_CLASSIFICATION_CONFIDENCE:
    issues.append(_issue("LOW_CONFIDENCE_CLASSIFICATION", "warning", f"Role {role} inferred from {class_source} with low confidence."))
  is_generic = material is None
  if is_generic and role not in COUNT_ROLES and role not in NO_LEGACY_BOQ_ROLES:
    issues.append(_issue("MISSING_MATERIAL", "warning", "No material assigned; generic type name used."))
 
  severities = {i["severity"] for i in issues}
  status = "INVALID" if "error" in severities else "WARNING" if "warning" in severities else "VALID"
 
  properties = _json_safe({**psets, **qtos})
  properties["is_generic_fallback"] = is_generic
  properties["_ifc"] = {
    "material_family": material_family,
    "quantity_basis": quantity_basis,
    "predefined_type": _clean(getattr(element, "PredefinedType", None)),
    "object_type": _clean(getattr(element, "ObjectType", None)),
  }
  
  if len(layers) > 1:
    properties["_ifc"]["layers"] = layers
  if geometry.kind in ("EXTRUDED_PROFILE", "AXIS_SWEPT") and geometry.mesh_volume_mm3:
    properties["_ifc"]["mesh_volume_mm3"] = round(float(geometry.mesh_volume_mm3), 1)
  if geometry.body:
    properties["_ifc"]["body"] = geometry.body
  if geometry.openings:
    properties["_ifc"]["openings"] = {"count": geometry.openings, "openings_mm3": round(geometry.openings_mm3, 1) if geometry.openings_mm3 is not None else None,
      "cutters_mm3": round(geometry.openings_cutter_mm3, 1) if geometry.openings_cutter_mm3 is not None else None}
  if role == "REBAR":
    try:
      rebar = _rebar_fields(element, psets, qtos, scales)
    except Exception:
      rebar = None
    if rebar is not None:
      properties["_ifc"]["rebar"] = rebar
 
  bbox_min = bbox_max = None
  if geometry.bbox_min is not None and geometry.bbox_max is not None:
    bbox_min = tuple(_dec(float(v)) for v in geometry.bbox_min)
    bbox_max = tuple(_dec(float(v)) for v in geometry.bbox_max)
  if bbox_min is None and role in ("DOOR", "WINDOW") and getattr(element, "ObjectPlacement", None) is not None:
    try:
      origin = ifcopenshell.util.placement.get_local_placement(element.ObjectPlacement)[:3, 3]
      bbox_min = bbox_max = tuple(_dec(float(v) * scales.mm_per_unit) for v in origin)
    except Exception:
      pass
 
  return ReadElement(
    step_id=element.id(),
    global_id=_clean(getattr(element, "GlobalId", None)),
    ifc_type=ifc_type,
    name=_clean(getattr(element, "Name", None)),
    raw_material_text=material or humanize_ifc_type(ifc_type),
    is_generic_fallback=is_generic,
    discipline=DISCIPLINE_BY_ROLE.get(role, DEFAULT_DISCIPLINE),
    structural_role=role,
    classification_source=class_source,
    classification_confidence=Decimal(str(class_conf)),
    level_global_id=level_gid,
    unit=unit,
    quantity=quantity,
    quantity_source=source,
    length_mm=_dec(dims.get("length")),
    width_mm=_dec(dims.get("width")),
    height_mm=_dec(dims.get("height")),
    thickness_mm=_dec(dims.get("thickness")),
    area_mm2=_dec(area_mm2),
    volume_mm3=_dec(volume_mm3),
    elevation_base_mm=_dec(base_mm),
    elevation_top_mm=_dec(top_mm),
    bbox_min_mm=bbox_min,
    bbox_max_mm=bbox_max,
    geometry_kind=geometry.kind,
    profile=geometry.profile,
    placement=geometry.placement,
    properties=properties,
    status=status,
    issues=issues,
    **_type_fields(element, psets, role),
  )
 
def _inferred_level_of(levels: list[ReadLevel], e: ReadElement) -> str | None:
  """A beam hangs below the floor it carries, so it belongs to the level at or above its top; everything else belongs to the level at its base."""
  if (e.structural_role or "").startswith(("BEAM", "EDGE_BEAM", "GIRDER")) and e.elevation_top_mm is not None:
    top = float(e.elevation_top_mm)
    for level in levels:
      if level.elevation_mm is not None and float(level.elevation_mm) >= top - LEVEL_TOLERANCE_MM:
        return level.global_id
    return levels[-1].global_id
  return _level_by_elevation(levels, float(e.elevation_base_mm) if e.elevation_base_mm is not None else None)

def _infer_levels(elements: list[ReadElement]) -> tuple[list[ReadLevel], dict]:
  """One level for each floor slab top, found the way the engine finds its stage datums (same cluster width, storey height and slab size rule)."""
  from app.engine.measure.stages import DEFAULTS as STAGE
  tol, storey, share = STAGE["slab_cluster_mm"], STAGE["min_storey_mm"], STAGE["floor_slab_min_area_frac"]
  slabs = []
  for e in elements:
    role = e.structural_role or ""
    if not role.startswith("SLAB") or role in NOT_FLOOR_SLAB_ROLES or e.elevation_top_mm is None:
      continue
    slabs.append((float(e.elevation_top_mm), float(e.area_mm2 or 0.0)))
  slabs.sort()
  clusters: list[dict] = []
  for top, area in slabs:
    if clusters and top - clusters[-1]["first"] <= tol:
      clusters[-1]["top"] = max(clusters[-1]["top"], top)
      clusters[-1]["area"] += area
    else:
      clusters.append({"first": top, "top": top, "area": area})
  largest = max((a for _, a in slabs), default=0.0)
  tops: list[float] = []
  for c in clusters:
    if largest > 0 and c["area"] < share * largest:
      continue
    if tops and c["top"] - tops[-1] < storey:
      continue
    tops.append(c["top"])
  info = {"slab_levels": len(tops), "tops_mm": [round(t, 1) for t in tops]}
  if len(tops) < 2:
    return [], info
  return [ReadLevel(global_id=f"INFERRED-LEVEL-{i + 1}", name=f"Level {i + 1} (inferred)", elevation_mm=_dec(t), sequence=i)
    for i, t in enumerate(tops)], info

def read_ifc(path: str, *, mesh_fallback_limit: int = DEFAULT_MESH_FALLBACK_LIMIT, mesh_budget_s: float = IFC_MESH_BUDGET_S) -> IfcReadResult:
  model = ifcopenshell.open(path)
  scales = _resolve_scales(model)
  levels = _read_levels(model, scales)
 
  model_issues: list[dict] = []
  if scales.ambiguous:
    model_issues.append(_issue("UNIT_SCALE_AMBIGUOUS", "error", "IFC file has no length unit; metres assumed. Verify dimensions."))
  if not levels:
    model_issues.append(_issue("NO_STOREYS", "warning", "Model has no IfcBuildingStorey; elements have no level."))
 
  schema_id = model.schema_identifier
  raw_elements = []
  excluded_counts: dict[str, int] = {}
  for element in model.by_type("IfcElement"):
    chain = _type_chain(schema_id, element.is_a())
    hit = next((name for name in chain if name in EXCLUDED_IFC_TYPES), None)
    if hit:
      excluded_counts[hit] = excluded_counts.get(hit, 0) + 1
      continue
    raw_elements.append(element)
  raw_elements.sort(key=lambda e: e.id())
 
  mesh_budget = _MeshBudget(mesh_fallback_limit, mesh_budget_s)
  storey_z = _storey_world_z(model, scales)
  elements: list[ReadElement] = []
  for element in raw_elements:
    try:
      elements.append(_normalise_element(element, scales, levels, mesh_budget, schema_id, storey_z))
    except Exception as exc:
      elements.append(
        ReadElement(
          step_id=element.id(),
          global_id=_clean(getattr(element, "GlobalId", None)),
          ifc_type=element.is_a(),
          name=_clean(getattr(element, "Name", None)),
          raw_material_text=humanize_ifc_type(element.is_a()),
          is_generic_fallback=True,
          discipline=DEFAULT_DISCIPLINE,
          structural_role="UNKNOWN",
          classification_source="NONE",
          classification_confidence=Decimal("0"),
          status="INVALID",
          issues=[_issue("READ_ERROR", "error", f"Element could not be read: {str(exc)[:200]}")],
        )
      )
 
  if not elements:
    model_issues.append(_issue("NO_ELEMENTS", "error", "No supported building elements were found in the model."))
  if mesh_budget.refused_count:
    model_issues.append(_issue("MESH_FALLBACK_LIMIT_REACHED", "info", f"Mesh fallback limit ({mesh_fallback_limit} elements) reached; {mesh_budget.refused_count} later elements were not meshed and may lack geometry."))
  if mesh_budget.refused_time:
    model_issues.append(_issue("MESH_BUDGET_REACHED", "warning", f"The mesh time budget ({mesh_budget_s:g} s) ran out; {mesh_budget.refused_time} elements were not meshed and may lack geometry or a cross-check."))
 
  if not levels and elements:
    levels, level_info = _infer_levels(elements)
    if levels:
      placed = 0
      for e in elements:
        if e.level_global_id is None:
          gid = _inferred_level_of(levels, e)
          if gid:
            e.level_global_id = gid
            e.issues.append(_issue("LEVEL_INFERRED", "info", "No storey in the model; level inferred from the floor slabs."))
            placed += 1
      model_issues.append(_issue("LEVELS_INFERRED", "info",
        f"The model has no storeys. {len(levels)} levels were inferred from the floor slabs (tops at {', '.join(str(int(t)) for t in level_info['tops_mm'])} mm) and {placed} elements were placed on them. Elements below the lowest level have none."))
    else:
      model_issues.append(_issue("LEVELS_NOT_INFERRED", "info",
        f"The model has no storeys and only {level_info['slab_levels']} floor slab level was found, so no levels were inferred; at least two are needed."))

  spatial = None
  try:
    from app.modules.drawings_boq.ifc_spatial import read_spatial
    spatial = read_spatial(model, scales, levels, {e.global_id for e in elements if e.global_id})
  except Exception as exc:
    model_issues.append(_issue("SPATIAL_READ_FAILED", "warning", f"Spaces and relations could not be read: {str(exc)[:200]}"))

  stats = {
    "space_count": len(spatial.spaces) if spatial else 0,
    "element_count": len(elements),
    "by_status": {s: sum(1 for e in elements if e.status == s) for s in ("VALID", "WARNING", "INVALID")},
    "by_geometry_kind": {},
    "by_role": {},
    "by_discipline": {},
    "excluded": excluded_counts,
    "mesh": {"budget_s": mesh_budget_s, "limit": mesh_fallback_limit, "elements_meshed": mesh_budget.used, "refused_by_count": mesh_budget.refused_count, "refused_by_time": mesh_budget.refused_time,
      "boolean_bodies": 0, "voided_elements": 0, "openings": 0, "openings_mm3": 0.0, "storey_disagrees": 0},
  }
  for e in elements:
    ifc = (e.properties or {}).get("_ifc") or {}
    stats["mesh"]["boolean_bodies"] += 1 if ifc.get("body") else 0
    if ifc.get("openings"):
      stats["mesh"]["voided_elements"] += 1
      stats["mesh"]["openings"] += int(ifc["openings"]["count"])
      stats["mesh"]["openings_mm3"] += float(ifc["openings"]["openings_mm3"] or 0.0)
    stats["mesh"]["storey_disagrees"] += 1 if any(i["code"] == "IFC_STOREY_DISAGREES" for i in e.issues) else 0
    stats["by_geometry_kind"][e.geometry_kind] = stats["by_geometry_kind"].get(e.geometry_kind, 0) + 1
    stats["by_role"][e.structural_role] = stats["by_role"].get(e.structural_role, 0) + 1
    stats["by_discipline"][e.discipline] = stats["by_discipline"].get(e.discipline, 0) + 1
 
  return IfcReadResult(
    schema=str(model.schema),
    header=_read_header(model),
    length_unit_scale=scales.length_m,
    levels=levels,
    elements=elements,
    model_issues=model_issues,
    stats=stats,
    spaces=spatial.spaces if spatial else [],
    boundaries=spatial.boundaries if spatial else [],
    relations=spatial.relations if spatial else [],
  )