from __future__ import annotations
import hashlib
import re
import secrets
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import TraceException
from app.modules.identity.token_store import IdentityTokenStore
from app.core.security import create_access_token, create_refresh_token, decode_token, hash_password, verify_password
from app.modules.identity.enums import TokenType
from app.modules.identity.models import RefreshToken, User, Organization, OrganizationMembership, OrganizationInvitation
from app.modules.identity.password_policy import validate_password
from app.modules.identity.repository import IdentityRepository
from app.modules.identity.schemas import LoginResponse, RegistrationResponse, TokenResponse, UserResponse, RoleResponse, OrganizationResponse, InvitationPreviewResponse
from app.core.config import settings
from app.modules.identity.email import EmailService
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.modules.subscriptions.service import SubscriptionService
from app.dependencies.tenancy import scope_session_to_org
from urllib.parse import quote

MAX_FAILED_LOGIN_ATTEMPTS = 5
LOCKOUT_MINUTES = 15

EMAIL_VERIFICATION_TTL_SECONDS = 60 * 60 * 24
PASSWORD_RESET_TTL_SECONDS = 60 * 15

class IdentityService:
  def __init__(
    self,
    session: AsyncSession,
    token_store: IdentityTokenStore,
    email_service: EmailService | None = None,
  ):
    self.session = session

    self.repository = IdentityRepository(
      session
    )

    self.token_store = token_store
    self.email_service = email_service or EmailService()

  @staticmethod
  def hash_refresh_token(
    token: str,
  ) -> str:
    return hashlib.sha256(
      token.encode("utf-8")
    ).hexdigest()

  @staticmethod
  def generate_one_time_token() -> str:
    return secrets.token_urlsafe(48)

  @staticmethod
  def normalize_email(
    email: str,
  ) -> str:
    return email.strip().lower()

  @staticmethod
  def generate_organization_slug(name: str) -> str:
    slug = name.strip().lower()
    slug = re.sub(
        r"[^a-z0-9]+",
        "-",
        slug,
    )
    slug = slug.strip("-")

    return slug
  
  @staticmethod
  def hash_invitation_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()

  async def authenticate(
    self,
    email: str,
    password: str,
  ) -> User:
    email = self.normalize_email(email)

    user = await self.repository.get_user_by_email(
      email
    )

    if user is None:
      raise TraceException(
        "Invalid email or password.",
        status_code=401,
        code="INVALID_CREDENTIALS",
      )

    now = datetime.now(timezone.utc)

    if (
      user.locked_until is not None
      and user.locked_until > now
    ):
      raise TraceException(
        "Account temporarily locked. Please try again later.",
        status_code=429,
        code="ACCOUNT_TEMPORARILY_LOCKED",
      )

    if not verify_password(
      password,
      user.password_hash,
    ):
      failed_attempts = (
        user.failed_login_attempts + 1
      )

      locked_until = None

      if (
        failed_attempts
        >= MAX_FAILED_LOGIN_ATTEMPTS
      ):
        locked_until = (
          now
          + timedelta(
            minutes=LOCKOUT_MINUTES
          )
        )

      await self.repository.record_failed_login(
        user,
        locked_until=locked_until,
      )

      await self.session.commit()

      raise TraceException(
        "Invalid email or password.",
        status_code=401,
        code="INVALID_CREDENTIALS",
      )

    if not user.is_active:
      raise TraceException(
        "User account is inactive.",
        status_code=403,
        code="USER_INACTIVE",
      )

    if not user.is_verified:
      raise TraceException(
        "Please verify your email address before logging in.",
        status_code=403,
        code="EMAIL_NOT_VERIFIED",
      )

    if not user.organization.is_active:
      raise TraceException(
        "Organization is inactive.",
        status_code=403,
        code="ORGANIZATION_INACTIVE",
      )

    return user

  async def get_organization_by_slug(
    self,
    slug: str,
  ) -> Organization | None:
    result = await self.session.execute(
      select(Organization).where(Organization.slug == slug)
    )
    return result.scalar_one_or_none()
  
  async def register(self, email: str, password: str, first_name: str, last_name: str, organization_name: str | None, password_confirmation: str, invitation_token: str | None = None,
) -> RegistrationResponse:

   email = self.normalize_email(email)

   if password != password_confirmation:
    raise TraceException(
      "Passwords do not match.",
      status_code=422,
      code="PASSWORD_MISMATCH",
    )

   validate_password(password)

   existing_user = await self.repository.get_user_by_email(
    email
   )

   if existing_user is not None:
    raise TraceException(
      "An account with this email already exists.",
      status_code=409,
      code="EMAIL_ALREADY_REGISTERED",
    )
   invitation: OrganizationInvitation | None = None
   organization: Organization | None = None
   
   if invitation_token is not None:
    invitation = await self._resolve_invitation(invitation_token, email)
    organization_id = invitation.organization_id
    role_id = invitation.role_id
   else: 
   
     organization_name = organization_name.strip()

     if not organization_name:
      raise TraceException(
      "Organization name is required.",
      status_code=422,
      code="ORGANIZATION_NAME_REQUIRED",
     )

     organization = await self.repository.get_organization_by_name(
     organization_name
     )

     if organization is not None:
      raise TraceException(
       "An organization with this name already exists.",
       status_code=409,
       code="ORGANIZATION_ALREADY_EXISTS",
      )

     organization_slug = self.generate_organization_slug(
      organization_name
     )

     if await self.repository.get_organization_by_slug(organization_slug) is not None:
      organization_slug = f"{organization_slug}-{secrets.token_hex(3)}"

     organization = await self.repository.create_organization(
      name=organization_name,
      slug=organization_slug,
     )

     role = await self.repository.get_role_by_name(
      organization_id=organization.id,
      name="Company Admin",
     )

     if role is None:
      role = await self.repository.create_role(
       organization_id=organization.id,
       name="Company Admin",
       description=(
         "Full administrative access to the organization."
       ),
       is_system=True,
      )

      await self.session.flush()
      all_permissions = await self.repository.get_all_permissions()
      role.permissions = all_permissions
      await self.session.flush()
      
     organization_id = organization.id
     role_id = role.id

   user = await self.repository.create_user(
    organization_id=organization_id,
    role_id=role_id,
    email=email,
    password_hash=hash_password(password),
    first_name=first_name.strip(),
    last_name=last_name.strip(),
    is_active=True,
    is_verified=False,
  )

   self.session.add(
    OrganizationMembership(
      user_id=user.id,
      organization_id=organization_id,
      role_id=role_id,
      is_active=True,
    )
  )
   
   if invitation is not None:
    invitation.accepted_at = datetime.now(timezone.utc)
    invitation.accepted_by_user_id = user.id
   else:
    await scope_session_to_org(self.session, organization_id)
    subscription_service = SubscriptionService(self.session)
    if organization is None:  
      organization = await self.repository.get_organization_by_id(organization_id)

    await subscription_service.create_initial_subscription(
      organization,
      plan_slug="free",
    )
   
   await self.session.commit()

   user = await self.repository.get_user_by_id(
    user.id
  )

   if user is None:
    raise TraceException(
      "Failed to load newly created user.",
      status_code=500,
      code="REGISTRATION_USER_LOAD_FAILED",
    )

   verification_token = await self.create_email_verification_token(user)
   token_value = quote(verification_token, safe="")

   web_link = (
    f"{settings.frontend_base_url}/verify-email"
    f"?token={token_value}" 
   )
   app_link = f"trace://verify-email?token={token_value}"
   
   await self.email_service.send(
     recipient=user.email,
     subject="Verify your email address",
     body=(
      "Welcome. Please verify your email address:\n\n"
      f"Web: {web_link}\n"
      f"Open in Trace: {app_link}"
     ),
   )

   return RegistrationResponse(
    user=user,
    verification_required=True,
    message=(
      "Registration successful. "
      "Please verify your email."
    ),
  )
   
  async def _resolve_invitation(
    self,
    token: str,
    registering_email: str,
  ) -> OrganizationInvitation:
    token_hash = self.hash_invitation_token(token)

    result = await self.session.execute(
    select(OrganizationInvitation).where(
      OrganizationInvitation.token_hash == token_hash
    )
  )
    invitation = result.scalar_one_or_none()

    if invitation is None:
      raise TraceException(
        "This invitation link is invalid.",
        status_code=404,
        code="INVITATION_NOT_FOUND",
      )

    if invitation.is_accepted:
      raise TraceException(
        "This invitation has already been used.",
        status_code=409,
        code="INVITATION_ALREADY_ACCEPTED",
      )

    if invitation.is_revoked:
      raise TraceException(
        "This invitation has been revoked.",
        status_code=409,
        code="INVITATION_REVOKED",
      )

    if invitation.is_expired:
      raise TraceException(
        "This invitation has expired. Ask an admin to send a new one.",
        status_code=409,
        code="INVITATION_EXPIRED",
      )

    if invitation.email.strip().lower() != registering_email.strip().lower():
      raise TraceException(
        "This invitation was sent to a different email address.",
        status_code=403,
        code="INVITATION_EMAIL_MISMATCH",
      )

    return invitation

  async def preview_invitation(self, token: str) -> InvitationPreviewResponse:
    token_hash = self.hash_invitation_token(token)

    result = await self.session.execute(
     select(OrganizationInvitation)
     .where(OrganizationInvitation.token_hash == token_hash)
     .options(
       selectinload(OrganizationInvitation.organization),
       selectinload(OrganizationInvitation.role),
      )
    )
    invitation = result.scalar_one_or_none()

    if invitation is None or not invitation.is_pending:
     raise TraceException(
       "This invitation link is invalid or no longer active.",
       status_code=404,
       code="INVITATION_NOT_FOUND",
      )

    return InvitationPreviewResponse(
      organization_name=invitation.organization.name,
      email=invitation.email,
      role_name=invitation.role.name,
    )
   
  async def switch_organization(
    self,
    user: User,
    organization_id: UUID,
  ) -> LoginResponse:
    membership = await self.repository.get_membership(
    user_id=user.id,
    organization_id=organization_id,
  )

    if membership is None or not membership.is_active:
      raise TraceException(
      "You do not have an active membership in this organization.",
      status_code=403,
      code="NO_ACTIVE_MEMBERSHIP",
    )

    if not membership.organization.is_active:
      raise TraceException(
      "Organization is inactive.",
      status_code=403,
      code="ORGANIZATION_INACTIVE",
    )

    tokens = await self.issue_tokens(user, membership)
    await self.session.commit()

    return LoginResponse(
      user=await self.build_user_response(user, membership),
      tokens=tokens,
    )

  async def create_email_verification_token(
    self,
    user: User,
  ) -> str:
    return await self.token_store.create(
      prefix="email-verification",
      user_id=str(user.id),
      ttl_seconds=EMAIL_VERIFICATION_TTL_SECONDS,
    )

  async def verify_email(
    self,
    token: str,
  ) -> None:
    user_id = await self.token_store.consume(
      prefix="email-verification",
      token=token,
    )

    if not user_id:
      raise TraceException(
        "Invalid or expired verification token.",
        status_code=400,
        code="INVALID_VERIFICATION_TOKEN",
      )

    try:
      parsed_user_id = UUID(user_id)
    except ValueError as exc:
      raise TraceException(
        "Invalid verification token.",
        status_code=400,
        code="INVALID_VERIFICATION_TOKEN",
      ) from exc

    user = await self.repository.get_user_by_id(
      parsed_user_id
    )

    if user is None:
      raise TraceException(
        "Invalid verification token.",
        status_code=400,
        code="INVALID_VERIFICATION_TOKEN",
      )

    if user.is_verified:
      return

    await self.repository.mark_email_verified(
      user
    )

    await self.session.commit()

  async def resend_verification(
    self,
    email: str,
  ) -> str | None:
    email = self.normalize_email(email)

    user = await self.repository.get_user_by_email(email)
    if user is None or user.is_verified:
      return None
    token = await self.create_email_verification_token(user)
    
    token_value = quote(token, safe="")
    web_link = f"{settings.frontend_base_url}/verify-email?token={token_value}"
    app_link = f"trace://verify-email?token={token_value}"

    await self.email_service.send(
      recipient=user.email,
      subject="Verify your email address",
      body=(
        "Verify your email address:\n\n"
        f"Web: {web_link}\n"
        f"Open in Trace: {app_link}"
      ),
    )

    return token

  async def change_password(
    self,
    user: User,
    current_password: str,
    new_password: str,
    password_confirmation: str,
  ) -> None:

    if not verify_password(
      current_password,
      user.password_hash,
    ):
      raise TraceException(
        "Current password is incorrect.",
        status_code=400,
        code="INVALID_CURRENT_PASSWORD",
      )

    if new_password != password_confirmation:
      raise TraceException(
        "Passwords do not match.",
        status_code=422,
        code="PASSWORD_MISMATCH",
      )

    if verify_password(
      new_password,
      user.password_hash,
    ):
      raise TraceException(
        "New password must be different from your current password.",
        status_code=422,
        code="PASSWORD_REUSE",
      )

    validate_password(new_password)

    user.password_hash = hash_password(
      new_password
    )

    user.failed_login_attempts = 0
    user.locked_until = None

    await self.repository.revoke_all_user_refresh_tokens(
      user.id
    )

    await self.session.commit()

  async def create_password_reset_token(
    self,
    user: User,
  ) -> str:
    return await self.token_store.create(
      prefix="password-reset",
      user_id=str(user.id),
      ttl_seconds=PASSWORD_RESET_TTL_SECONDS,
    )

  async def forgot_password(
    self,
    email: str,
  ) -> str | None:
    email = self.normalize_email(email)

    user = await self.repository.get_user_by_email(email)
    if user is None:
      return None

    token = await self.create_password_reset_token(user)
    token_value = quote(token, safe="")

    web_link = (
      f"{settings.frontend_base_url}/reset-password"
      f"?token={token_value}"
    )
    app_link = f"trace://reset-password?token={token_value}"

    await self.email_service.send(
      recipient=user.email,
      subject="Reset your password",
      body=(
        "Reset your password:\n\n"
        f"Web: {web_link}\n"
        f"Open in Trace: {app_link}"
      ),
    )

    return token

  async def reset_password(
    self,
    token: str,
    new_password: str,
  ) -> None:

    user_id = await self.token_store.consume(
      prefix="password-reset",
      token=token,
    )

    if not user_id:
      raise TraceException(
        "Invalid or expired password reset token.",
        status_code=400,
        code="INVALID_RESET_TOKEN",
      )

    try:
      parsed_user_id = UUID(user_id)
    except ValueError as exc:
      raise TraceException(
        "Invalid password reset token.",
        status_code=400,
        code="INVALID_RESET_TOKEN",
      ) from exc

    user = await self.repository.get_user_by_id(
      parsed_user_id
    )

    if user is None:
      raise TraceException(
        "Invalid password reset token.",
        status_code=400,
        code="INVALID_RESET_TOKEN",
      )

    validate_password(new_password)

    user.password_hash = hash_password(
      new_password
    )

    user.failed_login_attempts = 0
    user.locked_until = None

    await self.repository.revoke_all_user_refresh_tokens(
      user.id
    )

    await self.session.commit()

  async def login(self, email: str, password: str) -> LoginResponse:
    user = await self.authenticate(email=email, password=password)
    membership = await self.resolve_login_membership(user)
    tokens = await self.issue_tokens(user, membership)
    await self.repository.update_user_last_login(user)
    await self.session.commit()

    return LoginResponse(
      user=await self.build_user_response(user, membership),
      tokens=tokens,
    )

  async def _store_refresh_token(
    self, user: User, raw_token: str, organization_id: UUID,
  ) -> RefreshToken:
    payload = decode_token(raw_token)
    expires_at = datetime.fromtimestamp(payload["exp"], tz=timezone.utc)

    token = RefreshToken(
      id=uuid4(),
      user_id=user.id,
      organization_id=organization_id,
      token_hash=self.hash_refresh_token(raw_token),
      expires_at=expires_at,
    )
    return await self.repository.add_refresh_token(token)

  async def issue_tokens(
    self, user: User, membership: OrganizationMembership,
  ) -> TokenResponse:
    access_token = create_access_token(
      subject=str(user.id), organization_id=str(membership.organization_id),
    )
    refresh_token = create_refresh_token(
      subject=str(user.id), organization_id=str(membership.organization_id),
    )
    await self._store_refresh_token(
      user=user, raw_token=refresh_token, organization_id=membership.organization_id,
    )
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)

  async def refresh(
    self,
    raw_refresh_token: str,
  ) -> TokenResponse:

    try:
      payload = decode_token(
        raw_refresh_token
      )
    except Exception as exc:
      raise TraceException(
        "Invalid refresh token.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      ) from exc

    if payload.get("type") != TokenType.REFRESH:
      raise TraceException(
        "Invalid token type.",
        status_code=401,
        code="INVALID_TOKEN_TYPE",
      )

    subject = payload.get("sub")
    organization_id = payload.get("org_id")

    if not subject or not organization_id:
      raise TraceException(
        "Invalid refresh token.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      )

    try:
      user_id = UUID(subject)
      token_org_id = UUID(organization_id)
    except ValueError as exc:
      raise TraceException(
        "Invalid refresh token claims.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      ) from exc

    token_hash = self.hash_refresh_token(
      raw_refresh_token
    )

    stored_token = (
      await self.repository
      .get_refresh_token_by_hash(
        token_hash
      )
    )

    if stored_token is None:
      raise TraceException(
        "Invalid refresh token.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      )

    if stored_token.user_id != user_id:
      raise TraceException(
        "Invalid refresh token.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      )

    if (
      stored_token.organization_id
      != token_org_id
    ):
      raise TraceException(
        "Invalid refresh token.",
        status_code=401,
        code="INVALID_REFRESH_TOKEN",
      )

    if stored_token.is_revoked:
      await self.repository.revoke_all_user_refresh_tokens(
        user_id
      )

      await self.session.commit()

      raise TraceException(
        "Refresh token reuse detected.",
        status_code=401,
        code="REFRESH_TOKEN_REUSE_DETECTED",
      )

    if (
      stored_token.expires_at
      <= datetime.now(timezone.utc)
    ):
      raise TraceException(
        "Refresh token has expired.",
        status_code=401,
        code="REFRESH_TOKEN_EXPIRED",
      )

    user = await self.repository.get_user_by_id(
      user_id
    )

    if user is None or not user.is_active:
      raise TraceException(
        "User account is unavailable.",
        status_code=401,
        code="USER_UNAVAILABLE",
      )

    membership = await self.repository.get_membership(
      user_id=user.id,
      organization_id=stored_token.organization_id,
    )

    if (
      membership is None
      or not membership.is_active
      or not membership.organization.is_active
    ):
      raise TraceException(
      "Organization membership is no longer active.",
      status_code=403,
      code="ORGANIZATION_MEMBERSHIP_INACTIVE",
    )

    new_access_token = create_access_token(
      subject=str(user.id), organization_id=str(stored_token.organization_id),
    )
    new_refresh_token = create_refresh_token(
      subject=str(user.id), organization_id=str(stored_token.organization_id),
    )
    replacement = await self._store_refresh_token(
      user=user, raw_token=new_refresh_token, organization_id=stored_token.organization_id,
    )

    await self.repository.revoke_refresh_token(stored_token, replacement_id=replacement.id)
    await self.session.commit()

    return TokenResponse(access_token=new_access_token, refresh_token=new_refresh_token)
  
  async def get_current_user_in_organization(
    self,
    user_id: UUID,
    organization_id: UUID,
  ) -> User:
    user = await self.repository.get_user_by_id(user_id)

    if user is None:
        raise TraceException(
            "User not found.",
            status_code=401,
            code="USER_NOT_FOUND",
        )

    if not user.is_active:
        raise TraceException(
            "User account is inactive.",
            status_code=403,
            code="USER_INACTIVE",
        )

    membership = await self.repository.get_membership(
        user_id=user_id,
        organization_id=organization_id,
    )

    if membership is None or not membership.is_active:
        raise TraceException(
            "No active membership in this organization.",
            status_code=403,
            code="NO_ACTIVE_MEMBERSHIP",
        )

    if not membership.organization.is_active:
        raise TraceException(
            "Organization is inactive.",
            status_code=403,
            code="ORGANIZATION_INACTIVE",
        )

    user.active_membership = membership
    return user
  
  async def logout(
    self,
    raw_refresh_token: str,
  ) -> None:

    token_hash = self.hash_refresh_token(
      raw_refresh_token
    )

    stored_token = (
      await self.repository
      .get_refresh_token_by_hash(
        token_hash
      )
    )

    if stored_token is None:
      return

    if not stored_token.is_revoked:
      await self.repository.revoke_refresh_token(
        stored_token
      )

    await self.session.commit()

  async def logout_all(
    self,
    user_id: UUID,
  ) -> None:

    await self.repository.revoke_all_user_refresh_tokens(
      user_id
    )

    await self.session.commit()

  async def get_current_user(
    self,
    user_id: UUID,
  ) -> User:

    user = await self.repository.get_user_by_id(
      user_id
    )

    if user is None:
      raise TraceException(
        "User not found.",
        status_code=401,
        code="USER_NOT_FOUND",
      )

    if not user.is_active:
      raise TraceException(
        "User account is inactive.",
        status_code=403,
        code="USER_INACTIVE",
      )
    
    if not user.is_verified:
      raise TraceException(
        "Please verify your email address before logging in.",
        status_code=403,
        code="EMAIL_NOT_VERIFIED",
      )

    return user
  
  async def resolve_login_membership(
    self,
    user: User,
  ) -> OrganizationMembership:
    membership = await self.repository.get_membership(
      user_id=user.id,
      organization_id=user.organization_id,
    )

    if membership is not None and membership.organization.is_active:
      return membership

    active_memberships = [
      m for m in await self.repository.get_active_memberships(user.id)
      if m.organization.is_active
    ]

    if not active_memberships:
      raise TraceException(
        "No active organization membership found.",
        status_code=403, code="NO_ACTIVE_ORGANIZATION",
      )

    return active_memberships[0]
  
  async def build_user_response(
    self,
    user: User,
    membership: OrganizationMembership,
  ) -> UserResponse:
    platform_admin = await self.repository.get_platform_admin(user.id)
    return UserResponse(
      id=user.id,
      organization_id=membership.organization_id,
      email=user.email,
      first_name=user.first_name,
      last_name=user.last_name,
      is_active=user.is_active,
      is_verified=user.is_verified,
      last_login_at=user.last_login_at,
      role=RoleResponse.model_validate(membership.role),
      organization=OrganizationResponse.model_validate(membership.organization),
      is_platform_admin=platform_admin is not None,
    )