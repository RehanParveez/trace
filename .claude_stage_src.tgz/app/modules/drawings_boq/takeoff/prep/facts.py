from __future__ import annotations
import re
from collections import Counter
from app.modules.drawings_boq.takeoff.prep import spec_blocks

MM_INCH = 25.4
MM_FOOT = 304.8
_FRACTIONS = {"½": " 1/2", "¼": " 1/4", "¾": " 3/4", "⅛": " 1/8", "⅜": " 3/8", "⅝": " 5/8", "⅞": " 7/8"}
MAX_ITEMS_PER_SHEET = 60
MAX_LEVEL_MM = 120000.0
MIN_LEVEL_REPEATS = 2

_IN = r"(?P<in>\d{1,3}(?:\s+\d{1,2}/\d{1,2}|\s*/\s*\d{1,2})?)\s*(?:\"|″|”|'')"
_SLAB_THICK = re.compile(_IN + r"\s*THICK\s+(?:R\.?\s?C\.?\s?C\.?\s+)?SLAB", re.I)
_SLAB_NOTE = re.compile(r"(?P<scope>[A-Z][A-Z ]*?)\bSLABS?\s+(?:ARE|IS)\s+" + _IN + r"\s*THICK", re.I)
_WALL_THICK = re.compile(_IN + r"\s*THICK\s+R\.?\s?C\.?\s?C\.?\s+WALL", re.I)
_BRICK_COLUMN = re.compile(r"BRICK\s+COLUMNS?\s+(?P<a>\d{1,2})\s*(?:\"|″|”)?\s*[X×]\s*(?P<b>\d{1,2})\s*(?:\"|″|”)?", re.I)
_STEEL = re.compile(r"\bG\s*-?\s*(?P<grade>40|60|75)\b\s+DEFORMED\s+STEEL\s+FOR\s+(?P<scope>.+)$", re.I)
_CONCRETE = re.compile(r"CLASS\s+[\"“”']?(?P<cls>[A-D])[\"“”']?\s*\((?P<mix>[\d.]+\s*:\s*[\d.]+(?:\s*1/2)?\s*:\s*[\d.]+)\)\s*CONCRETE\s*(?:IN\s+)?(?P<scope>.*)$", re.I)
_COVER = re.compile(r"\(\s*[a-f]\s*\)\s*(?P<member>SLABS?|BEAMS?|COLUMNS?|FOOTINGS?|WALLS?)\s+" + _IN + r"\s*(?P<where>[A-Z ]*)", re.I)
_BEARING = re.compile(r"BEARING\s+CAPACITY[^0-9]{0,40}(?P<v>\d+(?:\.\d+)?)\s*(?P<u>TSF|KSF|PSF|PSI|KN\s*/\s*M2|KPA)", re.I)
_PLASTER = re.compile(_IN + r"\s*TH\.?\s*(?:C\.?\s?M\.?\s*)?PLASTER\b(?P<rest>.{0,60})", re.I)
_FILL_LAYER = re.compile(_IN + r"\s*THICK\s+COMPACTED\s+LAYERS", re.I)
_SOIL_STAB = re.compile(r"STABILI[SZ](?:E|ED|ES|ING|ATION)")
_SOIL_PCT = re.compile(r"(?P<pct>\d{1,2}(?:\.\d{1,2})?)\s*(?:%|PERCENT|PER\s*CENT)", re.I)
_SOIL_DEPTH = re.compile(_IN + r"\s*(?:DEEP|DEPTH|THICK|LAYER)|(?:DEPTH|THICKNESS|LAYER)\s*(?:OF|=|:)?\s*" + _IN.replace("(?P<in>", "(?P<in2>"), re.I)
_STAIR_WIDTH = re.compile(r"STAIR\s+WIDTH\s*=\s*(?P<ft>\d+)\s*'\s*-?\s*(?P<in>\d+)?", re.I)
_LAP = re.compile(r"\(\s*[a-f]\s*\)\s*(?P<d>\d{1,2}(?:\s*/\s*\d{1,2})?)\s*(?:\"|″|”|'')\s*\S{0,2}\s*=\s*" + _IN, re.I)
_PCC_THICK = re.compile(_IN + r"\s*(?:THICK\s+)?P\.?\s?C\.?\s?C\b", re.I)
_COMPACTION = re.compile(r"(?P<v>\d{2,3})\s*%\s*OF\s+(?P<method>MODIFIED|STANDARD)\s+(?P<kind>AASHTO|PROCTOR)", re.I)
_LEVEL = re.compile(r"^\s*(?P<sign>[+\-±]|\+/-)\s*(?P<ft>\d{1,3})\s*'\s*-?\s*(?P<in>\d{1,2}(?:\s+\d/\d)?)?\s*(?:\"|″|”|'')?\s*$")
_DPC = re.compile(_IN + r"\s*(?:TH\.?|THICK)\s+D\.?\s?P\.?\s?C\b", re.I)
SINGLE_VALUE = {"SLAB_THICKNESS": "slab thickness", "BEARING_CAPACITY": "soil bearing capacity", "RCC_WALL_THICKNESS": "RCC wall thickness"}
_WATERPROOF_WORDS = re.compile(r"SIK[A-Z]*|DAVCO|WATER\s*-?\s*PROOF|SOVACRYL", re.I)
_MIX = r"\(\s*(?P<mix>\d(?:\.\d)?\s*:\s*\d(?:\.\d)?(?:\s*:\s*\d(?:\.\d)?)?)\s*\)"
_LAYER_MATERIAL = (r"(?P<mat>P\.?\s?C\.?\s?C\.?|BRICK\s+BALLAST|SAND\s+FILLING|C\s*/\s*S\s+PLASTER|MUD\s+PLASTER|BRICK\s+TILES|"
  r"COMPACTED\s+MUD\s+LAYER)")
_LAYER = re.compile(_IN + r"\s*(?P<th>(?:TH\.?|THICK)\s+)?" + _LAYER_MATERIAL + r"(?:\s*\.?\s*" + _MIX + r")?", re.I)
_PCC_AFTER = re.compile(r"\bP\.?\s?C\.?\s?C\.?\s*" + _MIX + r"\s*" + _IN + r"(?!\s*(?:TH\b|THICK\b))", re.I)
_IN_A = _IN.replace("(?P<in>", "(?P<a>")
_IN_B = _IN.replace("(?P<in>", "(?P<b>")
_PCC_FLANK = re.compile(_IN_A + r"\s*P\.?\s?C\.?\s?C\.?\s*(?:" + _MIX + r")?\s*" + _IN_B, re.I)
_DPC = re.compile(_IN + r"\s*(?:TH\.?|THICK)\s+D\.?\s?P\.?\s?C\b", re.I)
_WP_LAYER = re.compile(r"\b(?P<n>ONE|TWO|THREE|[1-3])\s+(?P<unit>LAYERS?|COATS?)\s+(?:OF\s+)?(?P<what>[A-Z0-9][^*]{2,90})", re.I)
_WP_POLYTHENE = re.compile(r"\bPOLY(?:THENE|ETHYLENE)\b", re.I)
_WP_COAT = re.compile(r"\b(?:DAVCO|SOVACRYL|BITUMEN|BITUMINOUS|WATER\s*-?\s*PROOFING|ACRYLIC|SIKA[A-Z]*)\b", re.I)
_FALL = re.compile(_IN.replace("(?P<in>", "(?P<lo>") + r"\s*(?:-|–|TO)\s*" + _IN.replace("(?P<in>", "(?P<hi>") + r"\s*(?:TH\.?|THICK)\s+(?:COMPACTED\s+)?(?:MUD|BRICK\s*BAT|COBA)\s+(?:LAYER|FILL(?:ING)?)?\s*(?:IN\s+SLOPE|TO\s+(?:SLOPE|FALL))", re.I)
_WP_COUNT = {"ONE": 1, "TWO": 2, "THREE": 3, "1": 1, "2": 2, "3": 3}
_COMPACTION = re.compile(r"(?P<v>\d{2,3})\s*%\s*OF\s+(?P<method>MODIFIED|STANDARD)\s+(?P<kind>AASHTO|PROCTOR)", re.I)
_STAB_CEMENT = re.compile(r"USING\s+(?P<v>\d{1,2}(?:\.\d)?)\s*%\s*CEMENT", re.I)
_STAB_HEAD = re.compile(r"SOIL\s+STABI[LI]{1,2}[SZ]ATION", re.I)
_LOOSE_ONLY = re.compile(r"IN\s+CASE\s+OF\s+LOOSE\s+SOIL(?:\s+ONLY)?", re.I)

def _fix(text: str) -> str:
  s = text
  for k, v in _FRACTIONS.items():
    s = s.replace(k, v)
  return re.sub(r"\s+", " ", s).strip()

def inches_mm(s: str) -> float | None:
  """'6' -> 152.4, '1 1/2' -> 38.1, '3/4' -> 19.05."""
  s = (s or "").strip()
  m = re.fullmatch(r"(\d{1,3})(?:\s+(\d{1,2})\s*/\s*(\d{1,2}))?", s)
  if m:
    whole = float(m.group(1))
    if m.group(2):
      if int(m.group(3)) == 0:
        return None
      whole += int(m.group(2)) / int(m.group(3))
    return round(whole * MM_INCH, 2)
  m = re.fullmatch(r"(\d{1,2})\s*/\s*(\d{1,2})", s)
  if m and int(m.group(2)) != 0:
    return round(int(m.group(1)) / int(m.group(2)) * MM_INCH, 2)
  return None

def _clean_scope(s: str) -> str:
  s = re.sub(r"[^A-Za-z0-9,/&\- ]+", " ", s or "")
  s = re.sub(r"\s*,\s*", ", ", s)
  return re.sub(r"\s+", " ", s).strip(" ,-").lower()[:80]

def _item(kind: str, text: str, **extra) -> dict:
  return {"kind": kind, "text": text[:140], **extra}

def _soil_note(t: str) -> dict | None:
  up = t.upper()
  if not _SOIL_STAB.search(up) or "CEMENT" not in up:
    return None
  m = _SOIL_PCT.search(up)
  if not m:
    return None
  extra: dict = {"cement_pct": float(m.group("pct")), "loose": bool(re.search(r"\bLOOSE\b", up))}
  d = _SOIL_DEPTH.search(up)
  mm = inches_mm(d.group("in") or d.group("in2")) if d and (d.group("in") or d.group("in2")) else None
  if mm:
    extra["value_mm"] = mm
  return _item("SOIL_STABILISATION", t, scope="soil", **extra)

_MIX_RE = re.compile(_MIX, re.I)

def _mix_text(raw: str) -> str:
  return re.sub(r"\s+", "", raw or "")

def _pcc_scope(mix: str | None) -> str:
  if not mix:
    return "pcc bed"
  parts = [float(x) for x in re.split(r":", _mix_text(mix)) if x]
  if len(parts) == 3 and parts[1] + parts[2] < 8.0:
    return "floor pcc"
  return "pcc bed"

LAYER_KEY = {"PCC": "pcc", "BRICKBALLAST": "brick ballast", "SANDFILLING": "sand filling", "C/SPLASTER": "cement sand bed", "MUDPLASTER": "mud plaster",
  "BRICKTILES": "brick tiles", "COMPACTEDMUDLAYER": "compacted mud"}

def _layer_key(mat: str) -> str:
  k = re.sub(r"[\s.]+", "", mat.upper())
  return LAYER_KEY.get("PCC" if k == "PCC" else k, k.lower())

def _layers(t: str) -> list[dict]:
  out: list[dict] = []
  for m in _LAYER.finditer(t):
    before = t[:m.start()]
    if re.search(r"\d\s*(?:\"|″|”|'')\s*-\s*$", before):
      continue
    
    mm = inches_mm(m.group("in"))
    if not mm:
      continue
    key = _layer_key(m.group("mat"))
    if not m.group("th") and key not in ("sand filling", "brick ballast"):
      continue  
    extra = {"mix": _mix_text(m.group("mix"))} if m.group("mix") else {}
    out.append(_item("BUILD_UP_LAYER", t, value_mm=mm, layer=key, scope="floor build-up", **extra))
  return out

def _roof_fall(t: str) -> list[dict]:
  out: list[dict] = []
  for m in _FALL.finditer(t):
    lo, hi = inches_mm(m.group("lo")), inches_mm(m.group("hi"))
    if lo and hi and hi > lo:
      out.append(_item("ROOF_FALL", t, min_mm=lo, max_mm=hi, value_mm=round((lo + hi) / 2.0, 2), scope="roof fall"))
  return out

def _waterproof_layers(t: str) -> list[dict]:
  out: list[dict] = []
  for m in _WP_LAYER.finditer(t):
    what = m.group("what")
    if _WP_POLYTHENE.search(what):
      material = "polythene sheet"
    elif _WP_COAT.search(what):
      material = "waterproofing coat"
    else:
      continue
    out.append(_item("WATERPROOF_LAYER", t, value=float(_WP_COUNT[m.group("n").upper()]), unit=m.group("unit").lower().rstrip("s"), scope=material, material=material))
  return out

def read_line(text: str) -> list[dict]:
  """The facts one line of drawing text states. Most lines state none."""
  t = _fix(text)

  if len(t) < 6:
    return []
  out: list[dict] = []
  m = _SLAB_THICK.search(t)
  if m and inches_mm(m.group("in")):
    out.append(_item("SLAB_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope="slab"))
  else:
    m = _SLAB_NOTE.search(t)
    if m and inches_mm(m.group("in")):
      scope = _clean_scope(m.group("scope"))
      scope = re.sub(r"^(?:all|\*)\s*", "all ", scope).strip() or "all"
      out.append(_item("SLAB_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope=("all slabs" if scope in ("all", "") else scope + " slab")))
  m = _WALL_THICK.search(t)
  if m and inches_mm(m.group("in")):
    out.append(_item("RCC_WALL_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope="rcc wall"))
  m = _BRICK_COLUMN.search(t)
  if m:
    out.append(_item("BRICK_COLUMN", t, value_mm=round(int(m.group("a")) * MM_INCH, 2), value2_mm=round(int(m.group("b")) * MM_INCH, 2), scope="brick column"))
  m = _STEEL.search(t)
  if m:
    out.append(_item("STEEL_GRADE", t, grade=int(m.group("grade")), scope=_clean_scope(m.group("scope"))))
  m = _CONCRETE.search(t)
  if m:
    mix = re.sub(r"\s+", "", m.group("mix")).replace("1/2", ".5")
    out.append(_item("CONCRETE_CLASS", t, concrete_class=m.group("cls").upper(), mix=mix, scope=_clean_scope(m.group("scope"))))
  m = _COVER.search(t)
  if m and inches_mm(m.group("in")):
    member = m.group("member").lower().rstrip("s")
    out.append(_item("CLEAR_COVER", t, value_mm=inches_mm(m.group("in")), scope=member, where=_clean_scope(m.group("where"))))
  m = _BEARING.search(t)
  
  if m:
    out.append(_item("BEARING_CAPACITY", t, value=float(m.group("v")), unit=re.sub(r"\s+", "", m.group("u")).upper(), scope="soil"))
  m = _PLASTER.search(t)
  if m and inches_mm(m.group("in")):
    rest = m.group("rest") or ""
    scope = "waterproof plaster" if _WATERPROOF_WORDS.search(rest) else "cement mortar plaster"
    mix = _MIX_RE.search(rest)
    out.append(_item("PLASTER_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope=scope, **({"mix": _mix_text(mix.group("mix"))} if mix else {})))
  out.extend(_layers(t))
  out.extend(_roof_fall(t))
  out.extend(_waterproof_layers(t))
  m = _DPC.search(t)
  if m and inches_mm(m.group("in")):
    out.append(_item("DPC_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope="dpc"))
  m = _COMPACTION.search(t)
  if m:
    out.append(_item("COMPACTION_PCT", t, value=float(m.group("v")), method=f"{m.group('method').lower()} {m.group('kind').lower()}", scope="compacted fill"))
  m = _STAB_CEMENT.search(t)
  if m:
    out.append(_item("STAB_CEMENT_PCT", t, value=float(m.group("v")), scope="soil stabilisation"))
  if _STAB_HEAD.search(t):
    out.append(_item("SOIL_STAB_NOTE", t, scope="soil stabilisation"))
  if _LOOSE_ONLY.search(t):
    out.append(_item("SOIL_STAB_CONDITION", t, condition="loose soil only", scope="soil stabilisation"))
  m = _FILL_LAYER.search(t)
  if m and inches_mm(m.group("in")):
    out.append(_item("FILL_LAYER", t, value_mm=inches_mm(m.group("in")), scope="compacted fill layer"))
    
  soil = _soil_note(t)
  if soil is not None:
    out.append(soil)
  m = _LAP.search(t)
  if m and inches_mm(m.group("in")) and inches_mm(m.group("d")):
    dia = inches_mm(m.group("d"))
    out.append(_item("LAP_LENGTH", t, value_mm=inches_mm(m.group("in")), bar_dia_mm=dia, scope=f"lap bar {round(dia / 3.175)}"))
  flank = _PCC_FLANK.search(t)
  m = _PCC_THICK.search(t)
  
  if flank and inches_mm(flank.group("a")) and inches_mm(flank.group("a")) == inches_mm(flank.group("b")):
    out.append(_item("PCC_PROJECTION", t, value_mm=inches_mm(flank.group("a")), scope=_pcc_scope(flank.group("mix")),
      **({"mix": _mix_text(flank.group("mix"))} if flank.group("mix") else {})))
  elif flank and m and m.start() == flank.start():
    pass 
  elif m and inches_mm(m.group("in")):
    mix = _MIX_RE.search(t[m.end():m.end() + 24])
    out.append(_item("PCC_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope=_pcc_scope(mix.group("mix") if mix else None), **({"mix": _mix_text(mix.group("mix"))} if mix else {})))
  else:
    m = _PCC_AFTER.search(t)
    if m and inches_mm(m.group("in")):
      out.append(_item("PCC_THICKNESS", t, value_mm=inches_mm(m.group("in")), scope=_pcc_scope(m.group("mix")), mix=_mix_text(m.group("mix"))))
  m = _STAIR_WIDTH.search(t)
  if m:
    out.append(_item("STAIR_WIDTH", t, value_mm=round(int(m.group("ft")) * MM_FOOT + int(m.group("in") or 0) * MM_INCH, 2), scope="stair"))
  return out

def level_mark_mm(text: str) -> float | None:
  m = _LEVEL.match(_fix(text))
  if not m:
    return None
  inch = inches_mm(m.group("in")) if m.group("in") else 0.0
  if inch is None:
    return None
  mm = int(m.group("ft")) * MM_FOOT + inch
  if mm > MAX_LEVEL_MM:
    return None
  return round(-mm if m.group("sign") == "-" else mm, 1)

PLAUSIBLE_MM = {"SLAB_THICKNESS": (75.0, 400.0), "PLASTER_THICKNESS": (6.0, 40.0), "CLEAR_COVER": (10.0, 100.0), "FILL_LAYER": (50.0, 600.0), "LAP_LENGTH": (150.0, 3000.0), "PCC_THICKNESS": (25.0, 300.0),
  "RCC_WALL_THICKNESS": (100.0, 600.0), "STAIR_WIDTH": (600.0, 3000.0), "SOIL_STABILISATION": (50.0, 1500.0)}
PLAUSIBLE_CEMENT_PCT = (1.0, 20.0)
PLAUSIBLE_BEARING_TSF = (0.1, 20.0)

def plausible(item: dict) -> bool:
  kind = item.get("kind")
  bounds = PLAUSIBLE_MM.get(kind)
  if bounds is not None and item.get("value_mm") is not None:
    return bounds[0] <= float(item["value_mm"]) <= bounds[1]
  if kind == "SOIL_STABILISATION" and not PLAUSIBLE_CEMENT_PCT[0] <= float(item.get("cement_pct") or 0.0) <= PLAUSIBLE_CEMENT_PCT[1]:
    return False
  if kind == "BRICK_COLUMN":
    return all(150.0 <= float(item.get(k) or 0.0) <= 500.0 for k in ("value_mm", "value2_mm"))
  if kind == "BEARING_CAPACITY" and str(item.get("unit")) == "TSF":
    return PLAUSIBLE_BEARING_TSF[0] <= float(item.get("value") or 0.0) <= PLAUSIBLE_BEARING_TSF[1]
  return True

def _texts(lines: list, found: dict) -> list:
  """(text, block) for everything to read: the lines of the sheet without the words that belong to a specification block, then each entry of each block."""
  used = found["used"]
  out: list = []
  for ln in lines:
    text = getattr(ln, "text", ln)
    spans = getattr(ln, "spans", None)
    if used and spans:
      kept = [w.text for _, _, w in spans if id(w) not in used]
      if not kept:
        continue
      if len(kept) < len(spans):
        text = " ".join(kept)
    out.append((text, None))
  out.extend((entry, block) for block in found["blocks"] for entry in block["entries"])
  return out

_NAMED_LEVEL = re.compile(r"\b(?P<n>ROAD\s*LEVEL|R\.?\s?LEV\.?|D\.?\s?P\.?\s?C\.?|F\.?\s?F\.?\s?LEV(?:EL)?\.?|PLINTH\s*LEVEL|GROUND\s*LEVEL)\s*(?P<m>(?:\+/-|[+\-\u00b1])\s*\d{1,3}\s*'.*)$", re.I)

def _level_name(raw: str) -> str:
  t = re.sub(r"[\s.]", "", raw.upper())
  if t.startswith(("ROAD", "RLEV")):
    return "ROAD"
  if t == "DPC":
    return "DPC"
  if t.startswith("FF"):
    return "FLOOR"
  return "PLINTH" if t.startswith("PLINTH") else "GROUND"

def named_levels(lines: list) -> list:
  seen: Counter = Counter()
  for ln in lines:
    m = _NAMED_LEVEL.search(_fix(getattr(ln, "text", ln) or ""))
    if not m:
      continue
    mm = level_mark_mm(m.group("m"))
    if mm is not None:
      seen[(_level_name(m.group("n")), mm)] += 1
  return [{"name": n, "mm": mm, "count": c} for (n, mm), c in sorted(seen.items())]

def read_facts(lines: list, words: list | None = None, scanned: bool = False) -> dict:
  seen: dict = {}
  marks: Counter = Counter()
  found = spec_blocks.read(words)
  for text, block in _texts(lines, found):
    lvl = level_mark_mm(text) if block is None else None
    if lvl is not None:
      marks[lvl] += 1
      continue
  
    for it in read_line(text):
      if block is not None:
        it = {**it, "under": block["key"], "heading": block["heading"]}
      if scanned:
        if not plausible(it):
          continue
        it = {**it, "ocr": True}
      key = (it["kind"], it.get("scope"), it.get("value_mm"), it.get("value"), it.get("grade"), it.get("concrete_class"), it.get("mix"), it.get("where"), it.get("layer"), it.get("condition"), it.get("method"), it.get("under"))
      if key in seen:
        seen[key]["count"] += 1
      elif len(seen) < MAX_ITEMS_PER_SHEET:
        seen[key] = {**it, "count": 1}
  out = {"items": list(seen.values()), "level_marks": [{"mm": k, "count": v} for k, v in sorted(marks.items())]}
  named = named_levels(lines)
  if named:
    out["named_levels"] = named
  if found["blocks"]:
    out["spec_blocks"] = [{"key": b["key"], "heading": b["heading"], "entries": len(b["entries"])} for b in found["blocks"]]
  if words:
    from app.modules.drawings_boq.takeoff.prep.storeys import read_storeys
    found = read_storeys(words, lines)
    if found:
      out["storeys"] = found
  return out

def level_ladder(marks: list[dict]) -> dict:
  """The floor levels shown on the elevations and the height between each pair. A mark seen once may be a stray, so a level needs a repeat to count."""
  by_mm: Counter = Counter()
  
  for m in marks:
    by_mm[m["mm"]] += int(m.get("count", 1))
  levels = sorted(mm for mm, n in by_mm.items() if n >= MIN_LEVEL_REPEATS)
  gaps = [round(b - a, 1) for a, b in zip(levels, levels[1:])]
  typical = None
  if len(gaps) >= 2:
    common = Counter(round(g / 5.0) * 5.0 for g in gaps).most_common(1)[0]
    if common[1] >= 2:
      typical = round(sum(g for g in gaps if round(g / 5.0) * 5.0 == common[0]) / common[1], 1)
  return {"levels_mm": levels, "gaps_mm": gaps, "typical_floor_to_floor_mm": typical}

def suggest_wall_height(items: list, ladder: dict) -> dict | None:
  """A wall height to offer the estimator, never to apply on its own: the floor-to-floor height on the elevations minus the slab thickness
  in the notes. Where two slab thicknesses are printed, the more often printed one is offered and the other is listed beside it."""
  f2f = (ladder or {}).get("typical_floor_to_floor_mm")
  slabs: dict = {}
  for it in items:
    if it.get("kind") == "SLAB_THICKNESS" and it.get("value_mm"):
      row = slabs.setdefault(round(it["value_mm"], 1), {"slab_mm": round(it["value_mm"], 1), "count": 0, "pages": set()})
      row["count"] += int(it.get("count", 1))
      row["pages"].update(it.get("pages") or [])
  if not f2f or not slabs:
    return None
  ranked = sorted(slabs.values(), key=lambda r: (-r["count"], -r["slab_mm"]))
  top = ranked[0]
  out = {"value_mm": round(f2f - top["slab_mm"], 1), "floor_to_floor_mm": f2f, "slab_mm": top["slab_mm"], "basis": "FLOOR_TO_FLOOR_LESS_SLAB",
    "alternatives": [{"slab_mm": r["slab_mm"], "value_mm": round(f2f - r["slab_mm"], 1), "pages": sorted(r["pages"])} for r in ranked[1:4]]}
  if not 1500.0 <= out["value_mm"] <= 6500.0:
    return None
  return out

GENERIC_SLAB_SCOPES = ("slab", "all slabs")

def slab_values(items: list) -> list[dict]:
  """The slab thicknesses the drawing prints for slabs in general (a note "ALL SLABS ARE 5" THICK", a section label "6" Thick R.c.c Slab"),
  one row per distinct value: {"mm", "count", "pages", "scopes"}. Most often printed first. A slab named in a note of its own (a waist slab, a tank slab) is not general."""
  by: dict = {}
  
  for it in items or []:
    if it.get("kind") != "SLAB_THICKNESS" or not it.get("value_mm"):
      continue
    if (it.get("scope") or "slab") not in GENERIC_SLAB_SCOPES:
      continue
    row = by.setdefault(round(float(it["value_mm"]), 1), {"mm": round(float(it["value_mm"]), 1), "count": 0, "pages": set(), "scopes": set()})
    row["count"] += int(it.get("count", 1))
    row["pages"].update(it.get("pages") or [])
    row["scopes"].add(it.get("scope") or "slab")
  rows = sorted(by.values(), key=lambda r: (-r["count"], r["mm"]))
  return [{"mm": r["mm"], "count": r["count"], "pages": sorted(r["pages"]), "scopes": sorted(r["scopes"])} for r in rows]

FLOOR_ORDER = ("BASEMENT", "GROUND", "FIRST", "SECOND", "THIRD", "FOURTH", "ROOF")

def floor_heights(floor_keys: list, ladder: dict, slab_mm: float | None) -> dict:
  """The clear wall height offered for each floor: the gap between its level mark and the next one up, less the slab. The floors above the ground
  take the top level marks in order (the last mark is the roof of the top floor); a floor below the ground has no mark and takes the typical
  floor-to-floor height. Nothing is offered without a slab thickness."""
  if not slab_mm:
    return {}
  keys = [k for k in FLOOR_ORDER if k in floor_keys]
  above = [k for k in keys if k != "BASEMENT"]
  levels = (ladder or {}).get("levels_mm") or []
  typical = (ladder or {}).get("typical_floor_to_floor_mm")
  out: dict = {}
  if above and len(levels) >= len(above) + 1:
    marks = levels[-(len(above) + 1):]
    for i, k in enumerate(above):
      gap = marks[i + 1] - marks[i]
      if 1500.0 <= gap - slab_mm <= 6500.0:
        out[k] = {"clear_mm": round(gap - slab_mm, 1), "floor_to_floor_mm": round(gap, 1), "basis": "LEVEL_MARKS", "level_mm": round(marks[i], 1)}
  for k in keys:
    if k not in out and typical and 1500.0 <= typical - slab_mm <= 6500.0:
      out[k] = {"clear_mm": round(typical - slab_mm, 1), "floor_to_floor_mm": typical, "basis": "TYPICAL"}
  return out

def gather(sheets: list[dict]) -> dict:
  """All sheets' facts together. Each sheet is {"page_no", "label", "facts"}. The same fact on several sheets is one row with its pages.
  A fact that must be one number but is printed as two is returned under conflicts, so nobody builds a quantity on the wrong one."""
  rows: dict = {}
  marks: list = []
  
  storeys = None
  named: Counter = Counter()
  for sh in sheets:
    facts = sh.get("facts") or {}
    marks.extend(facts.get("level_marks") or [])
    for nl in facts.get("named_levels") or []:
      named[(nl["name"], nl["mm"])] += int(nl.get("count", 1))
    got = facts.get("storeys")
    
    if got and (storeys is None or (got.get("consistent"), len(got.get("clusters") or [])) > (storeys.get("consistent"), len(storeys.get("clusters") or []))):
      storeys = {**got, "page_no": sh["page_no"]}
    for it in facts.get("items") or []:
      key = (it["kind"], it.get("scope"), it.get("value_mm"), it.get("value"), it.get("grade"), it.get("concrete_class"), it.get("mix"), it.get("where"), it.get("layer"), it.get("under"))
      row = rows.get(key)
      
      if row is None:
        row = rows[key] = {**{k: v for k, v in it.items() if k != "count"}, "count": 0, "pages": []}
      row["count"] += int(it.get("count", 1))
      if sh["page_no"] not in row["pages"]:
        row["pages"].append(sh["page_no"])
        
  items = sorted(rows.values(), key=lambda r: (r["kind"], r.get("scope") or "", r.get("value_mm") or r.get("value") or 0))
  conflicts = []
  for kind, name in SINGLE_VALUE.items():
    mine = [r for r in items if r["kind"] == kind]
    by_value: dict = {}
    for r in mine:
      v = by_value.setdefault(r.get("value_mm", r.get("value")), {"value_mm": r.get("value_mm"), "value": r.get("value"), "unit": r.get("unit"), "scopes": [], "pages": [], "text": r["text"]})
      if r.get("scope") and r["scope"] not in v["scopes"]:
        v["scopes"].append(r["scope"])
      v["pages"] = sorted(set(v["pages"]) | set(r["pages"]))
    if len(by_value) > 1:
      conflicts.append({"kind": kind, "name": name, "values": list(by_value.values())})
  ladder = level_ladder(marks)
  return {"items": items, "conflicts": conflicts, "ladder": ladder, "storeys": storeys, "suggest": {"wall_height": suggest_wall_height(items, ladder)},
    "named_levels": [{"name": n, "mm": mm, "count": c} for (n, mm), c in sorted(named.items())]}