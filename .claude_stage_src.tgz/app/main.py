from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import dispose_engine
from app.core.exceptions import TraceException, trace_exception_handler
from app.core.logging import configure_logging
from app.modules.identity.router import router as identity_router
from app.modules.organizations.router import router as organizations_router
from app.modules.subscriptions.router import router as subscriptions_router
from app.modules.projects.router import router as projects_router
from app.modules.drawings_boq.router import router as drawings_boq_router
from app.modules.drawings_boq.standards.router import router as standards_router
from app.modules.drawings_boq.finish_schedule.router import router as finish_schedule_router
from app.modules.drawings_boq.difference.business import router as run_difference_router
from app.modules.drawings_boq.steel_view.business import router as steel_summary_router
from app.modules.drawings_boq.takeoff.router import router as takeoff_router
from app.modules.drawings_boq.lab.router import router as bill_compare_router
from app.modules.drawings_boq.lab.expected_business import router as expected_boq_router
from app.modules.drawings_boq.rebar.rebar_router import router as rebar_router
from app.modules.drawings_boq.pricing.router import router as pricing_router
from app.modules.drawings_boq.pricing.rate_import_router import router as rate_import_router
from app.modules.drawings_boq.measurement_params import router as measurement_params_router
from app.modules.drawings_boq.one_total_business import router as one_total_router
from app.modules.drawings_boq.datums import router as datums_router
from app.modules.drawings_boq.element_params import router as element_params_router
from app.modules.whatsapp.router import router as  whatsapp_router
from app.modules.verification.router import router as verification_router
from app.modules.notifications.router import router as notifications_router
from app.modules.audit.router import router as audit_router
from app.modules.ai_requests.router import router as ai_requests_router
from app.modules.budgets.router import router as budgets_router
from app.modules.site_progress.router import router as site_progress_router
from app.modules.procurement.router import router as procurement_router
from app.modules.expenses.router import router as expenses_router
from app.modules.running_bills.router import router as running_router
from app.modules.labour.router import router as labour_router
from app.modules.subcontractors.router import router as subcontractor_router
from app.modules.withholding_tax.router import router as withholding_tax_router
from app.modules.material_stock.router import router as material_stock_router
from app.modules.retention.router import router as retention_router
from app.modules.change_orders.router import router as change_orders_router
from app.modules.scheduling.router import router as scheduling_router
from app.modules.punch_lists.router import router as punch_lists_router
from app.modules.sales_tax.router import router as salex_tax_router
from app.modules.bank_guarantees.router import router as bank_guarantees_router
from app.modules.cash_flow.router import router as cash_flow_router
from app.modules.alerts.router import router as alerts_router
from app.modules.privacy.router import router as privacy_router
from app.core.crypto import check_settings as check_encryption_settings

@asynccontextmanager
async def lifespan(app: FastAPI):
  configure_logging()
  check_encryption_settings()
  yield
  await dispose_engine()

app = FastAPI(
  title=settings.app_name,
  version="0.1.0",
  description="Trace, Construction Intelligence Platform",
  lifespan=lifespan,
)

app.add_exception_handler(TraceException, trace_exception_handler)

app.add_middleware(
  CORSMiddleware,
  allow_origins=settings.cors_origin_list,
  allow_credentials=True,
  allow_methods=["*"],
  allow_headers=["*"],
  expose_headers=["X-Total-Count", "X-Next-Cursor"],
)

app.include_router(identity_router, prefix=settings.api_v1_prefix)

app.include_router(organizations_router, prefix=settings.api_v1_prefix)

app.include_router(subscriptions_router, prefix=settings.api_v1_prefix)

app.include_router(projects_router, prefix=settings.api_v1_prefix)

app.include_router(drawings_boq_router, prefix=settings.api_v1_prefix)

app.include_router(standards_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(finish_schedule_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(takeoff_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(bill_compare_router, prefix=settings.api_v1_prefix)

app.include_router(expected_boq_router, prefix=settings.api_v1_prefix)

app.include_router(run_difference_router, prefix=settings.api_v1_prefix)

app.include_router(steel_summary_router, prefix=settings.api_v1_prefix)

app.include_router(rebar_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(pricing_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(rate_import_router, prefix=f"{settings.api_v1_prefix}/drawings-boq",)

app.include_router(measurement_params_router, prefix=settings.api_v1_prefix)

app.include_router(one_total_router, prefix=settings.api_v1_prefix)

app.include_router(datums_router, prefix=settings.api_v1_prefix)

app.include_router(element_params_router, prefix=settings.api_v1_prefix)

app.include_router(whatsapp_router, prefix=settings.api_v1_prefix)

app.include_router(verification_router, prefix=settings.api_v1_prefix)

app.include_router(notifications_router, prefix=settings.api_v1_prefix)

app.include_router(audit_router, prefix=settings.api_v1_prefix)

app.include_router(ai_requests_router, prefix=settings.api_v1_prefix)

app.include_router(budgets_router, prefix=settings.api_v1_prefix)

app.include_router(site_progress_router, prefix=settings.api_v1_prefix)

app.include_router(procurement_router, prefix=settings.api_v1_prefix)

app.include_router(expenses_router, prefix=settings.api_v1_prefix)

app.include_router(running_router, prefix=settings.api_v1_prefix)

app.include_router(labour_router, prefix=settings.api_v1_prefix)

app.include_router(subcontractor_router, prefix=settings.api_v1_prefix)

app.include_router(withholding_tax_router, prefix=settings.api_v1_prefix)

app.include_router(material_stock_router, prefix=settings.api_v1_prefix)

app.include_router(retention_router, prefix=settings.api_v1_prefix)

app.include_router(change_orders_router, prefix=settings.api_v1_prefix)

app.include_router(scheduling_router, prefix=settings.api_v1_prefix)

app.include_router(punch_lists_router, prefix=settings.api_v1_prefix)

app.include_router(salex_tax_router, prefix=settings.api_v1_prefix)

app.include_router(bank_guarantees_router, prefix=settings.api_v1_prefix)

app.include_router(cash_flow_router, prefix=settings.api_v1_prefix)

app.include_router(alerts_router, prefix=settings.api_v1_prefix)

app.include_router(privacy_router, prefix=settings.api_v1_prefix)

@app.get("/health", tags=["system"])
async def health() -> dict[str, str]:
  return {
    "status": "healthy",
    "service": settings.app_name,
    "version": "0.1.0",
  }

@app.get("/ready", tags=["system"])
async def ready() -> dict[str, str]:
  return {"status": "ready"}

@app.get(settings.api_v1_prefix + "/system/ping", tags=["system"])
async def api_ping() -> dict[str, str]:
  return {"message": "Trace API is running"}
